/* ============================================================
   MathMaster Pro - app.js by Koushik Koley
   Main controller: routing, UI rendering, features wiring
   Implements all 200+ features across all screens
   ============================================================ */

const App = (function () {
  "use strict";

  // ---------- State ----------
  const state = {
    route: "home",
    selectedGroup: null,
    selectedTopic: null,
    selectedDifficulty: "easy",
    questionFormat: null,
    practiceSession: null,
    quizSession: null,
    gameSession: null,
    studyTopic: null,
    formulaFilter: null,
    currentTab: {},
    streak: 0,
    noHintRun: 0,
    timer: null,
    timerStart: 0,
    currentProblem: null,
    currentMode: "practice",
    worksheetConfig: {},
    calculatorValue: "0",
    calculatorHistory: [],
    searchTimeout: null,
  };

  // ---------- DOM refs ----------
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);
  const content = $("#content");

  // ---------- Utility ----------
  function el(tag, attrs = {}, children = []) {
    const e = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => {
      if (k === "class") e.className = v;
      else if (k === "html") e.innerHTML = v;
      else if (k.startsWith("on"))
        e.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === "style" && typeof v === "object")
        Object.assign(e.style, v);
      else if (k === "dataset")
        Object.entries(v).forEach(([dk, dv]) => (e.dataset[dk] = dv));
      else e.setAttribute(k, v);
    });
    (Array.isArray(children) ? children : [children]).forEach((c) => {
      if (c == null) return;
      if (typeof c === "string" || typeof c === "number")
        e.appendChild(document.createTextNode(String(c)));
      else e.appendChild(c);
    });
    return e;
  }

  function toast(title, msg = "", type = "info", duration = 3000) {
    const t = el("div", { class: `toast ${type}` }, [
      el("div", { class: "toast-title" }, title),
      msg ? el("div", { class: "toast-msg" }, msg) : null,
    ]);
    $("#toastContainer").appendChild(t);
    setTimeout(() => {
      t.style.opacity = "0";
      t.style.transform = "translateX(40px)";
      setTimeout(() => t.remove(), 300);
    }, duration);
  }

  function modal(title, bodyHTML, footerHTML = "") {
    $("#modalTitle").textContent = title;
    $("#modalBody").innerHTML = bodyHTML;
    $("#modalFooter").innerHTML = footerHTML;
    $("#modalOverlay").classList.add("show");
  }
  function closeModal() {
    $("#modalOverlay").classList.remove("show");
  }

  // ---------- Confetti ----------
  function confetti() {
    if (!MMP.settings.animations) return;
    const canvas = $("#confettiCanvas");
    canvas.classList.add("show");
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const ctx = canvas.getContext("2d");
    const colors = ["#4f46e5", "#f59e0b", "#10b981", "#ef4444", "#3b82f6"];
    const pieces = Array.from({ length: 100 }, () => ({
      x: Math.random() * canvas.width,
      y: -20,
      vx: (Math.random() - 0.5) * 6,
      vy: Math.random() * 3 + 2,
      size: Math.random() * 8 + 4,
      color: colors[Math.floor(Math.random() * colors.length)],
      rotation: Math.random() * Math.PI * 2,
      vRot: (Math.random() - 0.5) * 0.3,
    }));
    let frames = 0;
    function tick() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      pieces.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.rotation += p.vRot;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
      });
      frames++;
      if (frames < 120) requestAnimationFrame(tick);
      else canvas.classList.remove("show");
    }
    tick();
  }

  function playSound(type) {
    if (!MMP.settings.sound) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      const ac = new AC();
      const o = ac.createOscillator();
      const g = ac.createGain();
      o.connect(g);
      g.connect(ac.destination);
      const freqs = {
        correct: [523, 659, 784],
        wrong: [220, 196],
        level: [523, 659, 784, 1047],
        click: [440],
      };
      const seq = freqs[type] || [440];
      let t = ac.currentTime;
      seq.forEach((f) => {
        o.frequency.setValueAtTime(f, t);
        t += 0.1;
      });
      g.gain.setValueAtTime(0.1, ac.currentTime);
      g.gain.exponentialRampToValueAtTime(
        0.001,
        ac.currentTime + seq.length * 0.1,
      );
      o.start();
      o.stop(ac.currentTime + seq.length * 0.1);
    } catch (e) {}
  }

  function vibrate(ms) {
    if (MMP.settings.haptics && navigator.vibrate) navigator.vibrate(ms);
  }

  // ============================================================
  // ROUTER
  // ============================================================
  function navigate(route, params = {}) {
    state.route = route;
    state.params = params;
    $$(".nav-item, .footer-item").forEach((n) =>
      n.classList.toggle("active", n.dataset.route === route),
    );
    $("#sidebar").classList.remove("open");
    window.scrollTo(0, 0);
    const renderers = {
      home: renderHome,
      study: renderStudy,
      practice: renderPractice,
      quiz: renderQuiz,
      flashcards: renderFlashcards,
      games: renderGames,
      tools: renderTools,
      stats: renderStats,
      achievements: renderAchievements,
      worksheet: renderWorksheet,
      settings: renderSettings,
    };
    (renderers[route] || renderHome)();
    updateTopbar();
  }

  function updateTopbar() {
    $("#xpDisplay").textContent = MMP.profile.xp;
    $("#streakDisplay").textContent = MMP.profile.streak;
    $("#levelDisplay").textContent = MMP.profile.level;
    $("#sidebarLevel").textContent = MMP.profile.level;
    const lp = MMP.levelProgress();
    $("#levelProgressFill").style.width = lp.pct + "%";
    $("#levelProgressText").textContent = `${lp.inLevel} / ${lp.need} XP`;
  }

  // ============================================================
  // HOME SCREEN
  // ============================================================
  function renderHome() {
    const groups = [
      {
        id: "primary",
        name: "Primary School",
        range: "Class 1 - 5",
        icon: "🧒",
        desc: "Counting, addition, subtraction, multiplication, division basics",
      },
      {
        id: "middle",
        name: "Middle School",
        range: "Class 6 - 8",
        icon: "👦",
        desc: "Fractions, decimals, percentages, pre-algebra, geometry",
      },
      {
        id: "high",
        name: "High School",
        range: "Class 9 - 12",
        icon: "🧑",
        desc: "Algebra, trigonometry, calculus, statistics, probability",
      },
      {
        id: "college",
        name: "College",
        range: "University Level",
        icon: "🎓",
        desc: "Linear algebra, multivariable calculus, differential equations",
      },
    ];
    const dailyGoalPct = Math.min(
      100,
      (MMP.profile.todayCount / MMP.profile.dailyGoal) * 100,
    );
    content.innerHTML = `
      <div class="hero">
        <h1>Welcome back, ${MMP.profile.name}! 👋</h1>
        <p>You're a <strong>${MMP.profile.title}</strong> at Level ${MMP.profile.level}. Pick a level group below or jump straight into practice, study, or a quick game. Math mastery starts here.</p>
        <div class="hero-actions">
          <button class="btn btn-lg" onclick="App.navigate('practice')" style="background:white;color:var(--primary)">✏️ Start Practicing</button>
          <button class="btn btn-lg btn-outline" onclick="App.navigate('study')" style="border-color:white;color:white">📚 Study First</button>
          <button class="btn btn-lg btn-outline" onclick="App.navigate('games')" style="border-color:white;color:white">🎮 Play a Game</button>
        </div>
      </div>

      <div class="grid grid-2 mb-5">
        <div class="card">
          <div class="card-title">🎯 Today's Goal</div>
          <div class="card-subtitle">Answer ${MMP.profile.dailyGoal} questions today</div>
          <div class="progress-bar mt-2"><div class="progress-fill" style="width:${dailyGoalPct}%;background:var(--success)"></div></div>
          <div class="text-sm text-muted mt-2">${MMP.profile.todayCount} / ${MMP.profile.dailyGoal} completed ${dailyGoalPct >= 100 ? "🎉" : ""}</div>
        </div>
        <div class="card">
          <div class="card-title">🔥 Current Streak</div>
          <div class="card-subtitle">${MMP.profile.streak} day${MMP.profile.streak !== 1 ? "s" : ""} in a row</div>
          <div class="text-2xl font-bold text-warning mt-2">🔥 ${MMP.profile.streak}</div>
          <div class="text-sm text-muted mt-2">Best: ${MMP.stats.bestStreak} days</div>
        </div>
      </div>

      <div class="page-header">
        <h2>Choose Your Level</h2>
        <p>Click a level group to explore topics and start learning</p>
      </div>

      <div class="grid grid-4">
        ${groups
          .map(
            (g) => `
          <div class="card level-group-card" onclick="App.openGroup('${g.id}')">
            <div class="lg-icon">${g.icon}</div>
            <div class="lg-title">${g.name}</div>
            <div class="lg-range">${g.range}</div>
            <div class="lg-progress">
              <div class="progress-bar"><div class="progress-fill" style="width:${groupProgress(g.id)}%"></div></div>
              <div class="text-xs text-muted mt-1">${topicsAttemptedInGroup(g.id)} topics attempted</div>
            </div>
          </div>
        `,
          )
          .join("")}
      </div>

      <div class="page-header mt-5">
        <h2>Quick Actions</h2>
        <p>Jump into popular features</p>
      </div>

      <div class="grid grid-4">
        <div class="card topic-card" onclick="App.navigate('flashcards')"><div class="tc-icon">🗂️</div><div class="tc-title">Flashcards</div><div class="tc-count">${MMP.flashcards.length} cards</div></div>
        <div class="card topic-card" onclick="App.navigate('tools')"><div class="tc-icon">🔧</div><div class="tc-title">Math Tools</div><div class="tc-count">15+ tools</div></div>
        <div class="card topic-card" onclick="App.navigate('achievements')"><div class="tc-icon">🏅</div><div class="tc-title">Achievements</div><div class="tc-count">${MMP.achievements.length}/${MMP.ACHIEVEMENTS.length} unlocked</div></div>
        <div class="card topic-card" onclick="App.navigate('worksheet')"><div class="tc-icon">🖨️</div><div class="tc-title">Worksheets</div><div class="tc-count">Printable practice</div></div>
        <div class="card topic-card" onclick="App.navigate('stats')"><div class="tc-icon">📊</div><div class="tc-title">Statistics</div><div class="tc-count">Track progress</div></div>
        <div class="card topic-card" onclick="App.navigate('study', { tab: 'formulas' })"><div class="tc-icon">📐</div><div class="tc-title">Formula Sheet</div><div class="tc-count">${Study.FORMULAS.length} formulas</div></div>
        <div class="card topic-card" onclick="App.navigate('study', { tab: 'glossary' })"><div class="tc-icon">📖</div><div class="tc-title">Glossary</div><div class="tc-count">${Study.GLOSSARY.length} terms</div></div>
        <div class="card topic-card" onclick="App.navigate('settings')"><div class="tc-icon">⚙️</div><div class="tc-title">Settings</div><div class="tc-count">Customize</div></div>
      </div>

      <div class="page-header mt-5">
        <h2>Recent Activity</h2>
      </div>
      <div class="card">
        ${
          MMP.history
            .slice(-5)
            .reverse()
            .map(
              (h) => `
          <div class="flex items-center justify-between" style="padding:8px 0;border-bottom:1px solid var(--border)">
            <div>
              <div class="font-bold">${Problems.getTopic(h.topic)?.name || h.topic}</div>
              <div class="text-xs text-muted">${h.difficulty} · ${h.mode} · ${new Date(h.t).toLocaleTimeString()}</div>
            </div>
            <span class="badge ${h.correct ? "badge-success" : "badge-danger"}">${h.correct ? "✓ Correct" : "✗ Wrong"} · +${h.xp} XP</span>
          </div>
        `,
            )
            .join("") ||
          '<div class="text-muted text-center">No activity yet. Start practicing to see your history here!</div>'
        }
      </div>
    `;
  }

  function groupProgress(groupId) {
    const topics = Problems.getTopicsByGroup(groupId);
    const attempted = topics.filter(
      (t) => MMP.stats.topicsAttempted[t.id],
    ).length;
    return Math.round((attempted / topics.length) * 100);
  }
  function topicsAttemptedInGroup(groupId) {
    return Problems.getTopicsByGroup(groupId).filter(
      (t) => MMP.stats.topicsAttempted[t.id],
    ).length;
  }

  // Open group → list topics
  function openGroup(groupId) {
    const group = Study.LEARNING_PATHS[groupId];
    const topics = Problems.getTopicsByGroup(groupId);
    content.innerHTML = `
      <div class="page-header">
        <button class="btn btn-sm btn-outline" onclick="App.navigate('home')">← Back</button>
        <h1 class="mt-3">${group.icon} ${group.title}</h1>
        <p>${group.desc}</p>
      </div>
      <div class="alert alert-info mb-4">
        💡 <strong>Tip:</strong> Click any topic to study the concept first, then practice. Each topic has <strong>unlimited levels</strong> — keep solving to advance!
      </div>
      <div class="grid grid-auto">
        ${topics
          .map((t, idx) => {
            const tp = MMP.getTopicProgress(t.id);
            return `
          <div class="card topic-card" onclick="App.openTopic('${t.id}')">
            <div class="flex items-center gap-2">
              <span class="tc-icon">${t.icon}</span>
              <div style="flex:1">
                <div class="tc-title">${idx + 1}. ${t.name}</div>
                <div class="tc-count">Level ${tp.level} · ${tp.solved}/${tp.needed} solved ${tp.mastered ? "🎓" : ""}</div>
              </div>
            </div>
          </div>
        `;
          })
          .join("")}
      </div>
    `;
  }

  function openTopic(topicId) {
    state.selectedTopic = topicId;
    const topic = Problems.getTopic(topicId);
    const mat = Study.getMaterial(topicId);
    const tp = MMP.getTopicProgress(topicId);
    content.innerHTML = `
      <div class="page-header">
        <button class="btn btn-sm btn-outline" onclick="App.openGroup('${topic.group}')">← Back</button>
        <h1 class="mt-3">${topic.icon} ${topic.name}</h1>
        <p>Your progress: Level ${tp.level} · ${tp.solved}/${tp.needed} solved ${tp.mastered ? "🎓 Mastered!" : ""}</p>
      </div>

      <div class="tabs">
        <button class="tab active" onclick="App.switchTab('topic-study', this)">📚 Study</button>
        <button class="tab" onclick="App.switchTab('topic-practice', this)">✏️ Practice</button>
        <button class="tab" onclick="App.switchTab('topic-quiz', this)">🎯 Quiz</button>
        <button class="tab" onclick="App.switchTab('topic-info', this)">ℹ️ Info</button>
      </div>

      <div id="topic-study" class="tab-content">
        ${
          mat
            ? `
          <div class="card mb-4">
            <div class="card-title">📖 Concept</div>
            <p>${mat.concept}</p>
          </div>
          <div class="grid grid-2">
            <div class="card">
              <div class="card-title">📐 Formula</div>
              <div class="math" style="font-size:1.3rem;background:var(--bg-soft);padding:12px;border-radius:8px">${mat.formula}</div>
            </div>
            <div class="card">
              <div class="card-title">📝 Steps</div>
              <ol style="padding-left:20px">${mat.steps.map((s) => `<li class="mb-2">${s}</li>`).join("")}</ol>
            </div>
            <div class="card">
              <div class="card-title">💡 Examples</div>
              <ul style="padding-left:20px">${mat.examples.map((e) => `<li class="mb-2">${e}</li>`).join("")}</ul>
            </div>
            <div class="card">
              <div class="card-title">⚠️ Common Mistakes</div>
              <ul style="padding-left:20px">${mat.mistakes.map((m) => `<li class="mb-2">${m}</li>`).join("")}</ul>
            </div>
            <div class="card">
              <div class="card-title">✨ Tips</div>
              <ul style="padding-left:20px">${mat.tips.map((t) => `<li class="mb-2">${t}</li>`).join("")}</ul>
            </div>
            <div class="card">
              <div class="card-title">🔗 Resources</div>
              ${mat.resources.map((r) => `<div><a href="${r.url}" target="_blank" rel="noopener">→ ${r.name}</a></div>`).join("")}
            </div>
          </div>
          <div class="text-center mt-4">
            <button class="btn btn-primary btn-lg" onclick="App.startPractice('${topicId}', 'easy')">I'm Ready — Start Practicing ✏️</button>
          </div>
        `
            : '<div class="alert alert-warning">Study material not available for this topic yet.</div>'
        }
      </div>

      <div id="topic-practice" class="tab-content hidden">
        <div class="card text-center">
          <div class="card-title">Practice Configuration</div>
          <p class="card-subtitle">Choose your difficulty and start practicing ${topic.name}</p>
          <div class="chip-row justify-center mt-3">
            <span class="chip active" data-diff="easy" onclick="App.selectDiff(this)">🟢 Easy</span>
            <span class="chip" data-diff="medium" onclick="App.selectDiff(this)">🟡 Medium</span>
            <span class="chip" data-diff="hard" onclick="App.selectDiff(this)">🔴 Hard</span>
            <span class="chip" data-diff="expert" onclick="App.selectDiff(this)">🟣 Expert</span>
          </div>
          <div class="chip-row justify-center mt-3">
            <span class="chip active" data-fmt="mcq" onclick="App.selectFmt(this)">📝 Multiple Choice</span>
            <span class="chip" data-fmt="input" onclick="App.selectFmt(this)">⌨️ Type Answer</span>
            <span class="chip" data-fmt="truefalse" onclick="App.selectFmt(this)">✓/✗ True/False</span>
          </div>
          <div class="mt-4">
            <button class="btn btn-primary btn-lg" onclick="App.startPractice('${topicId}', document.querySelector('.chip[data-diff].active').dataset.diff)">Start Practice</button>
          </div>
        </div>
      </div>

      <div id="topic-quiz" class="tab-content hidden">
        <div class="card text-center">
          <div class="card-title">Take a Quiz</div>
          <p class="card-subtitle">10 questions, timed, scored</p>
          <div class="chip-row justify-center mt-3">
            <span class="chip active" data-qdiff="easy" onclick="App.selectQDiff(this)">🟢 Easy</span>
            <span class="chip" data-qdiff="medium" onclick="App.selectQDiff(this)">🟡 Medium</span>
            <span class="chip" data-qdiff="hard" onclick="App.selectQDiff(this)">🔴 Hard</span>
            <span class="chip" data-qdiff="mixed" onclick="App.selectQDiff(this)">🌈 Mixed</span>
          </div>
          <div class="chip-row justify-center mt-3">
            <span class="chip" data-qcount="5" onclick="App.selectQCount(this)">5 Q</span>
            <span class="chip active" data-qcount="10" onclick="App.selectQCount(this)">10 Q</span>
            <span class="chip" data-qcount="20" onclick="App.selectQCount(this)">20 Q</span>
          </div>
          <div class="mt-4">
            <button class="btn btn-primary btn-lg" onclick="App.startQuiz('${topicId}')">🎯 Start Quiz</button>
          </div>
        </div>
      </div>

      <div id="topic-info" class="tab-content hidden">
        <div class="card">
          <div class="card-title">Topic Information</div>
          <table class="table">
            <tr><th>Topic ID</th><td>${topic.id}</td></tr>
            <tr><th>Level Group</th><td>${topic.group}</td></tr>
            <tr><th>Your Level</th><td>${tp.level}</td></tr>
            <tr><th>Solved this level</th><td>${tp.solved} / ${tp.needed}</td></tr>
            <tr><th>Mastered</th><td>${tp.mastered ? "Yes 🎓" : "No"}</td></tr>
            <tr><th>Total attempts</th><td>${MMP.stats.topicsAttempted[topic.id] || 0}</td></tr>
            <tr><th>Total correct</th><td>${MMP.stats.topicsCorrect[topic.id] || 0}</td></tr>
            <tr><th>Accuracy</th><td>${MMP.stats.topicsAttempted[topic.id] ? Math.round(((MMP.stats.topicsCorrect[topic.id] || 0) / MMP.stats.topicsAttempted[topic.id]) * 100) : 0}%</td></tr>
          </table>
          <div class="mt-4 flex gap-2">
            <button class="btn btn-outline" onclick="App.bookmarkTopic('${topic.id}')">${MMP.isBookmarked(topic.id) ? "★ Bookmarked" : "☆ Bookmark"}</button>
            <button class="btn btn-outline" onclick="App.shareTopic('${topic.id}')">🔗 Share</button>
            <button class="btn btn-outline" onclick="App.addTopicCard('${topic.id}')">🗂️ Add Flashcard</button>
          </div>
        </div>
      </div>
    `;
    state.selectedDifficulty = "easy";
    state.questionFormat = "mcq";
    state.quizConfig = { diff: "easy", count: 10 };
  }

  function switchTab(name, btn) {
    $$(".tab-content").forEach((t) => t.classList.add("hidden"));
    $$(".tab").forEach((t) => t.classList.remove("active"));
    btn.classList.add("active");
    const target = document.getElementById(name);
    if (target) target.classList.remove("hidden");
  }

  // ============================================================
  // STUDY SCREEN
  // ============================================================
  function renderStudy() {
    const tab = state.params?.tab || "paths";
    content.innerHTML = `
      <div class="page-header">
        <h1>📚 Study Center</h1>
        <p>Prepare before practicing. Master concepts, formulas, and common mistakes.</p>
      </div>
      <div class="tabs">
        <button class="tab ${tab === "paths" ? "active" : ""}" onclick="App.renderStudyTab('paths')">🛤️ Learning Paths</button>
        <button class="tab ${tab === "formulas" ? "active" : ""}" onclick="App.renderStudyTab('formulas')">📐 Formulas</button>
        <button class="tab ${tab === "glossary" ? "active" : ""}" onclick="App.renderStudyTab('glossary')">📖 Glossary</button>
        <button class="tab ${tab === "tips" ? "active" : ""}" onclick="App.renderStudyTab('tips')">💡 Tips & Tricks</button>
        <button class="tab ${tab === "mistakes" ? "active" : ""}" onclick="App.renderStudyTab('mistakes')">⚠️ Common Mistakes</button>
        <button class="tab ${tab === "history" ? "active" : ""}" onclick="App.renderStudyTab('history')">🏛️ Math History</button>
        <button class="tab ${tab === "notepad" ? "active" : ""}" onclick="App.renderStudyTab('notepad')">📝 My Notes</button>
      </div>
      <div id="studyContent"></div>
    `;
    renderStudyTab(tab);
  }

  function renderStudyTab(tab) {
    const sc = $("#studyContent");
    if (!sc) return;
    $$(".tab").forEach((t) => t.classList.remove("active"));
    event?.target?.classList?.add("active");
    if (tab === "paths") {
      sc.innerHTML = Object.entries(Study.LEARNING_PATHS)
        .map(
          ([id, p]) => `
        <div class="card mb-4">
          <div class="card-title">${p.icon} ${p.title}</div>
          <p class="card-subtitle">${p.desc}</p>
          <div class="chip-row mt-3">
            ${p.path
              .map((tid, i) => {
                const t = Problems.getTopic(tid);
                const done = (MMP.stats.topicsCorrect[tid] || 0) >= 5;
                return `<span class="chip" onclick="App.openTopic('${tid}')" style="${done ? "background:var(--success);color:white" : ""}">${i + 1}. ${t?.name || tid} ${done ? "✓" : ""}</span>`;
              })
              .join("")}
          </div>
          <div class="mt-3">
            <button class="btn btn-primary" onclick="App.startPathPractice('${id}')">🚀 Practice This Path</button>
          </div>
        </div>
      `,
        )
        .join("");
    } else if (tab === "formulas") {
      const cats = Study.getFormulaCategories();
      const filter = state.formulaFilter || "All";
      const formulas =
        filter === "All" ? Study.FORMULAS : Study.getFormulas(filter);
      sc.innerHTML = `
        <div class="chip-row mb-4">
          <span class="chip ${filter === "All" ? "active" : ""}" onclick="App.filterFormulas('All')">All (${Study.FORMULAS.length})</span>
          ${cats.map((c) => `<span class="chip ${filter === c ? "active" : ""}" onclick="App.filterFormulas('${c}')">${c} (${Study.getFormulas(c).length})</span>`).join("")}
        </div>
        <div class="grid grid-2">
          ${formulas
            .map(
              (f) => `
            <div class="card">
              <div class="flex items-center justify-between">
                <span class="badge">${f.cat}</span>
                <button class="icon-btn" onclick="App.copyFormula('${f.formula.replace(/'/g, "\\'")}')">📋</button>
              </div>
              <div class="card-title mt-2">${f.name}</div>
              <div class="math" style="font-size:1.2rem;background:var(--bg-soft);padding:10px;border-radius:6px;margin-top:6px">${f.formula}</div>
              <button class="btn btn-sm btn-outline mt-2" onclick="App.openTopic('${f.topic}')">→ Practice this topic</button>
            </div>
          `,
            )
            .join("")}
        </div>
      `;
    } else if (tab === "glossary") {
      sc.innerHTML = `
        <div class="card">
          <input type="search" class="form-control mb-3" placeholder="Search terms..." oninput="App.searchGlossary(this.value)" />
          <div id="glossaryList">
            ${Study.GLOSSARY.map(
              (g) => `
              <div style="padding:10px 0;border-bottom:1px solid var(--border)">
                <div class="font-bold">${g.term}</div>
                <div class="text-sm text-muted">${g.def}</div>
              </div>
            `,
            ).join("")}
          </div>
        </div>
      `;
    } else if (tab === "tips") {
      sc.innerHTML = `
        <div class="grid grid-2">
          ${Study.TIPS.map(
            (t) => `
            <div class="card">
              <div class="card-title">✨ ${t.title}</div>
              <p>${t.body}</p>
            </div>
          `,
          ).join("")}
        </div>
      `;
    } else if (tab === "mistakes") {
      sc.innerHTML = `
        <div class="grid grid-2">
          ${Study.COMMON_MISTAKES.map(
            (m, i) => `
            <div class="card">
              <span class="badge badge-danger">${m.cat}</span>
              <div class="card-title mt-2">❌ ${m.mistake}</div>
              <div class="alert alert-success mt-2">✅ <strong>Fix:</strong> ${m.fix}</div>
            </div>
          `,
          ).join("")}
        </div>
      `;
    } else if (tab === "history") {
      sc.innerHTML = `
        <div class="card">
          <div class="card-title">🏛️ Timeline of Mathematics</div>
          <p class="card-subtitle">A journey through math history to inspire your learning</p>
          <div class="mt-3">
            ${Study.HISTORY.map(
              (h) => `
              <div style="display:flex;gap:12px;padding:10px 0;border-bottom:1px solid var(--border)">
                <div style="min-width:120px;font-weight:700;color:var(--primary)">${h.era}</div>
                <div>${h.event}</div>
              </div>
            `,
            ).join("")}
          </div>
        </div>
      `;
    } else if (tab === "notepad") {
      sc.innerHTML = `
        <div class="card">
          <div class="card-title">📝 My Math Notes</div>
          <p class="card-subtitle">Jot down anything you want to remember</p>
          <textarea class="form-control" rows="14" placeholder="Type your notes here..." oninput="App.saveNotes(this.value)">${MMP.notepad}</textarea>
          <div class="text-sm text-muted mt-2">Notes are saved automatically to your device.</div>
        </div>
      `;
    }
  }

  function filterFormulas(cat) {
    state.formulaFilter = cat;
    renderStudyTab("formulas");
  }
  function copyFormula(f) {
    navigator.clipboard?.writeText(f);
    toast("Copied!", "Formula copied to clipboard", "success");
  }
  function searchGlossary(q) {
    const list = $("#glossaryList");
    if (!list) return;
    const filtered = Study.GLOSSARY.filter(
      (g) =>
        g.term.toLowerCase().includes(q.toLowerCase()) ||
        g.def.toLowerCase().includes(q.toLowerCase()),
    );
    list.innerHTML =
      filtered
        .map(
          (g) => `
      <div style="padding:10px 0;border-bottom:1px solid var(--border)">
        <div class="font-bold">${g.term}</div>
        <div class="text-sm text-muted">${g.def}</div>
      </div>
    `,
        )
        .join("") ||
      '<div class="text-muted text-center">No matching terms found.</div>';
  }
  function saveNotes(v) {
    MMP.notepad = v;
  }

  // ============================================================
  // PRACTICE SCREEN (Unlimited Levels)
  // ============================================================
  function startPractice(topicId, difficulty) {
    state.selectedTopic = topicId;
    state.selectedDifficulty = difficulty;
    state.currentMode = "practice";
    state.practiceSession = {
      correct: 0,
      wrong: 0,
      streak: 0,
      startTime: Date.now(),
      hintsUsed: 0,
    };
    state.streak = 0;
    nextProblem();
  }

  function nextProblem() {
    const problem = Problems.generate(
      state.selectedTopic,
      state.selectedDifficulty,
    );
    state.currentProblem = problem;
    const fmt = state.questionFormat || MMP.settings.questionFormat;
    const tp = MMP.getTopicProgress(state.selectedTopic);
    renderProblem(problem, fmt, tp);
  }

  function renderProblem(p, fmt, tp) {
    const topic = Problems.getTopic(state.selectedTopic);
    content.innerHTML = `
      <div class="page-header">
        <button class="btn btn-sm btn-outline" onclick="App.openTopic('${state.selectedTopic}')">← Exit</button>
        <h2 class="mt-2">${topic.icon} ${topic.name} — Level ${tp.level}</h2>
      </div>
      <div class="practice-meta">
        <span class="meta-pill">📊 ${state.selectedDifficulty}</span>
        <span class="meta-pill score">✓ ${state.practiceSession.correct}</span>
        <span class="meta-pill">✗ ${state.practiceSession.wrong}</span>
        <span class="meta-pill streak">🔥 ${state.streak}</span>
        <span class="meta-pill">🎯 Lvl ${tp.level} · ${tp.solved}/${tp.needed}</span>
      </div>

      <div class="card problem-display">
        <div class="problem-text math">${p.question}</div>
        ${p.questionVisual ? `<div style="font-size:1.5rem;margin:8px 0">${p.questionVisual}</div>` : ""}
        <div class="problem-hint">${MMP.settings.showHints ? p.hint : ""}</div>
        <div id="answerArea" class="mt-3"></div>
        <div id="feedback" class="mt-3"></div>
      </div>

      <div class="text-center mt-3 flex gap-2" style="justify-content:center;flex-wrap:wrap">
        <button class="btn btn-outline" onclick="App.showHint()">💡 Hint</button>
        <button class="btn btn-outline" onclick="App.showSteps()">📝 Steps</button>
        <button class="btn btn-outline" onclick="App.showFormula()">📐 Formula</button>
        <button class="btn btn-outline" onclick="App.skipProblem()">⏭️ Skip</button>
        <button class="btn btn-danger btn-sm" onclick="App.exitPractice()">✕ End Session</button>
      </div>
    `;
    state.timerStart = Date.now();
    if (fmt === "mcq" && p.choices) {
      renderChoices(p);
    } else if (fmt === "input") {
      renderInput(p);
    } else if (fmt === "truefalse") {
      renderTrueFalse(p);
    } else if (p.choices) {
      renderChoices(p);
    } else {
      renderInput(p);
    }
  }

  function renderChoices(p) {
    const area = $("#answerArea");
    area.innerHTML = `<div class="choices-grid">${p.choices
      .map(
        (c) => `
      <button class="choice-btn" onclick="App.answerMCQ('${String(c).replace(/'/g, "\\'")}')">${c}</button>
    `,
      )
      .join("")}</div>`;
  }

  function renderInput(p) {
    const area = $("#answerArea");
    const isMobile = window.innerWidth < 700;
    area.innerHTML = `
      <input type="text" class="answer-input" id="ansInput" placeholder="Type your answer..." autocomplete="off" />
      <div class="mt-3">
        <button class="btn btn-primary btn-lg" onclick="App.answerInput()">Submit ✓</button>
      </div>
      ${
        isMobile
          ? `
        <div class="numpad mt-3">
          ${[7, 8, 9, 4, 5, 6, 1, 2, 3, ".", 0, "⌫"]
            .map(
              (k) => `
            <button onclick="App.numpadKey('${k}')">${k}</button>
          `,
            )
            .join("")}
        </div>
      `
          : ""
      }
    `;
    const inp = $("#ansInput");
    inp.focus();
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") answerInput();
    });
  }

  function renderTrueFalse(p) {
    const area = $("#answerArea");
    const truth =
      String(p.answer) === "Yes" || p.answer === true || p.answer === 1;
    area.innerHTML = `
      <div class="choices-grid" style="grid-template-columns: 1fr 1fr">
        <button class="choice-btn" style="background:var(--success);color:white" onclick="App.answerTF(true)">✓ True / Yes</button>
        <button class="choice-btn" style="background:var(--danger);color:white" onclick="App.answerTF(false)">✗ False / No</button>
      </div>
    `;
    state._tfTruth = truth;
  }

  function numpadKey(k) {
    const inp = $("#ansInput");
    if (k === "⌫") inp.value = inp.value.slice(0, -1);
    else inp.value += k;
  }

  function answerMCQ(choice) {
    const correct = String(choice) === String(state.currentProblem.answer);
    handleAnswer(correct, choice);
  }
  function answerInput() {
    const inp = $("#ansInput");
    const val = inp.value.trim();
    const correct =
      String(val) === String(state.currentProblem.answer) ||
      parseFloat(val) === parseFloat(state.currentProblem.answer);
    handleAnswer(correct, val);
  }
  function answerTF(choice) {
    handleAnswer(choice === state._tfTruth, choice ? "True" : "False");
  }

  function handleAnswer(correct, given) {
    const timeSpent = Math.round((Date.now() - state.timerStart) / 1000);
    const p = state.currentProblem;

    // Highlight correct/wrong
    $$(".choice-btn").forEach((btn) => {
      if (btn.textContent === String(p.answer)) btn.classList.add("correct");
      else if (btn.textContent === String(given) && !correct)
        btn.classList.add("wrong");
    });
    const inp = $("#ansInput");
    if (inp) {
      inp.classList.add(correct ? "correct" : "wrong");
      inp.disabled = true;
    }

    const result = MMP.recordAnswer({
      topic: state.selectedTopic,
      difficulty: state.selectedDifficulty,
      correct,
      timeSpent,
      mode: state.currentMode,
    });

    state.practiceSession.correct += correct ? 1 : 0;
    state.practiceSession.wrong += correct ? 0 : 1;
    state.streak = correct ? state.streak + 1 : 0;
    if (state.streak > MMP.stats.bestStreak)
      MMP.stats.bestStreak = state.streak;
    if (correct) state.practiceSession.streak = state.streak;

    const fb = $("#feedback");
    if (correct) {
      playSound("correct");
      vibrate(50);
      fb.innerHTML = `<div class="alert alert-success">✓ Correct! +${result.xp} XP ${result.leveledUp ? `🎉 <strong>LEVEL UP! You're now Level ${result.newLevel}!</strong>` : ""}</div>`;
      if (result.leveledUp) {
        confetti();
        playSound("level");
      }
      if (state.streak >= 5 && state.streak % 5 === 0) {
        toast(`${state.streak} Streak! 🔥`, "Keep it going!", "success");
        confetti();
      }
    } else {
      playSound("wrong");
      vibrate(200);
      fb.innerHTML = `
        <div class="alert alert-danger">✗ Not quite. Correct answer: <strong>${p.answer}</strong></div>
        ${
          MMP.settings.showSteps && p.steps
            ? `
          <div class="solution-steps">
            <h4>📝 Solution</h4>
            ${p.steps.map((s) => `<div class="solution-step">${s}</div>`).join("")}
          </div>
        `
            : ""
        }
      `;
    }

    // Check achievements
    const newAch = MMP.checkAchievements();
    newAch.forEach((a) => {
      toast(`Achievement Unlocked! ${a.icon}`, a.name, "warning", 5000);
      confetti();
    });

    updateTopbar();
    MMP.persist.all();

    // Auto-next or manual
    const delay = correct ? 800 : 2500;
    if (MMP.settings.autoNext) {
      setTimeout(() => nextProblem(), delay);
    } else {
      fb.innerHTML += `<div class="text-center mt-3"><button class="btn btn-primary btn-lg" onclick="App.nextProblem()">Next →</button></div>`;
    }
  }

  function showHint() {
    state.practiceSession.hintsUsed++;
    modal(
      "💡 Hint",
      `<p>${state.currentProblem.hint || "No hint available."}</p>`,
      `<button class="btn btn-primary" onclick="App.closeModal()">Got it</button>`,
    );
  }
  function showSteps() {
    const p = state.currentProblem;
    modal(
      "📝 Solution Steps",
      `
      <p><strong>Question:</strong> ${p.question}</p>
      <p><strong>Answer:</strong> ${p.answer}</p>
      <div class="solution-steps mt-3">
        ${p.steps ? p.steps.map((s) => `<div class="solution-step">${s}</div>`).join("") : "No steps available."}
      </div>
    `,
      `<button class="btn btn-primary" onclick="App.closeModal()">Close</button>`,
    );
  }
  function showFormula() {
    const p = state.currentProblem;
    modal(
      "📐 Formula",
      `<div class="math" style="font-size:1.4rem;text-align:center;padding:20px;background:var(--bg-soft);border-radius:8px">${p.formula || "No formula available."}</div>`,
      `<button class="btn btn-primary" onclick="App.closeModal()">Close</button>`,
    );
  }
  function skipProblem() {
    state.streak = 0;
    nextProblem();
  }
  function exitPractice() {
    if (state.practiceSession) {
      const s = state.practiceSession;
      const total = s.correct + s.wrong;
      const acc = total ? Math.round((s.correct / total) * 100) : 0;
      const time = Math.round((Date.now() - s.startTime) / 1000);
      modal(
        "📊 Session Summary",
        `
        <div class="grid grid-2">
          <div class="stat-card"><div class="stat-value">${s.correct}</div><div class="stat-label">Correct</div></div>
          <div class="stat-card"><div class="stat-value">${s.wrong}</div><div class="stat-label">Wrong</div></div>
          <div class="stat-card"><div class="stat-value">${acc}%</div><div class="stat-label">Accuracy</div></div>
          <div class="stat-card"><div class="stat-value">${Math.floor(time / 60)}:${String(time % 60).padStart(2, "0")}</div><div class="stat-label">Time</div></div>
          <div class="stat-card"><div class="stat-value">${s.streak}</div><div class="stat-label">Best Streak</div></div>
          <div class="stat-card"><div class="stat-value">${s.hintsUsed}</div><div class="stat-label">Hints Used</div></div>
        </div>
      `,
        `<button class="btn btn-outline" onclick="App.closeModal();App.openTopic('${state.selectedTopic}')">Close</button><button class="btn btn-primary" onclick="App.closeModal();App.startPractice('${state.selectedTopic}','${state.selectedDifficulty}')">Practice Again</button>`,
      );
    }
    state.practiceSession = null;
  }

  // Render practice screen (entry)
  function renderPractice() {
    if (!state.selectedTopic) {
      // Show topic picker
      content.innerHTML = `
        <div class="page-header">
          <h1>✏️ Practice</h1>
          <p>Pick any topic to start practicing. Each topic has unlimited levels!</p>
        </div>
        <div class="card mb-4">
          <div class="card-title">Quick Start</div>
          <div class="chip-row">
            ${["primary", "middle", "high", "college"].map((g) => `<span class="chip" onclick="App.filterTopics('${g}')">${Study.LEARNING_PATHS[g].icon} ${Study.LEARNING_PATHS[g].title}</span>`).join("")}
            <span class="chip active" onclick="App.filterTopics('all')">All</span>
          </div>
        </div>
        <div id="topicList" class="grid grid-auto">
          ${renderTopicList("all")}
        </div>
      `;
      return;
    }
    openTopic(state.selectedTopic);
  }

  function renderTopicList(group) {
    const topics =
      group === "all" ? Problems.TOPICS : Problems.getTopicsByGroup(group);
    return topics
      .map((t) => {
        const tp = MMP.getTopicProgress(t.id);
        return `
        <div class="card topic-card" onclick="App.openTopic('${t.id}')">
          <div class="flex items-center gap-2">
            <span class="tc-icon">${t.icon}</span>
            <div style="flex:1">
              <div class="tc-title">${t.name}</div>
              <div class="tc-count">Lvl ${tp.level} · ${tp.solved}/${tp.needed} ${tp.mastered ? "🎓" : ""}</div>
            </div>
          </div>
        </div>
      `;
      })
      .join("");
  }

  function filterTopics(group) {
    $$(".chip").forEach((c) => c.classList.remove("active"));
    event.target.classList.add("active");
    $("#topicList").innerHTML = renderTopicList(group);
  }

  // ============================================================
  // QUIZ MODE
  // ============================================================
  function renderQuiz() {
    content.innerHTML = `
      <div class="page-header">
        <h1>🎯 Quiz Mode</h1>
        <p>Timed quizzes to test your knowledge. Pick a topic or category.</p>
      </div>
      <div class="card mb-4">
        <div class="card-title">Quiz Configuration</div>
        <div class="form-group">
          <label class="form-label">Topic Group</label>
          <div class="chip-row">
            ${["primary", "middle", "high", "college", "all"].map((g) => `<span class="chip ${g === "all" ? "active" : ""}" onclick="App.setQuizGroup('${g}', this)">${g === "all" ? "🌈 All" : Study.LEARNING_PATHS[g].icon + " " + Study.LEARNING_PATHS[g].title}</span>`).join("")}
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Difficulty</label>
          <div class="chip-row">
            <span class="chip active" data-qdiff="easy" onclick="App.selectQDiffEl(this)">🟢 Easy</span>
            <span class="chip" data-qdiff="medium" onclick="App.selectQDiffEl(this)">🟡 Medium</span>
            <span class="chip" data-qdiff="hard" onclick="App.selectQDiffEl(this)">🔴 Hard</span>
            <span class="chip" data-qdiff="mixed" onclick="App.selectQDiffEl(this)">🌈 Mixed</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Number of Questions</label>
          <div class="chip-row">
            <span class="chip" data-qcount="5" onclick="App.selectQCountEl(this)">5</span>
            <span class="chip active" data-qcount="10" onclick="App.selectQCountEl(this)">10</span>
            <span class="chip" data-qcount="20" onclick="App.selectQCountEl(this)">20</span>
            <span class="chip" data-qcount="50" onclick="App.selectQCountEl(this)">50</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Time per question</label>
          <div class="chip-row">
            <span class="chip" data-qtime="15" onclick="App.selectQTimeEl(this)">15s</span>
            <span class="chip active" data-qtime="30" onclick="App.selectQTimeEl(this)">30s</span>
            <span class="chip" data-qtime="60" onclick="App.selectQTimeEl(this)">60s</span>
            <span class="chip" data-qtime="0" onclick="App.selectQTimeEl(this)">∞ No limit</span>
          </div>
        </div>
        <button class="btn btn-primary btn-lg btn-block mt-3" onclick="App.startQuizMode()">🚀 Start Quiz</button>
      </div>
      <div class="card">
        <div class="card-title">🏆 Quiz History</div>
        ${
          MMP.history
            .filter((h) => h.mode === "quiz")
            .slice(-5)
            .reverse()
            .map(
              (h) => `
          <div class="flex justify-between" style="padding:6px 0;border-bottom:1px solid var(--border)">
            <div>${Problems.getTopic(h.topic)?.name || h.topic}</div>
            <span class="badge ${h.correct ? "badge-success" : "badge-danger"}">${h.correct ? "✓" : "✗"} +${h.xp}</span>
          </div>
        `,
            )
            .join("") ||
          '<div class="text-muted text-center">No quiz history yet.</div>'
        }
      </div>
    `;
    state.quizConfig = { group: "all", diff: "easy", count: 10, time: 30 };
  }

  function setQuizGroup(g, btn) {
    state.quizConfig.group = g;
    $$(".chip").forEach((c) => c.classList.remove("active"));
    btn.classList.add("active");
  }
  function selectQDiff(btn) {
    state.quizConfig.diff = btn.dataset.qdiff;
    $$("[data-qdiff]").forEach((c) => c.classList.remove("active"));
    btn.classList.add("active");
  }
  function selectQDiffEl(btn) {
    selectQDiff(btn);
  }
  function selectQCount(btn) {
    state.quizConfig.count = parseInt(btn.dataset.qcount);
    $$("[data-qcount]").forEach((c) => c.classList.remove("active"));
    btn.classList.add("active");
  }
  function selectQCountEl(btn) {
    selectQCount(btn);
  }
  function selectQTime(btn) {
    state.quizConfig.time = parseInt(btn.dataset.qtime);
    $$("[data-qtime]").forEach((c) => c.classList.remove("active"));
    btn.classList.add("active");
  }
  function selectQTimeEl(btn) {
    selectQTime(btn);
  }
  function selectDiff(btn) {
    state.selectedDifficulty = btn.dataset.diff;
    $$("[data-diff]").forEach((c) => c.classList.remove("active"));
    btn.classList.add("active");
  }
  function selectFmt(btn) {
    state.questionFormat = btn.dataset.fmt;
    $$("[data-fmt]").forEach((c) => c.classList.remove("active"));
    btn.classList.add("active");
  }

  function startQuiz(topicId) {
    state.selectedTopic = topicId;
    state.quizConfig = state.quizConfig || {
      diff: "easy",
      count: 10,
      time: 30,
    };
    startQuizMode();
  }
  function startQuizMode() {
    const cfg = state.quizConfig;
    let topics;
    if (state.selectedTopic && state.route === "practice") {
      topics = [state.selectedTopic];
    } else if (cfg.group === "all") {
      topics = Problems.TOPICS.map((t) => t.id);
    } else {
      topics = Problems.getTopicsByGroup(cfg.group).map((t) => t.id);
    }
    state.quizSession = {
      questions: [],
      current: 0,
      correct: 0,
      startTime: Date.now(),
      timeLeft: cfg.time,
      timer: null,
    };
    for (let i = 0; i < cfg.count; i++) {
      const tId = topics[Math.floor(Math.random() * topics.length)];
      const diff =
        cfg.diff === "mixed"
          ? ["easy", "medium", "hard", "expert"][Math.floor(Math.random() * 4)]
          : cfg.diff;
      state.quizSession.questions.push({
        topicId: tId,
        diff,
        problem: Problems.generate(tId, diff),
      });
    }
    state.currentMode = "quiz";
    renderQuizQuestion();
  }

  function renderQuizQuestion() {
    const qs = state.quizSession;
    if (qs.current >= qs.questions.length) {
      endQuiz();
      return;
    }
    const q = qs.questions[qs.current];
    const p = q.problem;
    state.currentProblem = p;
    state.selectedTopic = q.topicId;
    state.selectedDifficulty = q.diff;

    content.innerHTML = `
      <div class="page-header">
        <button class="btn btn-sm btn-outline" onclick="if(confirm('Quit quiz?')) App.endQuiz()">✕ Quit</button>
        <h2 class="mt-2">🎯 Quiz — Question ${qs.current + 1} of ${qs.questions.length}</h2>
      </div>
      <div class="practice-meta">
        <span class="meta-pill score">✓ ${qs.correct}</span>
        <span class="meta-pill">📋 ${q.diff}</span>
        ${state.quizConfig.time > 0 ? `<span class="meta-pill timer" id="qTimer">⏱️ ${qs.timeLeft}s</span>` : ""}
      </div>
      <div class="progress-bar mb-3"><div class="progress-fill" style="width:${(qs.current / qs.questions.length) * 100}%"></div></div>
      <div class="card problem-display">
        <div class="problem-text math">${p.question}</div>
        ${p.questionVisual ? `<div style="font-size:1.5rem;margin:8px 0">${p.questionVisual}</div>` : ""}
        <div id="answerArea" class="mt-3"></div>
        <div id="feedback" class="mt-3"></div>
      </div>
    `;
    state.timerStart = Date.now();
    if (p.choices) renderChoices(p);
    else renderInput(p);

    if (state.quizConfig.time > 0) {
      qs.timeLeft = state.quizConfig.time;
      qs.timer = setInterval(() => {
        qs.timeLeft--;
        const t = $("#qTimer");
        if (t) t.textContent = `⏱️ ${qs.timeLeft}s`;
        if (qs.timeLeft <= 0) {
          clearInterval(qs.timer);
          handleAnswer(false, "(timeout)");
        }
      }, 1000);
    }
  }

  function endQuiz() {
    if (state.quizSession?.timer) clearInterval(state.quizSession.timer);
    const qs = state.quizSession;
    if (!qs) return;
    const total = qs.questions.length;
    const acc = total ? Math.round((qs.correct / total) * 100) : 0;
    const time = Math.round((Date.now() - qs.startTime) / 1000);
    const passed = acc >= MMP.settings.passScore;
    modal(
      passed ? "🎉 Quiz Passed!" : "📚 Keep Practicing",
      `
      <div class="grid grid-2">
        <div class="stat-card"><div class="stat-value">${qs.correct}/${total}</div><div class="stat-label">Score</div></div>
        <div class="stat-card"><div class="stat-value">${acc}%</div><div class="stat-label">Accuracy</div></div>
        <div class="stat-card"><div class="stat-value">${Math.floor(time / 60)}:${String(time % 60).padStart(2, "0")}</div><div class="stat-label">Time</div></div>
        <div class="stat-card"><div class="stat-value">${passed ? "PASS" : "FAIL"}</div><div class="stat-label">Result</div></div>
      </div>
      ${passed ? '<div class="alert alert-success mt-3">Great job! You\'ve passed this quiz.</div>' : '<div class="alert alert-warning mt-3">You\'ll get there! Review the study materials and try again.</div>'}
    `,
      `<button class="btn btn-outline" onclick="App.closeModal();App.navigate('quiz')">Close</button><button class="btn btn-primary" onclick="App.closeModal();App.startQuizMode()">Try Again</button>`,
    );
    if (passed) confetti();
    state.quizSession = null;
  }

  // ============================================================
  // FLASHCARDS
  // ============================================================
  function renderFlashcards() {
    content.innerHTML = `
      <div class="page-header">
        <h1>🗂️ Flashcards</h1>
        <p>Create and study your own flashcards, or use built-in ones.</p>
      </div>
      <div class="grid grid-2 mb-4">
        <div class="card">
          <div class="card-title">➕ Create New Card</div>
          <div class="form-group">
            <label class="form-label">Front (Question)</label>
            <input type="text" class="form-control" id="fcFront" placeholder="e.g., What is 7 × 8?" />
          </div>
          <div class="form-group">
            <label class="form-label">Back (Answer)</label>
            <input type="text" class="form-control" id="fcBack" placeholder="e.g., 56" />
          </div>
          <button class="btn btn-primary btn-block" onclick="App.addCard()">Add Card</button>
        </div>
        <div class="card">
          <div class="card-title">📚 Quick Add from Topic</div>
          <p class="card-subtitle">Generate flashcards from any topic</p>
          <select class="form-control" id="fcTopic">
            ${Problems.TOPICS.map((t) => `<option value="${t.id}">${t.icon} ${t.name}</option>`).join("")}
          </select>
          <button class="btn btn-outline btn-block mt-2" onclick="App.generateCardsFromTopic()">Generate 5 Cards</button>
        </div>
      </div>
      <div class="card mb-4">
        <div class="card-title">📇 Your Flashcards (${MMP.flashcards.length})</div>
        ${
          MMP.flashcards.length === 0
            ? '<p class="text-muted text-center">No flashcards yet. Create one above!</p>'
            : `
          <div class="grid grid-3">
            ${MMP.flashcards
              .map(
                (c) => `
              <div class="card" style="cursor:pointer" onclick="App.flipCard(${c.id})">
                <div id="fc-${c.id}">${c.front}</div>
                <div class="text-xs text-muted mt-2">Click to flip</div>
                <button class="btn btn-sm btn-danger mt-2" onclick="event.stopPropagation();App.removeCard(${c.id})">🗑️</button>
              </div>
            `,
              )
              .join("")}
          </div>
        `
        }
      </div>
      ${
        MMP.flashcards.length > 0
          ? `
        <div class="card">
          <div class="card-title">🎯 Study Mode</div>
          <p class="card-subtitle">Flip through cards randomly</p>
          <button class="btn btn-primary btn-lg" onclick="App.startCardStudy()">Start Studying</button>
        </div>
      `
          : ""
      }
    `;
  }

  let cardFlipState = {};
  function flipCard(id) {
    const card = MMP.flashcards.find((c) => c.id === id);
    if (!card) return;
    const el = document.getElementById("fc-" + id);
    cardFlipState[id] = !cardFlipState[id];
    el.textContent = cardFlipState[id] ? card.back : card.front;
    el.style.color = cardFlipState[id] ? "var(--primary)" : "var(--text)";
  }
  function addCard() {
    const f = $("#fcFront").value.trim();
    const b = $("#fcBack").value.trim();
    if (!f || !b) {
      toast("Missing fields", "Please fill both front and back", "warning");
      return;
    }
    MMP.addFlashcard({ front: f, back: b });
    toast("Card added!", "Flashcard saved", "success");
    renderFlashcards();
  }
  function removeCard(id) {
    if (!confirm("Delete this card?")) return;
    MMP.removeFlashcard(id);
    renderFlashcards();
  }
  function generateCardsFromTopic() {
    const topicId = $("#fcTopic").value;
    for (let i = 0; i < 5; i++) {
      const p = Problems.generate(topicId, "easy");
      MMP.addFlashcard({ front: p.question, back: String(p.answer) });
    }
    toast("5 cards added!", "Generated from topic", "success");
    renderFlashcards();
  }
  function addTopicCard(topicId) {
    const p = Problems.generate(topicId, "easy");
    MMP.addFlashcard({ front: p.question, back: String(p.answer) });
    toast("Card added!", "Check Flashcards page", "success");
  }
  function startCardStudy() {
    const cards = Problems.shuffle(MMP.flashcards);
    let idx = 0;
    function show() {
      const c = cards[idx];
      modal(
        `Card ${idx + 1} of ${cards.length}`,
        `
        <div class="flashcard" onclick="App.flipStudyCard()">
          <div class="flashcard-inner" id="studyCard">
            <div class="flashcard-front"><div class="flashcard-question">${c.front}</div><div class="text-xs text-muted mt-3">Tap to reveal answer</div></div>
            <div class="flashcard-back"><div class="flashcard-answer">${c.back}</div></div>
          </div>
        </div>
      `,
        `
        <button class="btn btn-outline" onclick="App.closeModal()">End Study</button>
        <button class="btn btn-primary" onclick="App.nextStudyCard()">Next →</button>
      `,
      );
    }
    state._studyCards = cards;
    state._studyIdx = 0;
    state._studyFlipped = false;
    show();
  }
  function flipStudyCard() {
    state._studyFlipped = !state._studyFlipped;
    $("#studyCard").parentElement.classList.toggle("flipped");
  }
  function nextStudyCard() {
    state._studyIdx++;
    if (state._studyIdx >= state._studyCards.length) {
      closeModal();
      toast("All done!", "You reviewed all flashcards", "success");
      return;
    }
    state._studyFlipped = false;
    const c = state._studyCards[state._studyIdx];
    $("#modalTitle").textContent =
      `Card ${state._studyIdx + 1} of ${state._studyCards.length}`;
    $("#modalBody").innerHTML = `
      <div class="flashcard" onclick="App.flipStudyCard()">
        <div class="flashcard-inner" id="studyCard">
          <div class="flashcard-front"><div class="flashcard-question">${c.front}</div><div class="text-xs text-muted mt-3">Tap to reveal answer</div></div>
          <div class="flashcard-back"><div class="flashcard-answer">${c.back}</div></div>
        </div>
      </div>
    `;
  }

  function startPathPractice(groupId) {
    const path = Study.LEARNING_PATHS[groupId];
    if (!path) return;
    state.pathIdx = state.pathIdx || {};
    state.pathIdx[groupId] = 0;
    const topicId = path.path[state.pathIdx[groupId]];
    state.pathGroupId = groupId;
    toast(
      "Path Practice Started!",
      `Topic ${state.pathIdx[groupId] + 1}/${path.path.length}: ${Problems.getTopic(topicId).name}`,
      "info",
      4000,
    );
    startPractice(topicId, "easy");
  }

  // ============================================================
  // GAMES
  // ============================================================
  function renderGames() {
    content.innerHTML = `
      <div class="page-header">
        <h1>🎮 Games</h1>
        <p>Fun math games to sharpen your skills</p>
      </div>
      <div class="grid grid-3">
        <div class="card topic-card" onclick="App.startSpeedRound()">
          <div class="tc-icon">⚡</div>
          <div class="tc-title">Speed Round</div>
          <div class="tc-count">60 seconds, max questions</div>
        </div>
        <div class="card topic-card" onclick="App.startSurvival()">
          <div class="tc-icon">💀</div>
          <div class="tc-title">Survival</div>
          <div class="tc-count">3 lives, how long can you last?</div>
        </div>
        <div class="card topic-card" onclick="App.startMentalMath()">
          <div class="tc-icon">🧠</div>
          <div class="tc-title">Mental Math</div>
          <div class="tc-count">No paper, no calculator</div>
        </div>
        <div class="card topic-card" onclick="App.startTargetNumber()">
          <div class="tc-icon">🎯</div>
          <div class="tc-title">Target Number</div>
          <div class="tc-count">Reach the target with operations</div>
        </div>
        <div class="card topic-card" onclick="App.startMixed()">
          <div class="tc-icon">🌈</div>
          <div class="tc-title">Mixed Madness</div>
          <div class="tc-count">Random topics, random difficulty</div>
        </div>
        <div class="card topic-card" onclick="App.startEstimation()">
          <div class="tc-icon">📐</div>
          <div class="tc-title">Estimation</div>
          <div class="tc-count">Get close to the answer</div>
        </div>
        <div class="card topic-card" onclick="App.startDailyChallenge()">
          <div class="tc-icon">📅</div>
          <div class="tc-title">Daily Challenge</div>
          <div class="tc-count">Special problem of the day</div>
        </div>
        <div class="card topic-card" onclick="App.startMathBingo()">
          <div class="tc-icon">🎰</div>
          <div class="tc-title">Math Bingo</div>
          <div class="tc-count">Get 5 in a row</div>
        </div>
        <div class="card topic-card" onclick="App.startNumberChain()">
          <div class="tc-icon">🔗</div>
          <div class="tc-title">Number Chain</div>
          <div class="tc-count">Build sequences with rules</div>
        </div>
      </div>
    `;
  }

  function startSpeedRound() {
    state.gameSession = {
      mode: "speed",
      score: 0,
      correct: 0,
      timeLeft: 60,
      startTime: Date.now(),
    };
    state.currentMode = "game";
    content.innerHTML = `
      <div class="page-header">
        <button class="btn btn-sm btn-outline" onclick="App.exitGame()">← Exit</button>
        <h2 class="mt-2">⚡ Speed Round</h2>
      </div>
      <div class="practice-meta">
        <span class="meta-pill timer" id="gameTimer">⏱️ 60s</span>
        <span class="meta-pill score">✓ ${state.gameSession.correct}</span>
      </div>
      <div id="gameArea" class="card problem-display"></div>
    `;
    state.gameSession.timer = setInterval(() => {
      state.gameSession.timeLeft--;
      const t = $("#gameTimer");
      if (t) t.textContent = `⏱️ ${state.gameSession.timeLeft}s`;
      if (state.gameSession.timeLeft <= 0) endGame();
    }, 1000);
    nextGameProblem();
  }

  function startSurvival() {
    state.gameSession = { mode: "survival", lives: 3, correct: 0, streak: 0 };
    state.currentMode = "game";
    content.innerHTML = `
      <div class="page-header">
        <button class="btn btn-sm btn-outline" onclick="App.exitGame()">← Exit</button>
        <h2 class="mt-2">💀 Survival</h2>
      </div>
      <div class="practice-meta">
        <span class="meta-pill">❤️ ${"❤️".repeat(state.gameSession.lives)}</span>
        <span class="meta-pill score">✓ ${state.gameSession.correct}</span>
        <span class="meta-pill streak">🔥 ${state.gameSession.streak}</span>
      </div>
      <div id="gameArea" class="card problem-display"></div>
    `;
    nextGameProblem();
  }

  function startMentalMath() {
    state.gameSession = { mode: "mental", correct: 0, total: 0 };
    state.currentMode = "game";
    content.innerHTML = `
      <div class="page-header">
        <button class="btn btn-sm btn-outline" onclick="App.exitGame()">← Exit</button>
        <h2 class="mt-2">🧠 Mental Math</h2>
      </div>
      <div class="alert alert-info">No calculator, no paper. Solve in your head!</div>
      <div class="practice-meta">
        <span class="meta-pill score">✓ ${state.gameSession.correct}</span>
        <span class="meta-pill">Total: ${state.gameSession.total}</span>
      </div>
      <div id="gameArea" class="card problem-display"></div>
    `;
    nextGameProblem();
  }

  function startTargetNumber() {
    const target = R(50, 200);
    const nums = Array.from({ length: 5 }, () => R(1, 20));
    state.gameSession = { mode: "target", target, nums, used: [], current: 0 };
    state.currentMode = "game";
    content.innerHTML = `
      <div class="page-header">
        <button class="btn btn-sm btn-outline" onclick="App.exitGame()">← Exit</button>
        <h2 class="mt-2">🎯 Target Number</h2>
      </div>
      <div class="card text-center">
        <div class="card-title">Reach: <span class="text-primary" style="font-size:2rem">${target}</span></div>
        <div class="text-2xl mt-3">Current: <span id="targetCurrent">0</span></div>
        <div class="chip-row justify-center mt-4" id="targetNums">
          ${nums.map((n, i) => `<span class="chip" onclick="App.useNum(${i})" data-idx="${i}">${n}</span>`).join("")}
        </div>
        <div class="chip-row justify-center mt-3">
          <button class="chip" onclick="App.targetOp('+')">+</button>
          <button class="chip" onclick="App.targetOp('-')">−</button>
          <button class="chip" onclick="App.targetOp('×')">×</button>
          <button class="chip" onclick="App.targetOp('÷')">÷</button>
        </div>
        <button class="btn btn-outline mt-3" onclick="App.resetTarget()">Reset</button>
      </div>
    `;
  }

  let targetPendingOp = null;
  function useNum(idx) {
    const gs = state.gameSession;
    if (!gs || gs.mode !== "target") return;
    const chip = document.querySelector(`[data-idx="${idx}"]`);
    if (chip.classList.contains("disabled")) return;
    const n = gs.nums[idx];
    if (targetPendingOp === null) {
      gs.current = n;
    } else {
      gs.current = applyOp(gs.current, targetPendingOp, n);
      targetPendingOp = null;
    }
    chip.classList.add("disabled");
    chip.style.opacity = "0.4";
    $("#targetCurrent").textContent = gs.current;
    if (gs.current === gs.target) {
      toast("🎉 Target reached!", "You win!", "success");
      confetti();
      setTimeout(() => navigate("games"), 2000);
    }
  }
  function targetOp(op) {
    targetPendingOp = op;
    toast("Operation selected", op, "info", 1000);
  }
  function resetTarget() {
    startTargetNumber();
  }
  function applyOp(a, op, b) {
    if (op === "+") return a + b;
    if (op === "-") return a - b;
    if (op === "×") return a * b;
    if (op === "÷") return b !== 0 ? a / b : a;
    return a;
  }
  function R(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function startMixed() {
    state.gameSession = { mode: "mixed", correct: 0, total: 0, streak: 0 };
    state.currentMode = "game";
    content.innerHTML = `
      <div class="page-header">
        <button class="btn btn-sm btn-outline" onclick="App.exitGame()">← Exit</button>
        <h2 class="mt-2">🌈 Mixed Madness</h2>
      </div>
      <div class="practice-meta">
        <span class="meta-pill score">✓ ${state.gameSession.correct}</span>
        <span class="meta-pill streak">🔥 ${state.gameSession.streak}</span>
      </div>
      <div id="gameArea" class="card problem-display"></div>
    `;
    nextGameProblem();
  }

  function startEstimation() {
    state.gameSession = { mode: "estimation", correct: 0, total: 0 };
    state.currentMode = "game";
    nextGameProblem();
  }

  function startDailyChallenge() {
    const today = MMP.todayStr();
    const seed = today.split("-").reduce((a, b) => a + parseInt(b), 0);
    const topic = Problems.TOPICS[seed % Problems.TOPICS.length];
    const diff = ["easy", "medium", "hard", "expert"][seed % 4];
    state.gameSession = { mode: "daily", correct: 0, total: 0, date: today };
    state.currentMode = "game";
    state.selectedTopic = topic.id;
    state.selectedDifficulty = diff;
    nextGameProblem();
  }

  function startMathBingo() {
    toast("Coming soon!", "Math Bingo is being developed", "info");
  }
  function startNumberChain() {
    toast("Coming soon!", "Number Chain is being developed", "info");
  }

  function nextGameProblem() {
    const gs = state.gameSession;
    let topicId, diff;
    if (gs.mode === "mixed" || gs.mode === "survival") {
      const topic =
        Problems.TOPICS[Math.floor(Math.random() * Problems.TOPICS.length)];
      topicId = topic.id;
      diff = ["easy", "medium", "hard"][Math.floor(Math.random() * 3)];
    } else if (gs.mode === "mental") {
      const mentalTopics = [
        "add_basic",
        "sub_basic",
        "mul_basic",
        "mul_tables",
      ];
      topicId = mentalTopics[Math.floor(Math.random() * mentalTopics.length)];
      diff = "easy";
    } else if (gs.mode === "estimation") {
      const estTopics = ["mul_basic", "add_basic", "percentages"];
      topicId = estTopics[Math.floor(Math.random() * estTopics.length)];
      diff = "medium";
    } else if (gs.mode === "daily") {
      topicId = state.selectedTopic;
      diff = state.selectedDifficulty;
    } else {
      topicId = state.selectedTopic || Problems.TOPICS[0].id;
      diff = "easy";
    }
    const p = Problems.generate(topicId, diff);
    state.currentProblem = p;
    state.selectedTopic = topicId;
    state.selectedDifficulty = diff;
    const area = $("#gameArea");
    if (!area) return;
    area.innerHTML = `
      <div class="problem-text math">${p.question}</div>
      ${p.questionVisual ? `<div style="font-size:1.5rem;margin:8px 0">${p.questionVisual}</div>` : ""}
      <div id="answerArea" class="mt-3"></div>
      <div id="feedback" class="mt-3"></div>
    `;
    state.timerStart = Date.now();
    if (p.choices) renderChoices(p);
    else renderInput(p);
  }

  // Override answer for games
  const _origHandle = handleAnswer;
  function gameHandleAnswer(correct, given) {
    const gs = state.gameSession;
    if (!gs) {
      _origHandle(correct, given);
      return;
    }
    const timeSpent = Math.round((Date.now() - state.timerStart) / 1000);
    const result = MMP.recordAnswer({
      topic: state.selectedTopic,
      difficulty: state.selectedDifficulty,
      correct,
      timeSpent,
      mode: "game",
    });
    gs.correct += correct ? 1 : 0;
    gs.total = (gs.total || 0) + 1;
    if (gs.mode === "survival") {
      if (!correct) {
        gs.lives--;
        state.streak = 0;
        if (gs.lives <= 0) {
          endGame();
          return;
        }
      } else {
        state.streak++;
        gs.streak = state.streak;
      }
    } else if (gs.mode === "mental" || gs.mode === "mixed") {
      if (!correct) state.streak = 0;
      else state.streak++;
      gs.streak = state.streak;
    }
    // Update display
    const fb = $("#feedback");
    if (fb) {
      fb.innerHTML = correct
        ? `<div class="alert alert-success">✓ Correct! +${result.xp} XP</div>`
        : `<div class="alert alert-danger">✗ Correct: ${state.currentProblem.answer}</div>`;
    }
    playSound(correct ? "correct" : "wrong");
    vibrate(correct ? 50 : 200);
    updateTopbar();
    setTimeout(nextGameProblem, correct ? 700 : 1500);
  }

  function endGame() {
    if (state.gameSession?.timer) clearInterval(state.gameSession.timer);
    const gs = state.gameSession;
    if (!gs) return;
    const time = Math.round((Date.now() - (gs.startTime || Date.now())) / 1000);
    modal(
      "🎮 Game Over",
      `
      <div class="grid grid-2">
        <div class="stat-card"><div class="stat-value">${gs.correct}</div><div class="stat-label">Correct</div></div>
        <div class="stat-card"><div class="stat-value">${gs.total || gs.correct}</div><div class="stat-label">Total</div></div>
        ${gs.mode === "survival" ? `<div class="stat-card"><div class="stat-value">${gs.streak}</div><div class="stat-label">Best Streak</div></div>` : ""}
        ${gs.mode === "speed" ? `<div class="stat-card"><div class="stat-value">${time}s</div><div class="stat-label">Time</div></div>` : ""}
      </div>
    `,
      `<button class="btn btn-primary" onclick="App.closeModal();App.navigate('games')">Play Again</button>`,
    );
    if (gs.correct >= 10) confetti();
    state.gameSession = null;
  }
  function exitGame() {
    if (state.gameSession?.timer) clearInterval(state.gameSession.timer);
    state.gameSession = null;
    navigate("games");
  }

  // ============================================================
  // TOOLS
  // ============================================================
  function renderTools() {
    content.innerHTML = `
      <div class="page-header">
        <h1>🔧 Math Tools</h1>
        <p>Handy calculators and converters</p>
      </div>
      <div class="grid grid-3">
        <div class="card tool-card" onclick="App.toolCalculator()">🧮 Calculator</div>
        <div class="card tool-card" onclick="App.toolScientific()">🔬 Scientific Calculator</div>
        <div class="card tool-card" onclick="App.toolFracSimplifier()">📉 Fraction Simplifier</div>
        <div class="card tool-card" onclick="App.toolPercentCalc()">% Percentage Calculator</div>
        <div class="card tool-card" onclick="App.toolPrimeFactor()">🔢 Prime Factorization</div>
        <div class="card tool-card" onclick="App.toolGcdLcm()">🧮 GCD/LCM Calculator</div>
        <div class="card tool-card" onclick="App.toolTriangleSolver()">📐 Triangle Solver</div>
        <div class="card tool-card" onclick="App.toolNumberBase()">🔢 Number Base Converter</div>
        <div class="card tool-card" onclick="App.toolRoman()">📜 Roman Numeral Converter</div>
        <div class="card tool-card" onclick="App.toolUnitConverter()">📏 Unit Converter</div>
        <div class="card tool-card" onclick="App.toolStatsCalc()">📊 Statistics Calculator</div>
        <div class="card tool-card" onclick="App.toolConstants()">🔢 Math Constants</div>
        <div class="card tool-card" onclick="App.toolSymbols()">🔣 Math Symbols</div>
        <div class="card tool-card" onclick="App.toolFormulaSheet()">📐 Formula Sheet</div>
        <div class="card tool-card" onclick="App.toolQuadraticSolver()">📈 Quadratic Solver</div>
      </div>
    `;
  }

  function toolCalculator() {
    modal(
      "🧮 Calculator",
      `
      <div class="card">
        <input type="text" class="answer-input" id="calcDisplay" value="0" readonly style="max-width:100%;font-size:1.6rem;text-align:right" />
        <div class="numpad mt-3" style="max-width:none">
          ${[
            "C",
            "⌫",
            "%",
            "÷",
            7,
            8,
            9,
            "×",
            4,
            5,
            6,
            "−",
            1,
            2,
            3,
            "+",
            0,
            ".",
            "(",
            ")",
            "=",
          ]
            .map(
              (k) => `
            <button onclick="App.calcKey('${k}')" style="${["÷", "×", "−", "+", "="].includes(k) ? "background:var(--primary);color:white" : k === "C" ? "background:var(--danger);color:white" : ""}">${k}</button>
          `,
            )
            .join("")}
        </div>
      </div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function calcKey(k) {
    let v = state.calculatorValue;
    if (k === "C") v = "0";
    else if (k === "⌫") v = v.length > 1 ? v.slice(0, -1) : "0";
    else if (k === "=") {
      try {
        v = String(
          eval(v.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-")),
        );
      } catch {
        v = "Error";
      }
    } else if (["+", "−", "×", "÷", "%", ".", "(", ")"].includes(k))
      v = v === "0" ? k : v + k;
    else v = v === "0" ? k : v + k;
    state.calculatorValue = v;
    $("#calcDisplay").value = v;
  }
  function toolScientific() {
    modal(
      "🔬 Scientific Calculator",
      `
      <div class="card">
        <input type="text" class="answer-input" id="sciDisplay" value="0" readonly style="max-width:100%;font-size:1.4rem;text-align:right" />
        <div class="numpad mt-3" style="max-width:none;grid-template-columns: repeat(5, 1fr)">
          ${[
            "sin",
            "cos",
            "tan",
            "π",
            "e",
            "log",
            "ln",
            "√",
            "^",
            "!",
            "C",
            "⌫",
            "(",
            ")",
            "%",
            "÷",
            7,
            8,
            9,
            "×",
            "−",
            4,
            5,
            6,
            "+",
            "1",
            1,
            2,
            3,
            "0",
            ".",
            "=",
          ]
            .map(
              (k) => `
            <button onclick="App.sciKey('${k}')" style="padding:12px 0">${k}</button>
          `,
            )
            .join("")}
        </div>
      </div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function sciKey(k) {
    let v = state.calculatorValue;
    if (k === "C") v = "0";
    else if (k === "⌫") v = v.length > 1 ? v.slice(0, -1) : "0";
    else if (k === "=") {
      try {
        let expr = v
          .replace(/×/g, "*")
          .replace(/÷/g, "/")
          .replace(/−/g, "-")
          .replace(/π/g, "Math.PI")
          .replace(/e/g, "Math.E")
          .replace(/√/g, "Math.sqrt")
          .replace(/sin/g, "Math.sin")
          .replace(/cos/g, "Math.cos")
          .replace(/tan/g, "Math.tan")
          .replace(/log/g, "Math.log10")
          .replace(/ln/g, "Math.log")
          .replace(/\^/g, "**");
        expr = expr.replace(/(\d+)!/g, (_, n) => {
          let r = 1;
          for (let i = 2; i <= +n; i++) r *= i;
          return r;
        });
        v = String(eval(expr));
      } catch {
        v = "Error";
      }
    } else v = v === "0" ? k : v + k;
    state.calculatorValue = v;
    $("#sciDisplay").value = v;
  }
  function toolFracSimplifier() {
    modal(
      "📉 Fraction Simplifier",
      `
      <div class="form-group">
        <label class="form-label">Numerator</label>
        <input type="number" class="form-control" id="fracNum" />
      </div>
      <div class="form-group">
        <label class="form-label">Denominator</label>
        <input type="number" class="form-control" id="fracDen" />
      </div>
      <button class="btn btn-primary btn-block" onclick="App.calcFrac()">Simplify</button>
      <div id="fracResult" class="mt-3"></div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function calcFrac() {
    const n = parseInt($("#fracNum").value);
    const d = parseInt($("#fracDen").value);
    if (!n || !d) return;
    const g = Problems.gcd(Math.abs(n), Math.abs(d));
    $("#fracResult").innerHTML =
      `<div class="tool-output">${n}/${d} = ${n / g}/${d / g} = ${(n / d).toFixed(4)}</div>`;
  }
  function toolPercentCalc() {
    modal(
      "% Percentage Calculator",
      `
      <div class="form-group"><label class="form-label">What is</label><input type="number" class="form-control" id="pct1" /></div>
      <div class="form-group"><label class="form-label">% of</label><input type="number" class="form-control" id="pct2" /></div>
      <button class="btn btn-primary btn-block" onclick="App.calcPct()">Calculate</button>
      <div id="pctResult" class="mt-3"></div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function calcPct() {
    const a = parseFloat($("#pct1").value);
    const b = parseFloat($("#pct2").value);
    if (isNaN(a) || isNaN(b)) return;
    const r = (a / 100) * b;
    $("#pctResult").innerHTML =
      `<div class="tool-output">${a}% of ${b} = ${r}</div>`;
  }
  function toolPrimeFactor() {
    modal(
      "🔢 Prime Factorization",
      `
      <div class="form-group"><label class="form-label">Enter a number</label><input type="number" class="form-control" id="pfNum" /></div>
      <button class="btn btn-primary btn-block" onclick="App.calcPrimeFactor()">Factorize</button>
      <div id="pfResult" class="mt-3"></div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function calcPrimeFactor() {
    let n = parseInt($("#pfNum").value);
    if (!n || n < 2) {
      $("#pfResult").innerHTML =
        '<div class="alert alert-warning">Enter a number ≥ 2</div>';
      return;
    }
    const factors = [];
    let d = 2;
    while (n > 1) {
      while (n % d === 0) {
        factors.push(d);
        n /= d;
      }
      d++;
    }
    const counts = {};
    factors.forEach((f) => (counts[f] = (counts[f] || 0) + 1));
    const str = Object.entries(counts)
      .map(([p, e]) => (e > 1 ? `${p}^${e}` : p))
      .join(" × ");
    $("#pfResult").innerHTML =
      `<div class="tool-output">${$("#pfNum").value} = ${str}</div>`;
  }
  function toolGcdLcm() {
    modal(
      "🧮 GCD/LCM Calculator",
      `
      <div class="form-group"><label class="form-label">Number 1</label><input type="number" class="form-control" id="gl1" /></div>
      <div class="form-group"><label class="form-label">Number 2</label><input type="number" class="form-control" id="gl2" /></div>
      <button class="btn btn-primary btn-block" onclick="App.calcGcdLcm()">Calculate</button>
      <div id="glResult" class="mt-3"></div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function calcGcdLcm() {
    const a = parseInt($("#gl1").value),
      b = parseInt($("#gl2").value);
    if (!a || !b) return;
    const g = Problems.gcd(a, b),
      l = Problems.lcm(a, b);
    $("#glResult").innerHTML =
      `<div class="tool-output">GCD(${a}, ${b}) = ${g}<br>LCM(${a}, ${b}) = ${l}</div>`;
  }
  function toolTriangleSolver() {
    modal(
      "📐 Triangle Solver (Right Triangle)",
      `
      <div class="alert alert-info">For right triangles with legs a, b and hypotenuse c</div>
      <div class="form-group"><label class="form-label">Side a</label><input type="number" class="form-control" id="triA" /></div>
      <div class="form-group"><label class="form-label">Side b</label><input type="number" class="form-control" id="triB" /></div>
      <button class="btn btn-primary btn-block" onclick="App.calcTriangle()">Find Hypotenuse</button>
      <div id="triResult" class="mt-3"></div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function calcTriangle() {
    const a = parseFloat($("#triA").value),
      b = parseFloat($("#triB").value);
    if (!a || !b) return;
    const c = Math.sqrt(a * a + b * b);
    $("#triResult").innerHTML =
      `<div class="tool-output">c = √(${a}² + ${b}²) = √${a * a + b * b} = ${c.toFixed(4)}</div>`;
  }
  function toolNumberBase() {
    modal(
      "🔢 Number Base Converter",
      `
      <div class="form-group"><label class="form-label">Number</label><input type="text" class="form-control" id="nbNum" /></div>
      <div class="form-group"><label class="form-label">From base</label>
        <select class="form-control" id="nbFrom"><option value="10">Decimal (10)</option><option value="2">Binary (2)</option><option value="8">Octal (8)</option><option value="16">Hex (16)</option></select>
      </div>
      <button class="btn btn-primary btn-block" onclick="App.calcBase()">Convert</button>
      <div id="nbResult" class="mt-3"></div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function calcBase() {
    const n = $("#nbNum").value.trim();
    const from = parseInt($("#nbFrom").value);
    const dec = parseInt(n, from);
    if (isNaN(dec)) {
      $("#nbResult").innerHTML =
        '<div class="alert alert-danger">Invalid number</div>';
      return;
    }
    $("#nbResult").innerHTML = `<div class="tool-output">
      Decimal: ${dec}<br>
      Binary: ${dec.toString(2)}<br>
      Octal: ${dec.toString(8)}<br>
      Hex: ${dec.toString(16).toUpperCase()}
    </div>`;
  }
  function toolRoman() {
    modal(
      "📜 Roman Numeral Converter",
      `
      <div class="form-group"><label class="form-label">Number (1-3999)</label><input type="number" class="form-control" id="rnNum" min="1" max="3999" /></div>
      <button class="btn btn-primary btn-block" onclick="App.calcRoman()">Convert</button>
      <div id="rnResult" class="mt-3"></div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function calcRoman() {
    const n = parseInt($("#rnNum").value);
    if (!n || n < 1 || n > 3999) {
      $("#rnResult").innerHTML =
        '<div class="alert alert-warning">Enter 1-3999</div>';
      return;
    }
    const map = [
      [1000, "M"],
      [900, "CM"],
      [500, "D"],
      [400, "CD"],
      [100, "C"],
      [90, "XC"],
      [50, "L"],
      [40, "XL"],
      [10, "X"],
      [9, "IX"],
      [5, "V"],
      [4, "IV"],
      [1, "I"],
    ];
    let r = "",
      x = n;
    for (const [v, s] of map)
      while (x >= v) {
        r += s;
        x -= v;
      }
    $("#rnResult").innerHTML = `<div class="tool-output">${n} = ${r}</div>`;
  }
  function toolUnitConverter() {
    modal(
      "📏 Unit Converter",
      `
      <div class="form-group"><label class="form-label">Value</label><input type="number" class="form-control" id="ucVal" value="1" /></div>
      <div class="form-group"><label class="form-label">From</label>
        <select class="form-control" id="ucFrom">
          <optgroup label="Length">
            <option value="m,1">meter</option><option value="cm,0.01">centimeter</option><option value="km,1000">kilometer</option><option value="inch,0.0254">inch</option><option value="ft,0.3048">foot</option><option value="mile,1609.34">mile</option>
          </optgroup>
          <optgroup label="Weight">
            <option value="kg,1">kilogram</option><option value="g,0.001">gram</option><option value="lb,0.453592">pound</option><option value="oz,0.0283495">ounce</option>
          </optgroup>
        </select>
      </div>
      <div class="form-group"><label class="form-label">To</label>
        <select class="form-control" id="ucTo">
          <optgroup label="Length">
            <option value="m,1">meter</option><option value="cm,0.01">centimeter</option><option value="km,1000">kilometer</option><option value="inch,0.0254">inch</option><option value="ft,0.3048">foot</option><option value="mile,1609.34">mile</option>
          </optgroup>
        </select>
      </div>
      <button class="btn btn-primary btn-block" onclick="App.calcUnit()">Convert</button>
      <div id="ucResult" class="mt-3"></div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function calcUnit() {
    const v = parseFloat($("#ucVal").value);
    const [fu, fm] = $("#ucFrom").value.split(",");
    const [tu, tm] = $("#ucTo").value.split(",");
    const meters = v * parseFloat(fm);
    const result = meters / parseFloat(tm);
    $("#ucResult").innerHTML =
      `<div class="tool-output">${v} ${fu} = ${result.toFixed(4)} ${tu}</div>`;
  }
  function toolStatsCalc() {
    modal(
      "📊 Statistics Calculator",
      `
      <div class="form-group"><label class="form-label">Numbers (comma-separated)</label><input type="text" class="form-control" id="stNums" placeholder="1, 2, 3, 4, 5" /></div>
      <button class="btn btn-primary btn-block" onclick="App.calcStats()">Calculate</button>
      <div id="stResult" class="mt-3"></div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function calcStats() {
    const arr = $("#stNums")
      .value.split(",")
      .map((s) => parseFloat(s.trim()))
      .filter((x) => !isNaN(x));
    if (arr.length < 2) {
      $("#stResult").innerHTML =
        '<div class="alert alert-warning">Enter at least 2 numbers</div>';
      return;
    }
    const n = arr.length;
    const sum = arr.reduce((a, b) => a + b, 0);
    const mean = sum / n;
    const sorted = arr.slice().sort((a, b) => a - b);
    const median =
      n % 2 ? sorted[(n - 1) / 2] : (sorted[n / 2 - 1] + sorted[n / 2]) / 2;
    const counts = {};
    arr.forEach((x) => (counts[x] = (counts[x] || 0) + 1));
    const maxC = Math.max(...Object.values(counts));
    const mode =
      maxC > 1 ? Object.keys(counts).find((k) => counts[k] === maxC) : "None";
    const variance = arr.reduce((s, x) => s + (x - mean) ** 2, 0) / n;
    const sd = Math.sqrt(variance);
    $("#stResult").innerHTML = `<div class="tool-output">
      Count: ${n}<br>Sum: ${sum}<br>Mean: ${mean.toFixed(4)}<br>Median: ${median}<br>Mode: ${mode}<br>Min: ${sorted[0]}<br>Max: ${sorted[n - 1]}<br>Range: ${sorted[n - 1] - sorted[0]}<br>Variance: ${variance.toFixed(4)}<br>Std Dev: ${sd.toFixed(4)}
    </div>`;
  }
  function toolConstants() {
    const consts = [
      { name: "π (Pi)", val: "3.14159265...", use: "Circles, trigonometry" },
      { name: "e (Euler)", val: "2.71828183...", use: "Calculus, growth" },
      { name: "φ (Golden ratio)", val: "1.61803399...", use: "Art, nature" },
      { name: "√2", val: "1.41421356...", use: "Geometry" },
      { name: "√3", val: "1.73205081...", use: "Geometry" },
      { name: "ln(2)", val: "0.69314718...", use: "Logarithms" },
      {
        name: "γ (Euler-Mascheroni)",
        val: "0.57721566...",
        use: "Number theory",
      },
      { name: "τ (Tau = 2π)", val: "6.28318531...", use: "Alternative to π" },
      { name: "c (speed of light)", val: "299,792,458 m/s", use: "Physics" },
      { name: "G (gravitational)", val: "6.674×10⁻¹¹", use: "Physics" },
    ];
    modal(
      "🔢 Math Constants",
      `
      <table class="table">
        <tr><th>Constant</th><th>Value</th><th>Used in</th></tr>
        ${consts.map((c) => `<tr><td><strong>${c.name}</strong></td><td>${c.val}</td><td class="text-muted">${c.use}</td></tr>`).join("")}
      </table>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function toolSymbols() {
    const syms = [
      { s: "+", n: "Plus" },
      { s: "−", n: "Minus" },
      { s: "×", n: "Multiply" },
      { s: "÷", n: "Divide" },
      { s: "=", n: "Equals" },
      { s: "≠", n: "Not equal" },
      { s: "<", n: "Less than" },
      { s: ">", n: "Greater than" },
      { s: "≤", n: "Less or equal" },
      { s: "≥", n: "Greater or equal" },
      { s: "≈", n: "Approximately" },
      { s: "√", n: "Square root" },
      { s: "∛", n: "Cube root" },
      { s: "xⁿ", n: "Power" },
      { s: "log", n: "Logarithm" },
      { s: "ln", n: "Natural log" },
      { s: "∫", n: "Integral" },
      { s: "d/dx", n: "Derivative" },
      { s: "∞", n: "Infinity" },
      { s: "π", n: "Pi" },
      { s: "Σ", n: "Sum" },
      { s: "Π", n: "Product" },
      { s: "θ", n: "Theta (angle)" },
      { s: "°", n: "Degree" },
      { s: "∠", n: "Angle" },
      { s: "⊥", n: "Perpendicular" },
      { s: "∥", n: "Parallel" },
      { s: "△", n: "Triangle" },
      { s: "◯", n: "Circle" },
      { s: "∴", n: "Therefore" },
      { s: "∵", n: "Because" },
      { s: "∈", n: "Element of" },
      { s: "∉", n: "Not element of" },
      { s: "⊂", n: "Subset" },
      { s: "∪", n: "Union" },
      { s: "∩", n: "Intersection" },
      { s: "∀", n: "For all" },
      { s: "∃", n: "There exists" },
      { s: "→", n: "Implies" },
      { s: "⇔", n: "If and only if" },
    ];
    modal(
      "🔣 Math Symbols",
      `
      <div class="grid grid-3">
        ${syms.map((s) => `<div class="card" style="text-align:center;padding:14px"><div style="font-size:1.6rem;font-family:var(--font-math)">${s.s}</div><div class="text-xs text-muted">${s.n}</div></div>`).join("")}
      </div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function toolFormulaSheet() {
    navigate("study", { tab: "formulas" });
    closeModal();
  }
  function toolQuadraticSolver() {
    modal(
      "📈 Quadratic Equation Solver",
      `
      <div class="alert alert-info">Solves ax² + bx + c = 0</div>
      <div class="grid grid-3">
        <div><label class="form-label">a</label><input type="number" class="form-control" id="qdA" value="1" /></div>
        <div><label class="form-label">b</label><input type="number" class="form-control" id="qdB" value="0" /></div>
        <div><label class="form-label">c</label><input type="number" class="form-control" id="qdC" value="0" /></div>
      </div>
      <button class="btn btn-primary btn-block mt-3" onclick="App.calcQuadratic()">Solve</button>
      <div id="qdResult" class="mt-3"></div>
    `,
      `<button class="btn btn-outline" onclick="App.closeModal()">Close</button>`,
    );
  }
  function calcQuadratic() {
    const a = parseFloat($("#qdA").value),
      b = parseFloat($("#qdB").value),
      c = parseFloat($("#qdC").value);
    if (a === 0) {
      $("#qdResult").innerHTML =
        '<div class="alert alert-warning">a cannot be 0</div>';
      return;
    }
    const disc = b * b - 4 * a * c;
    let result;
    if (disc < 0) result = "No real solutions (discriminant < 0)";
    else if (disc === 0)
      result = `One solution: x = ${(-b / (2 * a)).toFixed(4)}`;
    else {
      const s = Math.sqrt(disc);
      result = `Two solutions: x = ${((-b + s) / (2 * a)).toFixed(4)}, x = ${((-b - s) / (2 * a)).toFixed(4)}`;
    }
    $("#qdResult").innerHTML =
      `<div class="tool-output">Equation: ${a}x² + ${b}x + ${c} = 0<br>Discriminant: ${disc}<br>${result}</div>`;
  }

  // ============================================================
  // STATS / DASHBOARD
  // ============================================================
  function renderStats() {
    const s = MMP.stats;
    const acc = s.totalAttempted
      ? Math.round((s.totalCorrect / s.totalAttempted) * 100)
      : 0;
    const timeMin = Math.round(s.totalTimeSpent / 60);
    const days = Object.keys(s.byDay).sort();
    const last7 = days.slice(-7);
    content.innerHTML = `
      <div class="page-header">
        <h1>📊 Statistics Dashboard</h1>
        <p>Your comprehensive math progress overview</p>
      </div>

      <div class="grid grid-4 mb-4">
        <div class="card stat-card"><div class="stat-value">${s.totalAttempted}</div><div class="stat-label">Total Attempted</div></div>
        <div class="card stat-card"><div class="stat-value">${s.totalCorrect}</div><div class="stat-label">Total Correct</div></div>
        <div class="card stat-card"><div class="stat-value">${acc}%</div><div class="stat-label">Accuracy</div></div>
        <div class="card stat-card"><div class="stat-value">${s.totalXp}</div><div class="stat-label">Total XP</div></div>
        <div class="card stat-card"><div class="stat-value">${s.bestStreak}</div><div class="stat-label">Best Streak</div></div>
        <div class="card stat-card"><div class="stat-value">${timeMin}m</div><div class="stat-label">Time Practiced</div></div>
        <div class="card stat-card"><div class="stat-value">${MMP.profile.streak}</div><div class="stat-label">Day Streak</div></div>
        <div class="card stat-card"><div class="stat-value">${Object.keys(s.topicsAttempted).length}</div><div class="stat-label">Topics Tried</div></div>
      </div>

      <div class="grid grid-2 mb-4">
        <div class="card">
          <div class="card-title">📈 Last 7 Days Activity</div>
          ${
            last7.length
              ? `
            <div class="chart-container mt-3">
              <svg viewBox="0 0 300 200" style="width:100%;height:100%">
                ${(() => {
                  const max = Math.max(
                    1,
                    ...last7.map((d) => s.byDay[d]?.a || 0),
                  );
                  return last7
                    .map((d, i) => {
                      const v = s.byDay[d]?.a || 0;
                      const c = s.byDay[d]?.c || 0;
                      const h = (v / max) * 160;
                      const x = 30 + i * 38;
                      return `
                      <rect x="${x}" y="${180 - h}" width="30" height="${h}" fill="var(--primary)" opacity="0.7" />
                      <rect x="${x}" y="${180 - h * (c / Math.max(v, 1))}" width="30" height="${h * (c / Math.max(v, 1))}" fill="var(--success)" />
                      <text x="${x + 15}" y="195" text-anchor="middle" font-size="10" fill="var(--text-muted)">${d.slice(5)}</text>
                      <text x="${x + 15}" y="${175 - h}" text-anchor="middle" font-size="10" fill="var(--text)">${v}</text>
                    `;
                    })
                    .join("");
                })()}
              </svg>
            </div>
            <div class="text-xs text-muted mt-2">Green = correct, Indigo = total</div>
          `
              : '<div class="text-muted text-center">No data yet</div>'
          }
        </div>
        <div class="card">
          <div class="card-title">🎯 Difficulty Performance</div>
          ${Object.entries(s.difficultyStats)
            .map(([d, st]) => {
              const acc = st.a ? Math.round((st.c / st.a) * 100) : 0;
              return `
              <div class="mb-3">
                <div class="flex justify-between text-sm"><span class="font-bold">${d}</span><span>${st.c}/${st.a} (${acc}%)</span></div>
                <div class="progress-bar mt-1"><div class="progress-fill" style="width:${acc}%;background:${acc >= 70 ? "var(--success)" : acc >= 40 ? "var(--warning)" : "var(--danger)"}"></div></div>
              </div>
            `;
            })
            .join("")}
        </div>
      </div>

      <div class="grid grid-2 mb-4">
        <div class="card">
          <div class="card-title">🏆 Top Topics (by attempts)</div>
          ${
            Object.entries(s.topicsAttempted)
              .sort((a, b) => b[1] - a[1])
              .slice(0, 10)
              .map(([tid, a]) => {
                const c = s.topicsCorrect[tid] || 0;
                const t = Problems.getTopic(tid);
                const acc = Math.round((c / a) * 100);
                return `
              <div class="mb-2">
                <div class="flex justify-between text-sm">
                  <span>${t?.icon || ""} ${t?.name || tid}</span>
                  <span>${c}/${a} (${acc}%)</span>
                </div>
                <div class="progress-bar mt-1"><div class="progress-fill" style="width:${acc}%"></div></div>
              </div>
            `;
              })
              .join("") ||
            '<div class="text-muted text-center">No topics attempted yet</div>'
          }
        </div>
        <div class="card">
          <div class="card-title">💪 Strongest Topics (by accuracy)</div>
          ${
            Object.entries(s.topicsAttempted)
              .filter(([_, a]) => a >= 3)
              .sort((a, b) => {
                const aAcc = (s.topicsCorrect[a[0]] || 0) / a[1];
                const bAcc = (s.topicsCorrect[b[0]] || 0) / b[1];
                return bAcc - aAcc;
              })
              .slice(0, 10)
              .map(([tid, a]) => {
                const c = s.topicsCorrect[tid] || 0;
                const t = Problems.getTopic(tid);
                const acc = Math.round((c / a) * 100);
                return `
              <div class="mb-2">
                <div class="flex justify-between text-sm">
                  <span>${t?.icon || ""} ${t?.name || tid}</span>
                  <span>${acc}%</span>
                </div>
                <div class="progress-bar mt-1"><div class="progress-fill" style="width:${acc}%;background:var(--success)"></div></div>
              </div>
            `;
              })
              .join("") ||
            '<div class="text-muted text-center">Practice more to see your strengths</div>'
          }
        </div>
      </div>

      <div class="grid grid-2 mb-4">
        <div class="card">
          <div class="card-title">⚠️ Areas to Improve (lowest accuracy)</div>
          ${
            Object.entries(s.topicsAttempted)
              .filter(([_, a]) => a >= 3)
              .sort((a, b) => {
                const aAcc = (s.topicsCorrect[a[0]] || 0) / a[1];
                const bAcc = (s.topicsCorrect[b[0]] || 0) / b[1];
                return aAcc - bAcc;
              })
              .slice(0, 5)
              .map(([tid, a]) => {
                const c = s.topicsCorrect[tid] || 0;
                const t = Problems.getTopic(tid);
                const acc = Math.round((c / a) * 100);
                return `
              <div class="mb-2">
                <div class="flex justify-between text-sm">
                  <span>${t?.icon || ""} ${t?.name || tid}</span>
                  <span>${acc}%</span>
                </div>
                <div class="progress-bar mt-1"><div class="progress-fill" style="width:${acc}%;background:var(--danger)"></div></div>
                <button class="btn btn-sm btn-outline mt-1" onclick="App.openTopic('${tid}')">Practice →</button>
              </div>
            `;
              })
              .join("") ||
            '<div class="text-muted text-center">Not enough data</div>'
          }
        </div>
        <div class="card">
          <div class="card-title">📅 Activity Heatmap (last 28 days)</div>
          <div class="heatmap" id="heatmap">
            ${(() => {
              const today = new Date();
              let html = "";
              for (let i = 27; i >= 0; i--) {
                const d = new Date(today);
                d.setDate(d.getDate() - i);
                const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
                const count = s.byDay[key]?.a || 0;
                const lvl =
                  count === 0
                    ? 0
                    : count < 5
                      ? 1
                      : count < 10
                        ? 2
                        : count < 20
                          ? 3
                          : count < 40
                            ? 4
                            : 5;
                html += `<div class="heat-cell ${lvl ? "lvl-" + lvl : ""}" title="${key}: ${count} attempts"></div>`;
              }
              return html;
            })()}
          </div>
          <div class="text-xs text-muted mt-2">Less → More activity</div>
        </div>
      </div>

      <div class="card">
        <div class="card-title">📊 Mode Performance</div>
        <table class="table">
          <tr><th>Mode</th><th>Attempted</th><th>Correct</th><th>Accuracy</th></tr>
          ${Object.entries(s.byMode)
            .map(([m, st]) => {
              if (typeof st === "number")
                return `<tr><td>${m}</td><td>${st}</td><td>—</td><td>—</td></tr>`;
              const acc = st.a ? Math.round((st.c / st.a) * 100) : 0;
              return `<tr><td>${m}</td><td>${st.a}</td><td>${st.c}</td><td>${acc}%</td></tr>`;
            })
            .join("")}
        </table>
      </div>

      <div class="card mt-4">
        <div class="card-title">💾 Data Management</div>
        <div class="flex gap-2" style="flex-wrap:wrap">
          <button class="btn btn-outline" onclick="App.exportData()">📥 Export Data</button>
          <button class="btn btn-outline" onclick="App.importData()">📤 Import Data</button>
          <button class="btn btn-outline" onclick="App.shareProgress()">🔗 Share Progress</button>
          <button class="btn btn-danger" onclick="App.resetProgress()">🗑️ Reset All Progress</button>
        </div>
      </div>
    `;
  }

  function exportData() {
    const data = MMP.exportData();
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `mathmaster-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast("Exported!", "Your data has been downloaded", "success");
  }
  function importData() {
    const inp = document.createElement("input");
    inp.type = "file";
    inp.accept = ".json";
    inp.onchange = (e) => {
      const f = e.target.files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        try {
          const data = JSON.parse(ev.target.result);
          if (MMP.importData(data)) {
            toast("Imported!", "Data restored successfully", "success");
            updateTopbar();
            navigate("home");
          } else toast("Import failed", "Invalid file", "danger");
        } catch (e) {
          toast("Import failed", e.message, "danger");
        }
      };
      reader.readAsText(f);
    };
    inp.click();
  }
  function shareProgress() {
    const text = `I've solved ${MMP.stats.totalCorrect} math problems on MathMaster Pro! Level ${MMP.profile.level}, ${MMP.profile.title}, ${MMP.profile.streak}-day streak. 🧮`;
    if (navigator.share)
      navigator.share({ title: "My MathMaster Progress", text });
    else {
      navigator.clipboard?.writeText(text);
      toast("Copied!", "Progress text copied to clipboard", "success");
    }
  }
  function resetProgress() {
    if (
      !confirm(
        "Are you sure? This will erase ALL your progress, achievements, and settings. This cannot be undone!",
      )
    )
      return;
    if (
      !confirm("Last warning! All data will be permanently deleted. Continue?")
    )
      return;
    MMP.resetProgress();
    toast("Reset complete", "All data has been cleared", "warning");
    updateTopbar();
    navigate("home");
  }

  // ============================================================
  // ACHIEVEMENTS
  // ============================================================
  function renderAchievements() {
    content.innerHTML = `
      <div class="page-header">
        <h1>🏅 Achievements</h1>
        <p>${MMP.achievements.length} of ${MMP.ACHIEVEMENTS.length} unlocked</p>
      </div>
      <div class="progress-bar mb-4"><div class="progress-fill" style="width:${(MMP.achievements.length / MMP.ACHIEVEMENTS.length) * 100}%"></div></div>
      <div class="grid grid-3">
        ${MMP.ACHIEVEMENTS.map((a) => {
          const unlocked = MMP.achievements.includes(a.id);
          return `
            <div class="card achievement-card ${unlocked ? "unlocked" : ""}">
              <div class="achievement-icon">${a.icon}</div>
              <div class="achievement-name">${a.name}</div>
              <div class="achievement-desc">${a.desc}</div>
              ${unlocked ? '<div class="badge badge-success mt-2">Unlocked</div>' : '<div class="badge mt-2">Locked</div>'}
            </div>
          `;
        }).join("")}
      </div>
    `;
  }

  // ============================================================
  // WORKSHEET GENERATOR
  // ============================================================
  function renderWorksheet() {
    content.innerHTML = `
      <div class="page-header">
        <h1>🖨️ Worksheet Generator</h1>
        <p>Create printable practice worksheets</p>
      </div>
      <div class="card mb-4">
        <div class="card-title">Worksheet Settings</div>
        <div class="form-group">
          <label class="form-label">Topic</label>
          <select class="form-control" id="wsTopic">
            ${Problems.TOPICS.map((t) => `<option value="${t.id}">${t.icon} ${t.name}</option>`).join("")}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Difficulty</label>
          <select class="form-control" id="wsDiff">
            <option value="easy">🟢 Easy</option>
            <option value="medium">🟡 Medium</option>
            <option value="hard">🔴 Hard</option>
            <option value="expert">🟣 Expert</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Number of problems</label>
          <select class="form-control" id="wsCount">
            <option value="10">10</option>
            <option value="20" selected>20</option>
            <option value="30">30</option>
            <option value="50">50</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Format</label>
          <select class="form-control" id="wsFormat">
            <option value="problems">Problems only</option>
            <option value="answers">Answers only</option>
            <option value="both" selected>Problems + Answers</option>
          </select>
        </div>
        <button class="btn btn-primary btn-block btn-lg" onclick="App.generateWorksheet()">🖨️ Generate Worksheet</button>
      </div>
      <div id="worksheetPreview"></div>
    `;
  }

  function generateWorksheet() {
    const topicId = $("#wsTopic").value;
    const diff = $("#wsDiff").value;
    const count = parseInt($("#wsCount").value);
    const format = $("#wsFormat").value;
    const topic = Problems.getTopic(topicId);
    const problems = Array.from({ length: count }, () =>
      Problems.generate(topicId, diff),
    );
    MMP.stats.worksheetGenerated++;
    MMP.persist.stats();
    const html = `
      <div class="card" id="printableWorksheet">
        <div style="text-align:center;border-bottom:2px solid var(--text);padding-bottom:12px;margin-bottom:16px">
          <h2>${topic.icon} ${topic.name} Worksheet</h2>
          <p class="text-muted">${count} problems · ${diff} difficulty · Generated ${new Date().toLocaleDateString()}</p>
          <p class="text-muted">Name: _______________  Date: __________</p>
        </div>
        ${
          format !== "answers"
            ? `
          <ol style="padding-left:24px">
            ${problems.map((p, i) => `<li style="padding:6px 0">${p.question} ${p.choices ? `<div style="margin-left:20px;font-size:0.9em">${p.choices.map((c) => `□ ${c}`).join("   ")}</div>` : '<div style="display:inline-block;border-bottom:1px solid var(--text);width:120px;margin-left:8px"></div>'}</li>`).join("")}
          </ol>
        `
            : ""
        }
        ${
          format !== "problems"
            ? `
          <div style="margin-top:24px;border-top:2px solid var(--text);padding-top:12px">
            <h3>Answer Key</h3>
            <ol style="padding-left:24px">
              ${problems.map((p) => `<li>${p.answer}</li>`).join("")}
            </ol>
          </div>
        `
            : ""
        }
      </div>
      <div class="text-center mt-3 mb-4">
        <button class="btn btn-primary" onclick="window.print()">🖨️ Print</button>
        <button class="btn btn-outline" onclick="App.generateWorksheet()">🔄 Regenerate</button>
      </div>
    `;
    $("#worksheetPreview").innerHTML = html;
  }

  // ============================================================
  // SETTINGS
  // ============================================================
  function renderSettings() {
    const s = MMP.settings;
    content.innerHTML = `
      <div class="page-header">
        <h1>⚙️ Settings</h1>
        <p>Customize your MathMaster experience</p>
      </div>

      <div class="card mb-4">
        <div class="card-title">👤 Profile</div>
        <div class="form-group">
          <label class="form-label">Name</label>
          <input type="text" class="form-control" id="setName" value="${MMP.profile.name}" />
        </div>
        <div class="form-group">
          <label class="form-label">Avatar</label>
          <div class="chip-row">
            ${[
              "🦊",
              "🐼",
              "🦁",
              "🐯",
              "🦉",
              "🐺",
              "🐸",
              "🦄",
              "🐉",
              "🤖",
              "👻",
              "🌟",
              "🧠",
              "🎯",
              "🚀",
              "💎",
            ]
              .map(
                (a) => `
              <span class="chip ${MMP.profile.avatar === a ? "active" : ""}" onclick="App.setAvatar('${a}', this)">${a}</span>
            `,
              )
              .join("")}
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Daily Goal: <span class="range-value" id="goalVal">${MMP.profile.dailyGoal}</span> questions</label>
          <input type="range" class="range-input" min="5" max="100" step="5" value="${MMP.profile.dailyGoal}" oninput="App.setGoal(this.value)" />
        </div>
        <button class="btn btn-primary" onclick="App.saveProfile()">Save Profile</button>
      </div>

      <div class="card mb-4">
        <div class="card-title">🎨 Appearance</div>
        <div class="form-group">
          <label class="form-label">Theme</label>
          <div class="chip-row">
            <span class="chip ${s.theme === "light" ? "active" : ""}" onclick="App.setSetting('theme','light', this)">☀️ Light</span>
            <span class="chip ${s.theme === "dark" ? "active" : ""}" onclick="App.setSetting('theme','dark', this)">🌙 Dark</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Color</label>
          <div class="chip-row">
            ${["indigo", "emerald", "rose", "blue", "purple", "teal", "orange"]
              .map(
                (c) => `
              <span class="chip ${s.color === c ? "active" : ""}" onclick="App.setSetting('color','${c}', this)" style="background:${{ indigo: "#4f46e5", emerald: "#10b981", rose: "#e11d48", blue: "#2563eb", purple: "#9333ea", teal: "#0d9488", orange: "#ea580c" }[c]};${s.color === c ? "color:white" : ""}">${c}</span>
            `,
              )
              .join("")}
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Font Size</label>
          <div class="chip-row">
            <span class="chip ${s.fontSize === "small" ? "active" : ""}" onclick="App.setSetting('fontSize','small', this)">A Small</span>
            <span class="chip ${s.fontSize === "medium" ? "active" : ""}" onclick="App.setSetting('fontSize','medium', this)">A Medium</span>
            <span class="chip ${s.fontSize === "large" ? "active" : ""}" onclick="App.setSetting('fontSize','large', this)">A Large</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">High Contrast</label>
          <label class="toggle">
            <input type="checkbox" ${s.contrast === "high" ? "checked" : ""} onchange="App.setSetting('contrast', this.checked?'high':'normal')" />
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>

      <div class="card mb-4">
        <div class="card-title">🔊 Audio & Feedback</div>
        ${toggleRow("Sound effects", "sound", s.sound)}
        ${toggleRow("Background music", "music", s.music)}
        ${toggleRow("Haptic feedback (vibration)", "haptics", s.haptics)}
        ${toggleRow("Animations", "animations", s.animations)}
      </div>

      <div class="card mb-4">
        <div class="card-title">✏️ Practice Preferences</div>
        ${toggleRow("Auto-advance to next question", "autoNext", s.autoNext)}
        ${toggleRow("Show hints", "showHints", s.showHints)}
        ${toggleRow("Show timer", "showTimer", s.showTimer)}
        ${toggleRow("Show solution steps after wrong answer", "showSteps", s.showSteps)}
        ${toggleRow("Adaptive difficulty (auto-adjust based on performance)", "adaptive", s.adaptive)}
        ${toggleRow("Auto-save progress", "autoSave", s.autoSave)}
        ${toggleRow("Keyboard shortcuts", "keyboardShortcuts", s.keyboardShortcuts)}
        <div class="form-group">
          <label class="form-label">Default question format</label>
          <select class="form-control" onchange="App.setSetting('questionFormat', this.value)">
            <option value="mcq" ${s.questionFormat === "mcq" ? "selected" : ""}>Multiple Choice</option>
            <option value="input" ${s.questionFormat === "input" ? "selected" : ""}>Type Answer</option>
            <option value="truefalse" ${s.questionFormat === "truefalse" ? "selected" : ""}>True/False</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Pass score for quizzes: <span class="range-value" id="passVal">${s.passScore}%</span></label>
          <input type="range" class="range-input" min="50" max="100" step="5" value="${s.passScore}" oninput="App.setPassScore(this.value)" />
        </div>
      </div>

      <div class="card mb-4">
        <div class="card-title">🌐 Language & Region</div>
        <div class="form-group">
          <label class="form-label">Language</label>
          <select class="form-control" onchange="App.setSetting('language', this.value)">
            <option value="en" ${s.language === "en" ? "selected" : ""}>English</option>
            <option value="hi" ${s.language === "hi" ? "selected" : ""}>हिन्दी (Hindi)</option>
            <option value="es" ${s.language === "es" ? "selected" : ""}>Español</option>
            <option value="fr" ${s.language === "fr" ? "selected" : ""}>Français</option>
            <option value="de" ${s.language === "de" ? "selected" : ""}>Deutsch</option>
            <option value="zh" ${s.language === "zh" ? "selected" : ""}>中文</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Number format</label>
          <select class="form-control" onchange="App.setSetting('numberFormat', this.value)">
            <option value="western" ${s.numberFormat === "western" ? "selected" : ""}>1,234.56 (Western)</option>
            <option value="indian" ${s.numberFormat === "indian" ? "selected" : ""}>1,23,456.78 (Indian)</option>
            <option value="european" ${s.numberFormat === "european" ? "selected" : ""}>1.234,56 (European)</option>
          </select>
        </div>
      </div>

      <div class="card mb-4">
        <div class="card-title">⌨️ Keyboard Shortcuts</div>
        <table class="table">
          <tr><th>Enter</th><td>Submit answer / Next question</td></tr>
          <tr><th>1-4</th><td>Select choice 1-4 in MCQ</td></tr>
          <tr><th>H</th><td>Show hint</td></tr>
          <tr><th>S</th><td>Show solution steps</td></tr>
          <tr><th>N</th><td>Skip question</td></tr>
          <tr><th>Esc</th><td>Close modal</td></tr>
          <tr><th>Ctrl+K</th><td>Open search</td></tr>
        </table>
      </div>

      <div class="card mb-4">
        <div class="card-title">ℹ️ About</div>
        <p><strong>MathMaster Pro</strong> v1.0.0</p>
        <p class="text-muted">A comprehensive math practice software with 200+ features for students from Class 1 to College. Practice unlimited levels across 100+ math topics, study materials, games, tools, and more.</p>
        <p class="text-muted mt-2">All your data is stored locally on your device. No account needed, no data sent to servers.</p>
      </div>

      <div class="card">
        <div class="card-title">⚠️ Danger Zone</div>
        <div class="flex gap-2" style="flex-wrap:wrap">
          <button class="btn btn-outline" onclick="App.resetSettings()">Reset Settings</button>
          <button class="btn btn-danger" onclick="App.resetProgress()">Reset All Progress</button>
        </div>
      </div>
    `;
  }

  function toggleRow(label, key, val) {
    return `
      <div class="flex justify-between items-center" style="padding:8px 0;border-bottom:1px solid var(--border)">
        <span>${label}</span>
        <label class="toggle">
          <input type="checkbox" ${val ? "checked" : ""} onchange="App.setSetting('${key}', this.checked)" />
          <span class="toggle-slider"></span>
        </label>
      </div>
    `;
  }
  function setSetting(key, val, btn) {
    MMP.settings[key] = val;
    MMP.persist.settings();
    applySettings();
    if (btn) {
      $$(`.chip`).forEach((c) => c.classList.remove("active"));
      btn.classList.add("active");
    }
    toast("Saved", `${key} updated`, "success", 1500);
  }
  function setAvatar(a, btn) {
    MMP.profile.avatar = a;
    MMP.persist.profile();
    $$(".chip").forEach((c) => c.classList.remove("active"));
    btn.classList.add("active");
  }
  function setGoal(v) {
    $("#goalVal").textContent = v;
    MMP.profile.dailyGoal = parseInt(v);
    MMP.persist.profile();
  }
  function setPassScore(v) {
    $("#passVal").textContent = v + "%";
    MMP.settings.passScore = parseInt(v);
    MMP.persist.settings();
  }
  function saveProfile() {
    MMP.profile.name = $("#setName").value.trim() || "Learner";
    MMP.persist.profile();
    toast("Profile saved!", "Your changes are saved", "success");
    updateTopbar();
  }
  function resetSettings() {
    if (!confirm("Reset all settings to defaults?")) return;
    MMP.resetSettings();
    applySettings();
    renderSettings();
    toast("Settings reset", "Defaults restored", "info");
  }

  // ============================================================
  // SEARCH
  // ============================================================
  function setupSearch() {
    const inp = $("#globalSearch");
    const results = $("#searchResults");
    inp.addEventListener("input", (e) => {
      clearTimeout(state.searchTimeout);
      state.searchTimeout = setTimeout(() => doSearch(e.target.value), 200);
    });
    inp.addEventListener("focus", (e) => {
      if (e.target.value) doSearch(e.target.value);
    });
    document.addEventListener("click", (e) => {
      if (!e.target.closest(".search-box")) results.classList.remove("show");
    });
  }
  function doSearch(q) {
    const results = $("#searchResults");
    if (!q || q.length < 2) {
      results.classList.remove("show");
      return;
    }
    const ql = q.toLowerCase();
    const matches = [];
    Problems.TOPICS.forEach((t) => {
      if (t.name.toLowerCase().includes(ql))
        matches.push({
          type: "topic",
          id: t.id,
          title: t.name,
          desc: "Topic · " + t.group,
          action: () => openTopic(t.id),
        });
    });
    Study.FORMULAS.forEach((f) => {
      if (
        f.name.toLowerCase().includes(ql) ||
        f.formula.toLowerCase().includes(ql) ||
        f.cat.toLowerCase().includes(ql)
      ) {
        matches.push({
          type: "formula",
          title: f.name,
          desc: "Formula · " + f.cat,
          action: () => {
            navigate("study", { tab: "formulas" });
          },
        });
      }
    });
    Study.GLOSSARY.forEach((g) => {
      if (
        g.term.toLowerCase().includes(ql) ||
        g.def.toLowerCase().includes(ql)
      ) {
        matches.push({
          type: "glossary",
          title: g.term,
          desc: "Glossary · " + g.def.slice(0, 50) + "...",
          action: () => navigate("study", { tab: "glossary" }),
        });
      }
    });
    const routes = [
      { id: "home", name: "Home" },
      { id: "study", name: "Study" },
      { id: "practice", name: "Practice" },
      { id: "quiz", name: "Quiz" },
      { id: "flashcards", name: "Flashcards" },
      { id: "games", name: "Games" },
      { id: "tools", name: "Tools" },
      { id: "stats", name: "Statistics" },
      { id: "achievements", name: "Achievements" },
      { id: "worksheet", name: "Worksheets" },
      { id: "settings", name: "Settings" },
    ];
    routes.forEach((r) => {
      if (r.name.toLowerCase().includes(ql))
        matches.push({
          type: "page",
          title: r.name,
          desc: "Page",
          action: () => navigate(r.id),
        });
    });
    const top = matches.slice(0, 8);
    if (top.length === 0) {
      results.innerHTML =
        '<div class="search-result-item"><div class="sr-title">No results</div></div>';
    } else {
      results.innerHTML = top
        .map(
          (m, i) => `
        <div class="search-result-item" onclick="App.runSearchResult(${i})">
          <div class="sr-title">${m.title}</div>
          <div class="sr-desc">${m.desc}</div>
        </div>
      `,
        )
        .join("");
      state._searchResults = top;
    }
    results.classList.add("show");
  }
  function runSearchResult(i) {
    const r = state._searchResults[i];
    if (r && r.action) r.action();
    $("#searchResults").classList.remove("show");
    $("#globalSearch").value = "";
  }

  // ============================================================
  // THEME / SETTINGS APPLICATION
  // ============================================================
  function applySettings() {
    document.documentElement.setAttribute("data-theme", MMP.settings.theme);
    document.documentElement.setAttribute("data-color", MMP.settings.color);
    document.documentElement.setAttribute(
      "data-fontsize",
      MMP.settings.fontSize,
    );
    document.documentElement.setAttribute(
      "data-contrast",
      MMP.settings.contrast,
    );
    $("#themeToggle").textContent = MMP.settings.theme === "dark" ? "☀️" : "🌙";
  }

  // ============================================================
  // MISC FEATURES
  // ============================================================
  function bookmarkTopic(topicId) {
    const added = MMP.toggleBookmark({
      id: topicId,
      type: "topic",
      name: Problems.getTopic(topicId)?.name,
    });
    toast(
      added ? "Bookmarked!" : "Removed",
      added ? "Saved to bookmarks" : "Bookmark removed",
      "success",
      1500,
    );
  }
  function shareTopic(topicId) {
    const t = Problems.getTopic(topicId);
    const text = `Check out ${t.name} on MathMaster Pro! Practice math from Class 1 to College.`;
    if (navigator.share) navigator.share({ title: t.name, text });
    else {
      navigator.clipboard?.writeText(text);
      toast("Copied!", "Share text copied", "success");
    }
  }

  // ============================================================
  // EVENT WIRING
  // ============================================================
  function init() {
    // Load settings on startup
    applySettings();
    MMP.updateStreak();
    MMP.persist.profile();

    // Navigation
    document.body.addEventListener("click", (e) => {
      const navItem = e.target.closest("[data-route]");
      if (navItem) {
        e.preventDefault();
        navigate(navItem.dataset.route);
      }
    });

    // Menu toggle (mobile)
    $("#menuToggle").addEventListener("click", () =>
      $("#sidebar").classList.toggle("open"),
    );

    // Theme toggle
    $("#themeToggle").addEventListener("click", () => {
      MMP.settings.theme = MMP.settings.theme === "dark" ? "light" : "dark";
      MMP.persist.settings();
      applySettings();
    });

    // Profile button
    $("#profileBtn").addEventListener("click", () => {
      modal(
        "👤 Your Profile",
        `
        <div class="text-center">
          <div style="font-size:4rem">${MMP.profile.avatar}</div>
          <h2>${MMP.profile.name}</h2>
          <p class="text-muted">${MMP.profile.title} · Level ${MMP.profile.level}</p>
          <div class="grid grid-3 mt-3">
            <div class="stat-card"><div class="stat-value">${MMP.profile.xp}</div><div class="stat-label">XP</div></div>
            <div class="stat-card"><div class="stat-value">${MMP.profile.streak}</div><div class="stat-label">Day Streak</div></div>
            <div class="stat-card"><div class="stat-value">${MMP.stats.totalCorrect}</div><div class="stat-label">Solved</div></div>
          </div>
        </div>
      `,
        `<button class="btn btn-outline" onclick="App.closeModal()">Close</button><button class="btn btn-primary" onclick="App.closeModal();App.navigate('settings')">Edit Profile</button>`,
      );
    });

    // Modal close
    $("#modalClose").addEventListener("click", closeModal);
    $("#modalOverlay").addEventListener("click", (e) => {
      if (e.target.id === "modalOverlay") closeModal();
    });

    // Keyboard shortcuts
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeModal();
      if (MMP.settings.keyboardShortcuts) {
        if (e.ctrlKey && e.key === "k") {
          e.preventDefault();
          $("#globalSearch").focus();
        }
        if (state.currentProblem) {
          if (e.key === "h" && !e.target.matches("input,textarea")) showHint();
          if (e.key === "s" && !e.target.matches("input,textarea")) showSteps();
          if (e.key === "n" && !e.target.matches("input,textarea"))
            skipProblem();
          if (e.key.match(/[1-4]/) && !e.target.matches("input,textarea")) {
            const choices = $$(".choice-btn");
            const idx = parseInt(e.key) - 1;
            if (choices[idx]) choices[idx].click();
          }
        }
      }
    });

    // Search
    setupSearch();

    // Initial route
    navigate("home");

    // Check for new day
    const today = MMP.todayStr();
    if (MMP.profile.todayDate !== today) {
      MMP.updateStreak();
      MMP.persist.profile();
    }

    // Welcome back toast
    if (MMP.profile.streak >= 3) {
      setTimeout(
        () =>
          toast(
            `🔥 ${MMP.profile.streak}-day streak!`,
            "Keep practicing to grow it!",
            "success",
            4000,
          ),
        1000,
      );
    }

    // Auto-check achievements
    const newAch = MMP.checkAchievements();
    newAch.forEach((a) => {
      setTimeout(
        () =>
          toast(`Achievement: ${a.icon} ${a.name}`, a.desc, "warning", 5000),
        1500,
      );
    });
    if (newAch.length) MMP.persist.achievements();

    // Hide loading if any
    updateTopbar();
  }

  // ---------- Onboarding (first-time) ----------
  function showOnboarding() {
    const seen = localStorage.getItem("mmp_onboarded");
    if (seen) return;
    const overlay = el("div", { class: "onboarding-overlay show" });
    overlay.innerHTML = `
      <div class="onboarding-card">
        <div style="font-size:4rem">🧮</div>
        <h2>Welcome to MathMaster Pro!</h2>
        <p>Your all-in-one math practice companion. From counting to calculus, we've got you covered with 200+ features, 100+ topics, and unlimited practice levels.</p>
        <div class="grid grid-2" style="text-align:left;margin:20px 0">
          <div>📚 Study materials</div>
          <div>✏️ Unlimited practice</div>
          <div>🎯 Timed quizzes</div>
          <div>🎮 Fun math games</div>
          <div>🔧 Useful tools</div>
          <div>📊 Progress tracking</div>
          <div>🏅 Achievements</div>
          <div>🖨️ Printable worksheets</div>
        </div>
        <button class="btn btn-primary btn-lg btn-block" onclick="App.finishOnboarding()">Get Started →</button>
      </div>
    `;
    document.body.appendChild(overlay);
  }
  function finishOnboarding() {
    localStorage.setItem("mmp_onboarded", "1");
    document.querySelector(".onboarding-overlay")?.remove();
  }

  // ---------- Public API ----------
  return {
    init,
    navigate,
    openGroup,
    openTopic,
    switchTab,
    renderStudyTab,
    filterFormulas,
    copyFormula,
    searchGlossary,
    saveNotes,
    startPractice,
    nextProblem,
    renderStudyTab,
    selectDiff,
    selectFmt,
    answerMCQ,
    answerInput,
    answerTF,
    numpadKey,
    showHint,
    showSteps,
    showFormula,
    skipProblem,
    exitPractice,
    setQuizGroup,
    selectQDiff,
    selectQDiffEl,
    selectQCount,
    selectQCountEl,
    selectQTime,
    selectQTimeEl,
    startQuiz,
    startQuizMode,
    addCard,
    removeCard,
    generateCardsFromTopic,
    addTopicCard,
    flipCard,
    startCardStudy,
    flipStudyCard,
    nextStudyCard,
    startPathPractice,
    startSpeedRound,
    startSurvival,
    startMentalMath,
    startTargetNumber,
    startMixed,
    startEstimation,
    startDailyChallenge,
    startMathBingo,
    startNumberChain,
    useNum,
    targetOp,
    resetTarget,
    nextGameProblem,
    endGame,
    exitGame,
    toolCalculator,
    calcKey,
    toolScientific,
    sciKey,
    toolFracSimplifier,
    calcFrac,
    toolPercentCalc,
    calcPct,
    toolPrimeFactor,
    calcPrimeFactor,
    toolGcdLcm,
    calcGcdLcm,
    toolTriangleSolver,
    calcTriangle,
    toolNumberBase,
    calcBase,
    toolRoman,
    calcRoman,
    toolUnitConverter,
    calcUnit,
    toolStatsCalc,
    calcStats,
    toolConstants,
    toolSymbols,
    toolFormulaSheet,
    toolQuadraticSolver,
    calcQuadratic,
    exportData,
    importData,
    shareProgress,
    resetProgress,
    generateWorksheet,
    setSetting,
    setAvatar,
    setGoal,
    setPassScore,
    saveProfile,
    resetSettings,
    bookmarkTopic,
    shareTopic,
    renderStudyTab,
    filterTopics,
    closeModal,
    finishOnboarding,
    runSearchResult,
  };
})();

// Start the app
document.addEventListener("DOMContentLoaded", () => {
  App.init();
  App.showOnboarding();
});

// Make it globally accessible for inline onclick handlers
window.App = App;
