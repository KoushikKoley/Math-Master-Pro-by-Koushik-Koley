/* ============================================================
   MathMaster Pro - problems.js by Koushik Koley
   Problem generators for all math topics, Class 1 to College
   Each generator returns: { question, answer, choices?, hint?, steps?, formula? }
   Difficulty levels: easy, medium, hard, expert
   ============================================================ */

const Problems = (function () {
  "use strict";

  // ---------- Helpers ----------
  const R = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
  const Rf = (min, max, d = 2) =>
    parseFloat((Math.random() * (max - min) + min).toFixed(d));
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const gcd = (a, b) => (b === 0 ? Math.abs(a) : gcd(b, a % b));
  const lcm = (a, b) => Math.abs(a * b) / gcd(a, b);
  const isPrime = (n) => {
    if (n < 2) return false;
    for (let i = 2; i * i <= n; i++) if (n % i === 0) return false;
    return true;
  };
  const fmt = (n) =>
    Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/\.?0+$/, "");

  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function choices(answer, count = 4, spread = 5) {
    const set = new Set([answer]);
    let attempts = 0;
    while (set.size < count && attempts < 50) {
      const delta = R(-spread, spread);
      if (delta !== 0) set.add(answer + delta);
      attempts++;
    }
    while (set.size < count) set.add(answer + set.size);
    return shuffle([...set]);
  }

  function choicesF(answer, count = 4, spread = 1) {
    const set = new Set([answer]);
    while (set.size < count) {
      const delta = parseFloat(
        (Math.random() * spread * 2 - spread).toFixed(2),
      );
      if (Math.abs(delta) > 0.01)
        set.add(parseFloat((answer + delta).toFixed(2)));
    }
    return shuffle([...set]);
  }

  function round(n, d = 2) {
    const p = Math.pow(10, d);
    return Math.round(n * p) / p;
  }

  // ---------- Difficulty ranges by level ----------
  function range(level, easy, med, hard, expert) {
    return { easy, medium: med, hard, expert }[level] || easy;
  }

  // ============================================================
  // TOPIC CATALOG — organized by level group → topic
  // Each topic: { id, name, group, icon, generator(difficulty) }
  // ============================================================

  const TOPICS = [
    // ===== Primary School (Class 1-5) =====
    {
      id: "counting",
      name: "Counting Objects",
      group: "primary",
      icon: "🔢",
      gen: counting,
    },
    {
      id: "number_recognition",
      name: "Number Recognition",
      group: "primary",
      icon: "👁️",
      gen: numberRecognition,
    },
    {
      id: "compare_numbers",
      name: "Compare Numbers",
      group: "primary",
      icon: "⚖️",
      gen: compareNumbers,
    },
    {
      id: "before_after",
      name: "Before / After / Between",
      group: "primary",
      icon: "↔️",
      gen: beforeAfter,
    },
    {
      id: "ordinal",
      name: "Ordinal Numbers",
      group: "primary",
      icon: "🏅",
      gen: ordinal,
    },
    {
      id: "skip_counting",
      name: "Skip Counting",
      group: "primary",
      icon: "🦘",
      gen: skipCounting,
    },
    {
      id: "add_basic",
      name: "Addition (Basic)",
      group: "primary",
      icon: "➕",
      gen: addBasic,
    },
    {
      id: "add_carry",
      name: "Addition with Carry",
      group: "primary",
      icon: "➕",
      gen: addCarry,
    },
    {
      id: "sub_basic",
      name: "Subtraction (Basic)",
      group: "primary",
      icon: "➖",
      gen: subBasic,
    },
    {
      id: "sub_borrow",
      name: "Subtraction with Borrow",
      group: "primary",
      icon: "➖",
      gen: subBorrow,
    },
    {
      id: "add_sub_mix",
      name: "Mixed Add & Subtract",
      group: "primary",
      icon: "🔀",
      gen: addSubMix,
    },
    {
      id: "mul_tables",
      name: "Multiplication Tables",
      group: "primary",
      icon: "✖️",
      gen: mulTables,
    },
    {
      id: "mul_basic",
      name: "Multiplication",
      group: "primary",
      icon: "✖️",
      gen: mulBasic,
    },
    {
      id: "div_basic",
      name: "Division (Basic)",
      group: "primary",
      icon: "➗",
      gen: divBasic,
    },
    {
      id: "word_problems_primary",
      name: "Word Problems",
      group: "primary",
      icon: "📖",
      gen: wordPrimary,
    },
    {
      id: "time",
      name: "Telling Time",
      group: "primary",
      icon: "🕐",
      gen: timeTelling,
    },
    { id: "money", name: "Money", group: "primary", icon: "💰", gen: money },
    {
      id: "measurement",
      name: "Measurement",
      group: "primary",
      icon: "📏",
      gen: measurement,
    },
    {
      id: "shapes",
      name: "Basic Shapes",
      group: "primary",
      icon: "⬜",
      gen: shapes,
    },
    {
      id: "patterns",
      name: "Number Patterns",
      group: "primary",
      icon: "🔢",
      gen: patterns,
    },

    // ===== Middle School (Class 6-8) =====
    {
      id: "place_value",
      name: "Place Value",
      group: "middle",
      icon: "📍",
      gen: placeValue,
    },
    {
      id: "rounding",
      name: "Rounding Numbers",
      group: "middle",
      icon: "🔄",
      gen: rounding,
    },
    {
      id: "factors",
      name: "Factors",
      group: "middle",
      icon: "🔢",
      gen: factors,
    },
    {
      id: "multiples",
      name: "Multiples",
      group: "middle",
      icon: "♾️",
      gen: multiples,
    },
    {
      id: "gcd_lcm",
      name: "GCD & LCM",
      group: "middle",
      icon: "🧮",
      gen: gcdLcm,
    },
    {
      id: "primes",
      name: "Prime Numbers",
      group: "middle",
      icon: "⭐",
      gen: primes,
    },
    {
      id: "fractions_add",
      name: "Fractions: Add/Subtract",
      group: "middle",
      icon: "🍕",
      gen: fracAddSub,
    },
    {
      id: "fractions_mul",
      name: "Fractions: Multiply/Divide",
      group: "middle",
      icon: "🍕",
      gen: fracMulDiv,
    },
    {
      id: "fractions_simplify",
      name: "Simplify Fractions",
      group: "middle",
      icon: "📉",
      gen: fracSimplify,
    },
    {
      id: "fractions_compare",
      name: "Compare Fractions",
      group: "middle",
      icon: "⚖️",
      gen: fracCompare,
    },
    {
      id: "fractions_to_dec",
      name: "Fraction ↔ Decimal",
      group: "middle",
      icon: "🔁",
      gen: fracDec,
    },
    {
      id: "decimals_add",
      name: "Decimals: Add/Subtract",
      group: "middle",
      icon: "🔟",
      gen: decAddSub,
    },
    {
      id: "decimals_mul",
      name: "Decimals: Multiply/Divide",
      group: "middle",
      icon: "🔟",
      gen: decMulDiv,
    },
    {
      id: "percentages",
      name: "Percentages",
      group: "middle",
      icon: "%",
      gen: percentages,
    },
    {
      id: "percent_change",
      name: "Percent Change",
      group: "middle",
      icon: "📈",
      gen: percentChange,
    },
    {
      id: "ratios",
      name: "Ratios & Proportions",
      group: "middle",
      icon: "⚖️",
      gen: ratios,
    },
    {
      id: "integers_add",
      name: "Integers: Add/Subtract",
      group: "middle",
      icon: "➕",
      gen: intAddSub,
    },
    {
      id: "integers_mul",
      name: "Integers: Multiply/Divide",
      group: "middle",
      icon: "✖️",
      gen: intMulDiv,
    },
    {
      id: "order_of_ops",
      name: "Order of Operations",
      group: "middle",
      icon: "📋",
      gen: pemdas,
    },
    {
      id: "exponents",
      name: "Exponents",
      group: "middle",
      icon: "🔺",
      gen: exponents,
    },
    {
      id: "square_roots",
      name: "Square Roots",
      group: "middle",
      icon: "√",
      gen: squareRoots,
    },
    {
      id: "cube_roots",
      name: "Cube Roots",
      group: "middle",
      icon: "∛",
      gen: cubeRoots,
    },
    {
      id: "scientific_notation",
      name: "Scientific Notation",
      group: "middle",
      icon: "🔬",
      gen: scientific,
    },
    {
      id: "algebra_linear",
      name: "Linear Equations",
      group: "middle",
      icon: "🔤",
      gen: linearEq,
    },
    {
      id: "algebra_simplify",
      name: "Simplify Expressions",
      group: "middle",
      icon: "🧹",
      gen: simplifyExpr,
    },
    {
      id: "geometry_angles",
      name: "Angles",
      group: "middle",
      icon: "📐",
      gen: geoAngles,
    },
    {
      id: "geometry_area",
      name: "Area & Perimeter",
      group: "middle",
      icon: "📐",
      gen: geoArea,
    },
    {
      id: "geometry_volume",
      name: "Volume",
      group: "middle",
      icon: "📦",
      gen: geoVolume,
    },
    {
      id: "pythagoras",
      name: "Pythagorean Theorem",
      group: "middle",
      icon: "📏",
      gen: pythagoras,
    },
    {
      id: "mean_median_mode",
      name: "Mean/Median/Mode",
      group: "middle",
      icon: "📊",
      gen: meanMedianMode,
    },
    {
      id: "probability_basic",
      name: "Basic Probability",
      group: "middle",
      icon: "🎲",
      gen: probBasic,
    },
    {
      id: "data_bar_graph",
      name: "Read Bar Graphs",
      group: "middle",
      icon: "📊",
      gen: barGraph,
    },

    // ===== High School (Class 9-12) =====
    {
      id: "quad_equations",
      name: "Quadratic Equations",
      group: "high",
      icon: "📈",
      gen: quadEq,
    },
    {
      id: "quad_formula",
      name: "Quadratic Formula",
      group: "high",
      icon: "🧮",
      gen: quadFormula,
    },
    {
      id: "factoring",
      name: "Factoring",
      group: "high",
      icon: "✂️",
      gen: factoring,
    },
    {
      id: "simultaneous_eq",
      name: "Simultaneous Equations",
      group: "high",
      icon: "🔗",
      gen: simulEq,
    },
    {
      id: "inequalities",
      name: "Inequalities",
      group: "high",
      icon: "≠",
      gen: inequalities,
    },
    {
      id: "functions_eval",
      name: "Evaluate Functions",
      group: "high",
      icon: "ƒ",
      gen: functionsEval,
    },
    {
      id: "functions_domain",
      name: "Domain & Range",
      group: "high",
      icon: "🎯",
      gen: domainRange,
    },
    {
      id: "polynomials",
      name: "Polynomials",
      group: "high",
      icon: "📈",
      gen: polynomials,
    },
    {
      id: "rational_expr",
      name: "Rational Expressions",
      group: "high",
      icon: "➗",
      gen: rationalExpr,
    },
    {
      id: "logarithms",
      name: "Logarithms",
      group: "high",
      icon: "📜",
      gen: logarithms,
    },
    {
      id: "sequences",
      name: "Arithmetic Sequences",
      group: "high",
      icon: "🔢",
      gen: arithmeticSeq,
    },
    {
      id: "geometric_seq",
      name: "Geometric Sequences",
      group: "high",
      icon: "📐",
      gen: geometricSeq,
    },
    {
      id: "binomial",
      name: "Binomial Theorem",
      group: "high",
      icon: "🧮",
      gen: binomial,
    },
    {
      id: "trig_basic",
      name: "Trigonometry Basics",
      group: "high",
      icon: "📐",
      gen: trigBasic,
    },
    {
      id: "trig_identities",
      name: "Trig Identities",
      group: "high",
      icon: "≅",
      gen: trigIdentities,
    },
    {
      id: "trig_eq",
      name: "Trig Equations",
      group: "high",
      icon: "📐",
      gen: trigEq,
    },
    {
      id: "circles",
      name: "Circle Theorems",
      group: "high",
      icon: "⭕",
      gen: circles,
    },
    {
      id: "triangles",
      name: "Triangle Properties",
      group: "high",
      icon: "🔺",
      gen: triangles,
    },
    {
      id: "vectors_2d",
      name: "2D Vectors",
      group: "high",
      icon: "➡️",
      gen: vectors2d,
    },
    {
      id: "matrices_basic",
      name: "Matrices",
      group: "high",
      icon: "🔲",
      gen: matrices,
    },
    {
      id: "complex_numbers",
      name: "Complex Numbers",
      group: "high",
      icon: "🌌",
      gen: complex,
    },
    {
      id: "conic_sections",
      name: "Conic Sections",
      group: "high",
      icon: "⭕",
      gen: conics,
    },
    { id: "limits", name: "Limits", group: "high", icon: "→", gen: limits },
    {
      id: "derivatives_basic",
      name: "Basic Derivatives",
      group: "high",
      icon: "d/dx",
      gen: derivatives,
    },
    {
      id: "integrals_basic",
      name: "Basic Integrals",
      group: "high",
      icon: "∫",
      gen: integrals,
    },
    {
      id: "stats_std",
      name: "Standard Deviation",
      group: "high",
      icon: "📊",
      gen: stddev,
    },
    {
      id: "perms_combs",
      name: "Permutations & Combinations",
      group: "high",
      icon: "🎲",
      gen: permsCombs,
    },
    {
      id: "set_theory",
      name: "Set Theory",
      group: "high",
      icon: "⊃",
      gen: setTheory,
    },
    {
      id: "number_theory",
      name: "Number Theory",
      group: "high",
      icon: "🔢",
      gen: numberTheory,
    },
    {
      id: "compound_interest",
      name: "Compound Interest",
      group: "high",
      icon: "💵",
      gen: compoundInterest,
    },

    // ===== College =====
    {
      id: "derivatives_adv",
      name: "Advanced Derivatives",
      group: "college",
      icon: "d/dx",
      gen: derivativesAdv,
    },
    {
      id: "integrals_adv",
      name: "Advanced Integrals",
      group: "college",
      icon: "∫",
      gen: integralsAdv,
    },
    {
      id: "series_convergence",
      name: "Series Convergence",
      group: "college",
      icon: "Σ",
      gen: seriesConvergence,
    },
    {
      id: "differential_eq",
      name: "Differential Equations",
      group: "college",
      icon: "∂",
      gen: differentialEq,
    },
    {
      id: "partial_deriv",
      name: "Partial Derivatives",
      group: "college",
      icon: "∂",
      gen: partialDeriv,
    },
    {
      id: "multivariable",
      name: "Multivariable Calculus",
      group: "college",
      icon: "🌐",
      gen: multivariable,
    },
    {
      id: "linear_algebra",
      name: "Linear Algebra",
      group: "college",
      icon: "🟦",
      gen: linearAlgebra,
    },
    {
      id: "eigenvalues",
      name: "Eigenvalues",
      group: "college",
      icon: "λ",
      gen: eigenvalues,
    },
    {
      id: "matrix_ops",
      name: "Matrix Operations",
      group: "college",
      icon: "🔢",
      gen: matrixOps,
    },
    {
      id: "vector_calc",
      name: "Vector Calculus",
      group: "college",
      icon: "∇",
      gen: vectorCalc,
    },
    {
      id: "discrete_math",
      name: "Discrete Math",
      group: "college",
      icon: "🔢",
      gen: discreteMath,
    },
    {
      id: "graph_theory",
      name: "Graph Theory",
      group: "college",
      icon: "🕸️",
      gen: graphTheory,
    },
    {
      id: "boolean_algebra",
      name: "Boolean Algebra",
      group: "college",
      icon: "_True",
      gen: booleanAlgebra,
    },
    {
      id: "probability_adv",
      name: "Advanced Probability",
      group: "college",
      icon: "🎲",
      gen: probAdv,
    },
    {
      id: "bayes",
      name: "Bayes' Theorem",
      group: "college",
      icon: "🎯",
      gen: bayes,
    },
    {
      id: "hypothesis",
      name: "Hypothesis Testing",
      group: "college",
      icon: "📊",
      gen: hypothesis,
    },
    {
      id: "regression",
      name: "Linear Regression",
      group: "college",
      icon: "📈",
      gen: regression,
    },
    {
      id: "fourier",
      name: "Fourier Series",
      group: "college",
      icon: "〰️",
      gen: fourier,
    },
    {
      id: "laplace",
      name: "Laplace Transform",
      group: "college",
      icon: "ℒ",
      gen: laplace,
    },
    {
      id: "taylor_series",
      name: "Taylor Series",
      group: "college",
      icon: "Σ",
      gen: taylorSeries,
    },
    {
      id: "complex_analysis",
      name: "Complex Analysis",
      group: "college",
      icon: "🌐",
      gen: complexAnalysis,
    },
    {
      id: "topology",
      name: "Topology Basics",
      group: "college",
      icon: "🍩",
      gen: topology,
    },
    {
      id: "abstract_algebra",
      name: "Abstract Algebra",
      group: "college",
      icon: "🔁",
      gen: abstractAlgebra,
    },
    {
      id: "numerical_methods",
      name: "Numerical Methods",
      group: "college",
      icon: "💻",
      gen: numericalMethods,
    },
    {
      id: "optimization",
      name: "Optimization",
      group: "college",
      icon: "🎯",
      gen: optimization,
    },
  ];

  // ============================================================
  // GENERATORS (Primary)
  // ============================================================
  function counting(d) {
    const n = R(range(d, 5, 10, 20, 50), range(d, 10, 20, 50, 100));
    return {
      question: `🍎🍎🍎 ... (${n} apples shown as 🍕 × ${n}). How many apples?`,
      questionVisual: "🍎".repeat(n),
      answer: n,
      choices: choices(n, 4, 3),
      hint: "Count each apple one by one.",
      steps: [
        "Look at the group of apples.",
        `Count: 1, 2, 3, ... up to ${n}.`,
        `Total: ${n} apples.`,
      ],
      formula: "Counting = total number of objects",
    };
  }

  function numberRecognition(d) {
    const n = R(range(d, 1, 10, 50, 100), range(d, 10, 50, 100, 999));
    return {
      question: `What number is this? (Written form)`,
      questionVisual: numToWords(n),
      answer: n,
      choices: choices(n, 4, Math.max(5, Math.floor(n * 0.2))),
      hint: "Read the words and convert to digits.",
      steps: [`"${numToWords(n)}" means ${n}.`],
      formula: "Number = digit representation of word form",
    };
  }

  function numToWords(n) {
    if (n < 10)
      return [
        "zero",
        "one",
        "two",
        "three",
        "four",
        "five",
        "six",
        "seven",
        "eight",
        "nine",
      ][n];
    if (n < 20)
      return [
        "ten",
        "eleven",
        "twelve",
        "thirteen",
        "fourteen",
        "fifteen",
        "sixteen",
        "seventeen",
        "eighteen",
        "nineteen",
      ][n - 10];
    if (n < 100) {
      const tens = [
        "twenty",
        "thirty",
        "forty",
        "fifty",
        "sixty",
        "seventy",
        "eighty",
        "ninety",
      ][Math.floor(n / 10) - 2];
      return n % 10 === 0 ? tens : `${tens}-${numToWords(n % 10)}`;
    }
    if (n < 1000) {
      const h = Math.floor(n / 100);
      return `${numToWords(h)} hundred${n % 100 ? " and " + numToWords(n % 100) : ""}`;
    }
    return String(n);
  }

  function compareNumbers(d) {
    const a = R(range(d, 1, 10, 100, 1000), range(d, 10, 100, 1000, 9999));
    const b = R(range(d, 1, 10, 100, 1000), range(d, 10, 100, 1000, 9999));
    const ans = a > b ? ">" : a < b ? "<" : "=";
    return {
      question: `Fill in: ${a} ___ ${b}`,
      answer: ans,
      choices: [">", "<", "="],
      hint: 'The bigger number "eats" the smaller one with >.',
      steps: [
        `Compare ${a} and ${b}.`,
        a > b
          ? `${a} is bigger than ${b}.`
          : a < b
            ? `${b} is bigger than ${a}.`
            : "They are equal.",
        `Symbol: ${ans}`,
      ],
      formula: "> greater than, < less than, = equal to",
    };
  }

  function beforeAfter(d) {
    const n = R(range(d, 5, 20, 50, 100), range(d, 20, 50, 200, 999));
    const type = pick(["before", "after", "between"]);
    if (type === "before") {
      return {
        question: `What comes BEFORE ${n}?`,
        answer: n - 1,
        choices: choices(n - 1, 4, 3),
        hint: "Before = one less.",
        steps: [`${n} - 1 = ${n - 1}`],
        formula: "Before = n - 1",
      };
    } else if (type === "after") {
      return {
        question: `What comes AFTER ${n}?`,
        answer: n + 1,
        choices: choices(n + 1, 4, 3),
        hint: "After = one more.",
        steps: [`${n} + 1 = ${n + 1}`],
        formula: "After = n + 1",
      };
    } else {
      const m = n + 2;
      return {
        question: `What number is BETWEEN ${n} and ${m}?`,
        answer: n + 1,
        choices: choices(n + 1, 4, 2),
        hint: "Between = the number right in the middle.",
        steps: [`${n} < ? < ${m}`, `Answer: ${n + 1}`],
        formula: "Between = midpoint",
      };
    }
  }

  function ordinal(d) {
    const n = R(1, range(d, 10, 20, 50, 100));
    const ord = ordinalStr(n);
    return {
      question: `What is the ordinal form of ${n}?`,
      answer: ord,
      choices: shuffle([
        ord,
        ordinalStr(n + 1),
        ordinalStr(n - 1 || 1),
        ordinalStr(n + 2),
      ]),
      hint: "Most use -th, but 1st, 2nd, 3rd are special.",
      steps: [`${n} → ${ord}`],
      formula: "1st, 2nd, 3rd, then -th",
    };
  }
  function ordinalStr(n) {
    const s = ["th", "st", "nd", "rd"];
    const v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
  }

  function skipCounting(d) {
    const step = pick([2, 3, 5, 10, range(d, 2, 3, 5, 10)]);
    const start = R(1, 20);
    const seq = [start, start + step, start + 2 * step, start + 3 * step];
    const ans = start + 4 * step;
    return {
      question: `Skip counting: ${seq.join(", ")}, ___?`,
      answer: ans,
      choices: choices(ans, 4, step),
      hint: `Each number goes up by ${step}.`,
      steps: [
        `Pattern: +${step} each time.`,
        `${start + 3 * step} + ${step} = ${ans}`,
      ],
      formula: `Skip count by ${step}: a_n = a_1 + (n-1)*${step}`,
    };
  }

  function addBasic(d) {
    const max = range(d, 10, 50, 100, 500);
    const a = R(1, max),
      b = R(1, max);
    return {
      question: `${a} + ${b} = ?`,
      answer: a + b,
      choices: choices(a + b, 4, Math.max(3, Math.floor((a + b) * 0.1))),
      hint: "Add the two numbers together.",
      steps: [`${a} + ${b}`, `= ${a + b}`],
      formula: "a + b = sum",
    };
  }

  function addCarry(d) {
    const max = range(d, 50, 200, 999, 9999);
    const a = R(20, max),
      b = R(20, max);
    return {
      question: `${a} + ${b} = ?`,
      answer: a + b,
      choices: choices(a + b, 4, Math.max(5, Math.floor((a + b) * 0.05))),
      hint: "Stack and add column by column, carrying when needed.",
      steps: [`  ${a}`, `+ ${b}`, `-----`, `= ${a + b}`],
      formula: "Stack addition with carry",
    };
  }

  function subBasic(d) {
    const max = range(d, 10, 50, 100, 500);
    let a = R(1, max),
      b = R(1, max);
    if (b > a) [a, b] = [b, a];
    return {
      question: `${a} − ${b} = ?`,
      answer: a - b,
      choices: choices(a - b, 4, Math.max(2, Math.floor((a - b) * 0.2))),
      hint: "Subtract the smaller from the bigger.",
      steps: [`${a} - ${b}`, `= ${a - b}`],
      formula: "a - b = difference",
    };
  }

  function subBorrow(d) {
    const max = range(d, 50, 200, 999, 9999);
    let a = R(20, max),
      b = R(20, max);
    if (b > a) [a, b] = [b, a];
    return {
      question: `${a} − ${b} = ?`,
      answer: a - b,
      choices: choices(a - b, 4, Math.max(5, Math.floor((a - b) * 0.1))),
      hint: "Borrow from the next column when needed.",
      steps: [`  ${a}`, `− ${b}`, `-----`, `= ${a - b}`],
      formula: "Stack subtraction with borrow",
    };
  }

  function addSubMix(d) {
    const a = R(1, range(d, 20, 50, 100, 500));
    const b = R(1, range(d, 20, 50, 100, 500));
    const c = R(1, range(d, 20, 50, 100, 500));
    const op = pick(["+", "−"]);
    const ans = op === "+" ? a + b - c : a - b + c;
    if (ans < 0) return addSubMix(d);
    return {
      question: `${a} ${op} ${b} ${op === "+" ? "−" : "+"} ${c} = ?`,
      answer: ans,
      choices: choices(ans, 4, Math.max(3, Math.floor(ans * 0.1))),
      hint: "Solve left to right.",
      steps: [
        `Step 1: ${a} ${op} ${b} = ${op === "+" ? a + b : a - b}`,
        `Step 2: ${op === "+" ? a + b : a - b} ${op === "+" ? "−" : "+"} ${c} = ${ans}`,
      ],
      formula: "Left to right evaluation",
    };
  }

  function mulTables(d) {
    const table = R(2, range(d, 10, 12, 15, 20));
    const mult = R(2, 12);
    return {
      question: `${table} × ${mult} = ?`,
      answer: table * mult,
      choices: choices(table * mult, 4, Math.max(3, table)),
      hint: `Use the ${table} times table.`,
      steps: [`${table} × ${mult}`, `= ${table * mult}`],
      formula: `${table} × ${mult} = ${table * mult}`,
    };
  }

  function mulBasic(d) {
    const max = range(d, 12, 50, 99, 999);
    const a = R(2, max),
      b = R(2, max);
    return {
      question: `${a} × ${b} = ?`,
      answer: a * b,
      choices: choices(a * b, 4, Math.max(5, Math.floor(a * b * 0.1))),
      hint: "Multiply the two numbers.",
      steps: [`${a} × ${b}`, `= ${a * b}`],
      formula: "a × b = product",
    };
  }

  function divBasic(d) {
    const b = R(2, range(d, 10, 12, 15, 25));
    const ans = R(1, range(d, 10, 12, 20, 50));
    const a = b * ans;
    return {
      question: `${a} ÷ ${b} = ?`,
      answer: ans,
      choices: choices(ans, 4, Math.max(2, Math.floor(ans * 0.2))),
      hint: `${a} divided into groups of ${b}.`,
      steps: [`${a} ÷ ${b}`, `= ${ans}`, `Check: ${b} × ${ans} = ${a}`],
      formula: "a ÷ b = quotient",
    };
  }

  function wordPrimary(d) {
    const types = ["add", "sub", "mul", "div"];
    const t = pick(types);
    if (t === "add") {
      const a = R(2, 20),
        b = R(2, 20);
      return {
        question: `Sara has ${a} candies. Her mom gives her ${b} more. How many candies does Sara have now?`,
        answer: a + b,
        choices: choices(a + b, 4, 3),
        hint: "Add the candies.",
        steps: [`${a} + ${b} = ${a + b}`],
        formula: "Addition word problem",
      };
    }
    if (t === "sub") {
      let a = R(5, 30),
        b = R(1, a - 1);
      return {
        question: `Tom had ${a} marbles. He lost ${b}. How many does he have left?`,
        answer: a - b,
        choices: choices(a - b, 4, 3),
        hint: "Subtract what he lost.",
        steps: [`${a} - ${b} = ${a - b}`],
        formula: "Subtraction word problem",
      };
    }
    if (t === "mul") {
      const a = R(2, 10),
        b = R(2, 10);
      return {
        question: `There are ${a} boxes with ${b} pencils each. How many pencils in total?`,
        answer: a * b,
        choices: choices(a * b, 4, 5),
        hint: "Multiply boxes by pencils per box.",
        steps: [`${a} × ${b} = ${a * b}`],
        formula: "Multiplication word problem",
      };
    }
    const b = R(2, 10),
      ans = R(2, 12),
      a = b * ans;
    return {
      question: `${a} cookies shared equally among ${b} friends. How many each?`,
      answer: ans,
      choices: choices(ans, 4, 2),
      hint: "Divide total by friends.",
      steps: [`${a} ÷ ${b} = ${ans}`],
      formula: "Division word problem",
    };
  }

  function timeTelling(d) {
    const h = R(1, 12),
      m = pick([0, 15, 30, 45, range(d, 0, 5, 10, 1)]);
    const mStr =
      m === 0
        ? "o'clock"
        : m === 15
          ? "quarter past"
          : m === 30
            ? "half past"
            : m === 45
              ? "quarter to" + (h + 1)
              : `${m} minutes past`;
    const timeStr =
      m === 45 ? `quarter to ${h + 1 === 13 ? 1 : h + 1}` : `${mStr} ${h}`;
    return {
      question: `What time is "${timeStr}"?`,
      questionVisual: "🕐".repeat(1),
      answer: `${h}:${String(m).padStart(2, "0")}`,
      choices: shuffle([
        `${h}:${String(m).padStart(2, "0")}`,
        `${h + 1 === 13 ? 1 : h + 1}:${String(m).padStart(2, "0")}`,
        `${h}:${String((m + 15) % 60).padStart(2, "0")}`,
        `${h - 1 || 12}:${String(m).padStart(2, "0")}`,
      ]),
      hint: "Read hours and minutes.",
      steps: [
        `Hour hand: ${h}`,
        `Minute hand: ${m}`,
        `Time: ${h}:${String(m).padStart(2, "0")}`,
      ],
      formula: "Hour:Minute",
    };
  }

  function money(d) {
    const items = [
      { n: "pencil", p: 5 },
      { n: "eraser", p: 10 },
      { n: "ruler", p: 15 },
      { n: "notebook", p: 30 },
      { n: "pen", p: 20 },
      { n: "crayon", p: 8 },
      { n: "sharpener", p: 12 },
      { n: "glue", p: 25 },
    ];
    const item = pick(items);
    const qty = R(2, range(d, 5, 10, 12, 20));
    const total = item.p * qty;
    return {
      question: `One ${item.n} costs ₹${item.p}. How much do ${qty} ${item.n}s cost?`,
      answer: total,
      choices: choices(total, 4, Math.max(5, Math.floor(total * 0.2))),
      hint: "Multiply price by quantity.",
      steps: [`${item.p} × ${qty}`, `= ₹${total}`],
      formula: "Total cost = price × quantity",
    };
  }

  function measurement(d) {
    const types = [
      { from: "m", to: "cm", factor: 100 },
      { from: "km", to: "m", factor: 1000 },
      { from: "kg", to: "g", factor: 1000 },
      { from: "L", to: "mL", factor: 1000 },
      { from: "cm", to: "mm", factor: 10 },
      { from: "hr", to: "min", factor: 60 },
    ];
    const t = pick(types);
    const v = R(1, range(d, 10, 20, 50, 100));
    const ans = v * t.factor;
    return {
      question: `Convert ${v} ${t.from} to ${t.to}.`,
      answer: ans,
      choices: choices(ans, 4, Math.max(5, Math.floor(ans * 0.1))),
      hint: `1 ${t.from} = ${t.factor} ${t.to}.`,
      steps: [`${v} ${t.from} × ${t.factor}`, `= ${ans} ${t.to}`],
      formula: `1 ${t.from} = ${t.factor} ${t.to}`,
    };
  }

  function shapes(d) {
    const shapes = [
      { n: "triangle", sides: 3, icon: "🔺" },
      { n: "square", sides: 4, icon: "⬜" },
      { n: "rectangle", sides: 4, icon: "▭" },
      { n: "pentagon", sides: 5, icon: "⬠" },
      { n: "hexagon", sides: 6, icon: "⬡" },
      { n: "circle", sides: 0, icon: "⭕" },
    ];
    const s = pick(shapes);
    if (s.sides === 0) {
      return {
        question: `How many sides does a ${s.n} have?`,
        questionVisual: s.icon,
        answer: "0 (curved)",
        choices: ["0 (curved)", "3", "4", "1"],
        hint: "A circle is curved.",
        steps: ["A circle has no straight sides."],
        formula: "Circle: 0 sides",
      };
    }
    return {
      question: `How many sides does a ${s.n} have?`,
      questionVisual: s.icon,
      answer: s.sides,
      choices: choices(s.sides, 4, 1),
      hint: `Count the straight edges of a ${s.n}.`,
      steps: [`${s.n} = ${s.icon}`, `Sides: ${s.sides}`],
      formula: `${s.n}: ${s.sides} sides`,
    };
  }

  function patterns(d) {
    const start = R(1, 10),
      step = R(2, range(d, 5, 10, 12, 20));
    const seq = [start, start + step, start + 2 * step, start + 3 * step];
    const ans = start + 4 * step;
    return {
      question: `Continue the pattern: ${seq.join(", ")}, ___?`,
      answer: ans,
      choices: choices(ans, 4, step),
      hint: `Add ${step} each time.`,
      steps: [`Pattern: +${step}`, `${seq[3]} + ${step} = ${ans}`],
      formula: `Arithmetic: a_n = ${start} + (n-1)*${step}`,
    };
  }

  // ============================================================
  // GENERATORS (Middle School)
  // ============================================================
  function placeValue(d) {
    const n = R(
      range(d, 100, 1000, 9999, 99999),
      range(d, 1000, 9999, 99999, 999999),
    );
    const str = String(n);
    const idx = R(0, str.length - 1);
    const digit = parseInt(str[idx]);
    const placeNames = [
      "ones",
      "tens",
      "hundreds",
      "thousands",
      "ten-thousands",
      "hundred-thousands",
      "millions",
    ];
    const place = placeNames[str.length - 1 - idx];
    return {
      question: `In ${n}, what is the place value of digit ${digit}?`,
      answer: place,
      choices: shuffle([
        place,
        ...shuffle(placeNames.filter((p) => p !== place)).slice(0, 3),
      ]),
      hint: "Ones, tens, hundreds, thousands from right to left.",
      steps: [
        `${n}`,
        `Digit ${digit} is at position ${str.length - idx} from right.`,
        `Place value: ${place}`,
      ],
      formula: "Right to left: ones, tens, hundreds, thousands...",
    };
  }

  function rounding(d) {
    const places = [10, 100, 1000, 10000];
    const p = pick(places.slice(0, range(d, 2, 3, 4, 4)));
    const n = R(p, p * 100);
    const ans = Math.round(n / p) * p;
    return {
      question: `Round ${n} to the nearest ${p >= 1000 ? p / 1000 + "k" : p}.`,
      answer: ans,
      choices: choices(ans, 4, p),
      hint: `Look at the digit just below ${p}.`,
      steps: [
        `${n} to nearest ${p}`,
        `Digit below: ${Math.floor((n % (p * 10)) / p)}`,
        `Rounded: ${ans}`,
      ],
      formula: "Round up if 5+, else down",
    };
  }

  function factors(d) {
    const candidates = [6, 8, 10, 12, 15, 18, 20, 24, 30, 36, 48];
    const n = pick(candidates);
    const fs = [];
    for (let i = 1; i <= n; i++) if (n % i === 0) fs.push(i);
    const ask = pick(fs);
    return {
      question: `Is ${ask} a factor of ${n}?`,
      answer: "Yes",
      choices: ["Yes", "No"],
      hint: `${n} ÷ ${ask} = ${n / ask}`,
      steps: [
        `${n} ÷ ${ask} = ${n / ask}`,
        n % ask === 0 ? "No remainder, so yes." : "Has remainder, so no.",
      ],
      formula: "Factor: divides evenly with no remainder",
    };
  }

  function multiples(d) {
    const n = R(2, range(d, 10, 12, 20, 50));
    const k = R(2, range(d, 5, 10, 15, 25));
    const ans = n * k;
    return {
      question: `What is the ${ordinalStr(k)} multiple of ${n}?`,
      answer: ans,
      choices: choices(ans, 4, n),
      hint: `${n} × ${k}`,
      steps: [`${n} × ${k} = ${ans}`],
      formula: `k-th multiple = n × k`,
    };
  }

  function gcdLcm(d) {
    const a = R(2, range(d, 12, 20, 50, 100));
    const b = R(2, range(d, 12, 20, 50, 100));
    const isGcd = Math.random() < 0.5;
    const ans = isGcd ? gcd(a, b) : lcm(a, b);
    return {
      question: `Find the ${isGcd ? "GCD" : "LCM"} of ${a} and ${b}.`,
      answer: ans,
      choices: choices(ans, 4, Math.max(3, Math.floor(ans * 0.3))),
      hint: isGcd
        ? "GCD is the biggest number that divides both."
        : "LCM is the smallest number both divide into.",
      steps: isGcd
        ? [`GCD(${a}, ${b})`, `Factors common to both`, `Greatest = ${ans}`]
        : [`LCM(${a}, ${b})`, `Smallest common multiple`, `= ${ans}`],
      formula: isGcd
        ? `GCD(a,b) = largest common divisor`
        : `LCM(a,b) = |a*b| / GCD(a,b)`,
    };
  }

  function primes(d) {
    const n = R(range(d, 5, 10, 50, 100), range(d, 20, 100, 200, 500));
    return {
      question: `Is ${n} a prime number?`,
      answer: isPrime(n) ? "Yes" : "No",
      choices: ["Yes", "No"],
      hint: "Prime = only divisible by 1 and itself.",
      steps: [
        `Check ${n}: divisible by 2, 3, 5, 7...?`,
        isPrime(n) ? "No divisors found → prime." : "Has divisors → not prime.",
      ],
      formula: "Prime: only divisors are 1 and itself",
    };
  }

  function fracAddSub(d) {
    const a = R(1, range(d, 4, 8, 12, 20));
    const b = R(2, range(d, 4, 8, 12, 20));
    const c = R(1, range(d, 4, 8, 12, 20));
    const op = pick(["+", "−"]);
    const lcmV = lcm(b, b);
    const num = op === "+" ? a + c : a - c;
    if (num < 0) return fracAddSub(d);
    const g = gcd(Math.abs(num), b);
    return {
      question: `${a}/${b} ${op} ${c}/${b} = ?`,
      answer: `${num / g}/${b / g}`,
      choices: shuffle([
        `${num / g}/${b / g}`,
        `${num}/${b}`,
        `${num + 1}/${b}`,
        `${num - 1 || 1}/${b}`,
      ]),
      hint: "Same denominator — just add/subtract the tops.",
      steps: [
        `${a} ${op} ${c} = ${num} (numerators)`,
        `Denominator stays ${b}.`,
        `Simplify ${num}/${b} = ${num / g}/${b / g}`,
      ],
      formula: "a/b ± c/b = (a±c)/b",
    };
  }

  function fracMulDiv(d) {
    const a = R(1, range(d, 4, 8, 12, 15));
    const b = R(2, range(d, 4, 8, 12, 15));
    const c = R(1, range(d, 4, 8, 12, 15));
    const e = R(2, range(d, 4, 8, 12, 15));
    const op = pick(["×", "÷"]);
    let num, den;
    if (op === "×") {
      num = a * c;
      den = b * e;
    } else {
      num = a * e;
      den = b * c;
    }
    const g = gcd(num, den);
    return {
      question: `${a}/${b} ${op} ${c}/${e} = ?`,
      answer: `${num / g}/${den / g}`,
      choices: shuffle([
        `${num / g}/${den / g}`,
        `${num}/${den}`,
        `${num + 1}/${den}`,
        `${num - 1 || 1}/${den}`,
      ]),
      hint:
        op === "×"
          ? "Multiply tops, multiply bottoms."
          : "Multiply by reciprocal.",
      steps:
        op === "×"
          ? [
              `${a}×${c} = ${num}`,
              `${b}×${e} = ${den}`,
              `Simplify: ${num / g}/${den / g}`,
            ]
          : [
              `${a}/${b} × ${e}/${c}`,
              `= ${num}/${den}`,
              `Simplify: ${num / g}/${den / g}`,
            ],
      formula: op === "×" ? "(a/b)(c/d) = ac/bd" : "(a/b)/(c/d) = ad/bc",
    };
  }

  function fracSimplify(d) {
    const g = R(2, range(d, 5, 8, 12, 20));
    const a = R(1, range(d, 3, 5, 8, 12));
    const b = R(1, range(d, 3, 5, 8, 12));
    const num = g * a,
      den = g * b;
    const gg = gcd(num, den);
    return {
      question: `Simplify ${num}/${den}.`,
      answer: `${num / gg}/${den / gg}`,
      choices: shuffle([
        `${num / gg}/${den / gg}`,
        `${num}/${den}`,
        `${num / gg + 1}/${den / gg}`,
        `${num / gg}/${den / gg + 1}`,
      ]),
      hint: "Divide top and bottom by their GCD.",
      steps: [
        `GCD(${num}, ${den}) = ${gg}`,
        `${num}÷${gg} = ${num / gg}`,
        `${den}÷${gg} = ${den / gg}`,
        `= ${num / gg}/${den / gg}`,
      ],
      formula: "Divide numerator & denominator by GCD",
    };
  }

  function fracCompare(d) {
    const a = R(1, 8),
      b = R(2, 9),
      c = R(1, 8),
      e = R(2, 9);
    const v1 = a / b,
      v2 = c / e;
    const ans = v1 > v2 ? ">" : v1 < v2 ? "<" : "=";
    return {
      question: `Compare: ${a}/${b} ___ ${c}/${e}`,
      answer: ans,
      choices: [">", "<", "="],
      hint: "Cross-multiply or convert to common denominator.",
      steps: [
        `${a}/${b} = ${v1.toFixed(3)}`,
        `${c}/${e} = ${v2.toFixed(3)}`,
        `Symbol: ${ans}`,
      ],
      formula: "a/b vs c/d: compare a*d vs b*c",
    };
  }

  function fracDec(d) {
    const denoms = [2, 4, 5, 8, 10, 20, 25, 50, 100];
    const b = pick(denoms);
    const a = R(1, b - 1);
    const dec = round(a / b, 3);
    return {
      question: `Convert ${a}/${b} to a decimal.`,
      answer: dec,
      choices: choicesF(dec, 4, 0.5),
      hint: "Divide the top by the bottom.",
      steps: [`${a} ÷ ${b}`, `= ${dec}`],
      formula: "Decimal = numerator ÷ denominator",
    };
  }

  function decAddSub(d) {
    const a = round(Rf(1, range(d, 10, 50, 100, 500)), 2);
    const b = round(Rf(1, range(d, 10, 50, 100, 500)), 2);
    const op = pick(["+", "−"]);
    const ans = round(op === "+" ? a + b : a - b, 2);
    if (ans < 0) return decAddSub(d);
    return {
      question: `${a} ${op} ${b} = ?`,
      answer: ans,
      choices: choicesF(ans, 4, 1),
      hint: "Line up decimal points.",
      steps: [`${a} ${op} ${b}`, `= ${ans}`],
      formula: "Line up decimals, then add/subtract",
    };
  }

  function decMulDiv(d) {
    const a = round(Rf(1, range(d, 10, 20, 50, 100)), 2);
    const b = R(2, range(d, 5, 10, 20, 50));
    const op = pick(["×", "÷"]);
    let ans;
    if (op === "×") ans = round(a * b, 2);
    else ans = round(a / b, 3);
    return {
      question: `${a} ${op} ${b} = ?`,
      answer: ans,
      choices: choicesF(ans, 4, Math.max(1, ans * 0.2)),
      hint:
        op === "×"
          ? "Multiply normally, count decimal places."
          : "Move decimals to make divisor whole.",
      steps: [`${a} ${op} ${b}`, `= ${ans}`],
      formula:
        op === "×" ? "Count decimal places" : "Multiply both by power of 10",
    };
  }

  function percentages(d) {
    const p = R(5, range(d, 25, 50, 100, 200));
    const base = R(20, range(d, 100, 200, 500, 1000));
    const ans = round((p / 100) * base, 2);
    return {
      question: `What is ${p}% of ${base}?`,
      answer: ans,
      choices: choicesF(ans, 4, Math.max(2, ans * 0.2)),
      hint: "Convert % to decimal, multiply.",
      steps: [`${p}% = ${p / 100}`, `${p / 100} × ${base} = ${ans}`],
      formula: "x% of n = (x/100) × n",
    };
  }

  function percentChange(d) {
    const oldV = R(20, range(d, 50, 100, 200, 500));
    const change = R(10, range(d, 20, 50, 100, 200));
    const isUp = Math.random() < 0.5;
    const newV = isUp ? oldV + change : Math.max(1, oldV - change);
    const ans = round(Math.abs((newV - oldV) / oldV) * 100, 1);
    return {
      question: `A price changes from ${oldV} to ${newV}. What is the percent change?`,
      answer: ans,
      choices: choicesF(ans, 4, Math.max(2, ans * 0.2)),
      hint: "Change ÷ original × 100.",
      steps: [
        `Change = |${newV} - ${oldV}| = ${Math.abs(newV - oldV)}`,
        `${Math.abs(newV - oldV)} / ${oldV} × 100`,
        `= ${ans}%`,
      ],
      formula: "% change = |new-old| / old × 100",
    };
  }

  function ratios(d) {
    const a = R(1, range(d, 5, 10, 20, 50));
    const b = R(1, range(d, 5, 10, 20, 50));
    const g = gcd(a, b);
    return {
      question: `Simplify the ratio ${a}:${b}.`,
      answer: `${a / g}:${b / g}`,
      choices: shuffle([
        `${a / g}:${b / g}`,
        `${a}:${b}`,
        `${(a * 2) / g}:${(b * 2) / g}`,
        `${b / g}:${a / g}`,
      ]),
      hint: "Divide both by their GCD.",
      steps: [
        `GCD(${a}, ${b}) = ${g}`,
        `${a}÷${g} = ${a / g}`,
        `${b}÷${g} = ${b / g}`,
        `Ratio: ${a / g}:${b / g}`,
      ],
      formula: "Divide both sides by GCD",
    };
  }

  function intAddSub(d) {
    const a =
      R(range(d, 5, 20, 50, 100), range(d, 20, 50, 100, 200)) *
      (Math.random() < 0.5 ? -1 : 1);
    const b =
      R(range(d, 5, 20, 50, 100), range(d, 20, 50, 100, 200)) *
      (Math.random() < 0.5 ? -1 : 1);
    const op = pick(["+", "−"]);
    const ans = op === "+" ? a + b : a - b;
    return {
      question: `${a} ${op} ${b} = ?`,
      answer: ans,
      choices: choices(ans, 4, Math.max(3, Math.abs(ans * 0.2))),
      hint: "Same signs add, different signs subtract.",
      steps: [`${a} ${op} ${b}`, `= ${ans}`],
      formula: "Same sign: add. Different sign: subtract smaller from bigger.",
    };
  }

  function intMulDiv(d) {
    const a = R(2, range(d, 10, 20, 50, 100)) * (Math.random() < 0.5 ? -1 : 1);
    const b = R(2, range(d, 10, 20, 50, 100)) * (Math.random() < 0.5 ? -1 : 1);
    const op = pick(["×", "÷"]);
    let ans;
    if (op === "×") ans = a * b;
    else {
      const q = R(2, 10);
      const aa = b * q;
      ans = aa / b;
    }
    return {
      question: `${a} ${op} ${b} = ?`,
      answer: ans,
      choices: choices(ans, 4, Math.max(3, Math.abs(ans * 0.2))),
      hint: "Same sign = positive, different sign = negative.",
      steps: [
        `${a} ${op} ${b}`,
        `Magnitude: ${Math.abs(a)} ${op} ${Math.abs(b)} = ${Math.abs(ans)}`,
        `Sign: ${ans > 0 ? "+" : "-"}`,
      ],
      formula: "(+)(+)=(+), (+)(-)=(-), (-)(+) =(-), (-)(-)=(+)",
    };
  }

  function pemdas(d) {
    const a = R(2, 10),
      b = R(2, 10),
      c = R(1, 5),
      e = R(2, 5);
    const expr = `${a} + ${b} × ${c} - (${e})`;
    const ans = a + b * c - e;
    return {
      question: `Evaluate: ${a} + ${b} × ${c} − ${e}`,
      answer: ans,
      choices: choices(ans, 4, 5),
      hint: "PEMDAS: Parentheses, Exponents, Multiply/Divide, Add/Subtract.",
      steps: [
        `Multiply first: ${b} × ${c} = ${b * c}`,
        `${a} + ${b * c} − ${e}`,
        `= ${ans}`,
      ],
      formula: "Order: () → ^ → ×÷ → +−",
    };
  }

  function exponents(d) {
    const base = R(2, range(d, 5, 10, 12, 15));
    const exp = R(2, range(d, 3, 4, 5, 6));
    const ans = Math.pow(base, exp);
    return {
      question: `${base}^${exp} = ?`,
      answer: ans,
      choices: choices(ans, 4, Math.max(10, Math.floor(ans * 0.1))),
      hint: `Multiply ${base} by itself ${exp} times.`,
      steps: [
        `${base}^${exp} = ${base} × ${base}${exp > 2 ? " × ..." : ""}`,
        `= ${ans}`,
      ],
      formula: "a^n = a × a × ... (n times)",
    };
  }

  function squareRoots(d) {
    const n = R(range(d, 3, 5, 10, 15), range(d, 10, 15, 20, 30));
    const sq = n * n;
    return {
      question: `√${sq} = ?`,
      answer: n,
      choices: choices(n, 4, 2),
      hint: "What number times itself gives this?",
      steps: [`${n} × ${n} = ${sq}`, `So √${sq} = ${n}`],
      formula: "√(n²) = n",
    };
  }

  function cubeRoots(d) {
    const n = R(2, range(d, 5, 8, 10, 15));
    const cb = n * n * n;
    return {
      question: `∛${cb} = ?`,
      answer: n,
      choices: choices(n, 4, 2),
      hint: "What number cubed gives this?",
      steps: [`${n}³ = ${cb}`, `So ∛${cb} = ${n}`],
      formula: "∛(n³) = n",
    };
  }

  function scientific(d) {
    const mantissa = Rf(1, 9.99, 2);
    const exp = R(range(d, 2, 4, 6, 9), range(d, 3, 5, 8, 12));
    const num = mantissa * Math.pow(10, exp);
    return {
      question: `Write ${num.toExponential(2)} in scientific notation.`,
      answer: `${mantissa} × 10^${exp}`,
      choices: shuffle([
        `${mantissa} × 10^${exp}`,
        `${mantissa} × 10^${exp + 1}`,
        `${mantissa * 10} × 10^${exp - 1}`,
        `${mantissa / 10} × 10^${exp + 1}`,
      ]),
      hint: "One digit before decimal, rest after.",
      steps: [
        `${num}`,
        `Move decimal ${exp} places left`,
        `= ${mantissa} × 10^${exp}`,
      ],
      formula: "a × 10^n where 1 ≤ a < 10",
    };
  }

  function linearEq(d) {
    const m = R(2, range(d, 5, 10, 15, 20));
    const x = R(1, range(d, 5, 10, 15, 25));
    const b = R(1, range(d, 10, 20, 50, 100));
    const ans = m * x + b;
    return {
      question: `Solve for x: ${m}x + ${b} = ${ans}`,
      answer: x,
      choices: choices(x, 4, 2),
      hint: "Subtract b, then divide by m.",
      steps: [
        `${m}x + ${b} = ${ans}`,
        `${m}x = ${ans - b}`,
        `x = ${(ans - b) / m}`,
      ],
      formula: "ax + b = c → x = (c - b)/a",
    };
  }

  function simplifyExpr(d) {
    const a = R(2, 10),
      b = R(2, 10),
      c = R(1, 5);
    return {
      question: `Simplify: ${a}x + ${b}x - ${c}x`,
      answer: `${a + b - c}x`,
      choices: shuffle([
        `${a + b - c}x`,
        `${a + b + c}x`,
        `${a - b + c}x`,
        `${a * b - c}x`,
      ]),
      hint: "Combine like terms.",
      steps: [`(${a} + ${b} - ${c})x`, `= ${a + b - c}x`],
      formula: "Combine coefficients of like terms",
    };
  }

  function geoAngles(d) {
    const types = [
      { name: "acute", min: 1, max: 89 },
      { name: "right", min: 90, max: 90 },
      { name: "obtuse", min: 91, max: 179 },
      { name: "straight", min: 180, max: 180 },
      { name: "reflex", min: 181, max: 359 },
    ];
    const t = pick(types);
    const angle = t.min === t.max ? t.min : R(t.min, t.max);
    return {
      question: `An angle of ${angle}° is called what?`,
      answer: t.name,
      choices: shuffle([
        t.name,
        ...shuffle(types.map((x) => x.name).filter((n) => n !== t.name)).slice(
          0,
          3,
        ),
      ]),
      hint: "Acute < 90, right = 90, obtuse 91-179, straight = 180, reflex > 180.",
      steps: [
        `${angle}° is between ${t.min}° and ${t.max}°`,
        `Type: ${t.name}`,
      ],
      formula: "Acute<90, Right=90, Obtuse 90-180, Straight=180, Reflex>180",
    };
  }

  function geoArea(d) {
    const shapes = [
      {
        n: "square",
        f: (s) => ({
          q: `Square with side ${s} cm. Find area.`,
          a: s * s,
          formula: "A = s²",
        }),
      },
      {
        n: "rectangle",
        f: (l) => {
          const w = R(2, 10);
          return {
            q: `Rectangle ${l}cm × ${w}cm. Find area.`,
            a: l * w,
            formula: "A = l × w",
          };
        },
      },
      {
        n: "triangle",
        f: (b) => {
          const h = R(2, 15);
          return {
            q: `Triangle base ${b}cm, height ${h}cm. Find area.`,
            a: (b * h) / 2,
            formula: "A = ½ × b × h",
          };
        },
      },
      {
        n: "circle",
        f: (r) => ({
          q: `Circle radius ${r}cm. Find area (use π ≈ 3.14).`,
          a: round(3.14 * r * r, 2),
          formula: "A = π × r²",
        }),
      },
    ];
    const s = pick(shapes);
    const dim = R(2, range(d, 10, 15, 20, 30));
    const r = s.f(dim);
    return {
      question: r.q,
      answer: r.a,
      choices: Number.isInteger(r.a)
        ? choices(r.a, 4, Math.max(3, Math.floor(r.a * 0.2)))
        : choicesF(r.a, 4, 2),
      hint: r.formula,
      steps: [r.formula, `Plug in values`, `= ${r.a}`],
      formula: r.formula,
    };
  }

  function geoVolume(d) {
    const shapes = [
      {
        n: "cube",
        f: (s) => ({
          q: `Cube with side ${s} cm. Find volume.`,
          a: s * s * s,
          formula: "V = s³",
        }),
      },
      {
        n: "cuboid",
        f: (l) => {
          const w = R(2, 10),
            h = R(2, 10);
          return {
            q: `Box ${l}×${w}×${h} cm. Find volume.`,
            a: l * w * h,
            formula: "V = l × w × h",
          };
        },
      },
      {
        n: "cylinder",
        f: (r) => {
          const h = R(2, 15);
          return {
            q: `Cylinder radius ${r}cm, height ${h}cm (π ≈ 3.14).`,
            a: round(3.14 * r * r * h, 2),
            formula: "V = π × r² × h",
          };
        },
      },
      {
        n: "sphere",
        f: (r) => ({
          q: `Sphere radius ${r}cm (π ≈ 3.14).`,
          a: round((4 / 3) * 3.14 * r * r * r, 2),
          formula: "V = (4/3) × π × r³",
        }),
      },
    ];
    const s = pick(shapes);
    const dim = R(2, range(d, 5, 10, 15, 20));
    const r = s.f(dim);
    return {
      question: r.q,
      answer: r.a,
      choices: Number.isInteger(r.a)
        ? choices(r.a, 4, Math.max(5, Math.floor(r.a * 0.1)))
        : choicesF(r.a, 4, 3),
      hint: r.formula,
      steps: [r.formula, `Plug in`, `= ${r.a}`],
      formula: r.formula,
    };
  }

  function pythagoras(d) {
    const a = R(3, range(d, 8, 12, 20, 30));
    const b = R(3, range(d, 8, 12, 20, 30));
    const c = round(Math.sqrt(a * a + b * b), 2);
    return {
      question: `Right triangle with legs ${a} and ${b}. Find the hypotenuse.`,
      answer: c,
      choices: choicesF(c, 4, 2),
      hint: "a² + b² = c²",
      steps: [
        `${a}² + ${b}² = c²`,
        `${a * a} + ${b * b} = c²`,
        `c² = ${a * a + b * b}`,
        `c = √${a * a + b * b} = ${c}`,
      ],
      formula: "a² + b² = c²",
    };
  }

  function meanMedianMode(d) {
    const n = range(d, 4, 5, 6, 7);
    const arr = Array.from({ length: n }, () => R(1, range(d, 10, 20, 30, 50)));
    const sorted = arr.slice().sort((a, b) => a - b);
    const sum = arr.reduce((s, x) => s + x, 0);
    const mean = round(sum / n, 2);
    const median =
      n % 2 ? sorted[(n - 1) / 2] : (sorted[n / 2 - 1] + sorted[n / 2]) / 2;
    const counts = {};
    arr.forEach((x) => (counts[x] = (counts[x] || 0) + 1));
    const maxCount = Math.max(...Object.values(counts));
    const mode =
      maxCount > 1
        ? Object.keys(counts).find((k) => counts[k] === maxCount)
        : "No mode";
    const askType = pick(["mean", "median", "mode"]);
    const ans =
      askType === "mean"
        ? mean
        : askType === "median"
          ? median
          : typeof mode === "string"
            ? mode
            : parseInt(mode);
    return {
      question: `Find the ${askType} of: ${arr.join(", ")}`,
      answer: typeof ans === "number" ? round(ans, 2) : ans,
      choices:
        typeof ans === "number"
          ? Number.isInteger(ans)
            ? choices(ans, 4, 3)
            : choicesF(ans, 4, 2)
          : ["No mode", String(mode), String(ans), String(parseInt(mode) + 1)],
      hint: `Mean = sum/count, Median = middle, Mode = most frequent.`,
      steps: [
        `Data sorted: ${sorted.join(", ")}`,
        `Mean = ${sum}/${n} = ${mean}`,
        `Median = ${median}`,
        `Mode = ${mode}`,
      ],
      formula: "Mean = Σx / n, Median = middle value, Mode = most frequent",
    };
  }

  function probBasic(d) {
    const total = range(d, 6, 10, 20, 52);
    const favorable = R(1, total - 1);
    const g = gcd(favorable, total);
    return {
      question: `A bag has ${favorable} red and ${total - favorable} blue marbles. Probability of red?`,
      answer: `${favorable / g}/${total / g}`,
      choices: shuffle([
        `${favorable / g}/${total / g}`,
        `${favorable}/${total}`,
        `${(favorable + 1) / g}/${total / g}`,
        `${favorable / g}/${(total + 1) / g}`,
      ]),
      hint: "Favorable ÷ Total",
      steps: [
        `Favorable: ${favorable}`,
        `Total: ${total}`,
        `P = ${favorable}/${total} = ${favorable / g}/${total / g}`,
      ],
      formula: "P(event) = favorable / total",
    };
  }

  function barGraph(d) {
    const labels = ["Mon", "Tue", "Wed", "Thu", "Fri"];
    const values = labels.map(() => R(2, range(d, 10, 15, 25, 50)));
    const idx = R(0, labels.length - 1);
    return {
      question: `Bar graph: ${labels.map((l, i) => `${l}=${values[i]}`).join(", ")}. What is the value for ${labels[idx]}?`,
      answer: values[idx],
      choices: choices(values[idx], 4, 3),
      hint: "Read the height of the bar.",
      steps: [`Looking at ${labels[idx]}'s bar.`, `Value = ${values[idx]}`],
      formula: "Bar height = data value",
    };
  }

  // ============================================================
  // GENERATORS (High School)
  // ============================================================
  function quadEq(d) {
    const r1 =
      R(range(d, 2, 5, 10, 15), range(d, 5, 10, 15, 20)) *
      (Math.random() < 0.5 ? -1 : 1);
    const r2 =
      R(range(d, 2, 5, 10, 15), range(d, 5, 10, 15, 20)) *
      (Math.random() < 0.5 ? -1 : 1);
    // (x - r1)(x - r2) = x² - (r1+r2)x + r1*r2
    const b = -(r1 + r2),
      c = r1 * r2;
    return {
      question: `Solve: x² ${b >= 0 ? "+" : "−"} ${Math.abs(b)}x ${c >= 0 ? "+" : "−"} ${Math.abs(c)} = 0`,
      answer: `x = ${r1}, ${r2}`,
      choices: shuffle([
        `x = ${r1}, ${r2}`,
        `x = ${r1 + 1}, ${r2 + 1}`,
        `x = ${-r1}, ${-r2}`,
        `x = ${r1}, ${-r2}`,
      ]),
      hint: "Factor: (x - r1)(x - r2) = 0",
      steps: [
        `Find two numbers that multiply to ${c} and add to ${b}.`,
        `Those are ${r1} and ${r2}.`,
        `(x - ${r1})(x - ${r2}) = 0`,
        `x = ${r1} or x = ${r2}`,
      ],
      formula: "x² + bx + c = (x - r₁)(x - r₂)",
    };
  }

  function quadFormula(d) {
    const a = R(1, 3);
    const b =
      R(range(d, 2, 4, 8, 12), range(d, 5, 8, 12, 20)) *
      (Math.random() < 0.5 ? -1 : 1);
    const c =
      R(range(d, 2, 5, 10, 15), range(d, 5, 10, 15, 25)) *
      (Math.random() < 0.5 ? -1 : 1);
    const disc = b * b - 4 * a * c;
    let ans;
    if (disc < 0) ans = "No real solutions";
    else if (disc === 0) ans = round(-b / (2 * a), 2);
    else {
      const s = Math.sqrt(disc);
      ans = `${round((-b + s) / (2 * a), 2)}, ${round((-b - s) / (2 * a), 2)}`;
    }
    return {
      question: `Use the quadratic formula: ${a}x² ${b >= 0 ? "+" : "−"} ${Math.abs(b)}x ${c >= 0 ? "+" : "−"} ${Math.abs(c)} = 0`,
      answer: ans,
      choices:
        typeof ans === "string"
          ? [
              ans,
              `x = ${-b / (2 * a)}`,
              `x = ${(-b + 1) / (2 * a)}`,
              `x = ${(-b - 1) / (2 * a)}`,
            ]
          : choicesF(ans, 4, 1),
      hint: "x = (-b ± √(b²-4ac)) / 2a",
      steps: [
        `a=${a}, b=${b}, c=${c}`,
        `Discriminant: ${b}² - 4(${a})(${c}) = ${disc}`,
        disc < 0
          ? "Negative discriminant → no real solutions."
          : `x = (-${b} ± √${disc}) / ${2 * a}`,
      ],
      formula: "x = (-b ± √(b²-4ac)) / 2a",
    };
  }

  function factoring(d) {
    const a = R(1, 5),
      b = R(2, 8);
    const expr = `${a * b}x ${Math.random() < 0.5 ? "+" : "-"} ${a * b}`;
    const ans = `${a}x ${Math.random() < 0.5 ? "+" : "-"} ${a}`;
    return {
      question: `Factor: ${expr}`,
      answer: `${a}(x ${Math.random() < 0.5 ? "+" : "-"} ${b})`,
      choices: shuffle([
        `${a}(x + ${b})`,
        `${a * b}(x + 1)`,
        `${a}(x + ${b + 1})`,
        `${b}(x + ${a})`,
      ]),
      hint: "Find GCF of coefficients and variable.",
      steps: [
        `GCF of ${a * b} and ${a * b} is ${a}`,
        `${a * b}x = ${a}·${b}x`,
        `${a * b} = ${a}·${b}`,
        `= ${a}(${b}x + ${b})`,
      ],
      formula: "Factor out GCF",
    };
  }

  function simulEq(d) {
    const x = R(1, range(d, 5, 10, 15, 20));
    const y = R(1, range(d, 5, 10, 15, 20));
    const a1 = R(1, 5),
      b1 = R(1, 5),
      a2 = R(1, 5),
      b2 = R(1, 5);
    const c1 = a1 * x + b1 * y,
      c2 = a2 * x + b2 * y;
    return {
      question: `Solve the system: ${a1}x + ${b1}y = ${c1} and ${a2}x + ${b2}y = ${c2}`,
      answer: `x = ${x}, y = ${y}`,
      choices: shuffle([
        `x = ${x}, y = ${y}`,
        `x = ${x + 1}, y = ${y}`,
        `x = ${x}, y = ${y + 1}`,
        `x = ${y}, y = ${x}`,
      ]),
      hint: "Use substitution or elimination.",
      steps: [
        `From eq1: ${a1}x + ${b1}y = ${c1}`,
        `From eq2: ${a2}x + ${b2}y = ${c2}`,
        `Solve to get x = ${x}, y = ${y}`,
      ],
      formula: "Eliminate one variable, substitute back",
    };
  }

  function inequalities(d) {
    const m = R(2, 10),
      x = R(1, 10),
      b = R(1, 20);
    const val = m * x + b;
    const op = pick(["<", ">", "≤", "≥"]);
    return {
      question: `Solve: ${m}x + ${b} ${op} ${val}`,
      answer: `x ${op} ${x}`,
      choices: shuffle([
        `x ${op} ${x}`,
        `x ${op} ${x + 1}`,
        `x ${op} ${x - 1}`,
        `x ${op} ${val}`,
      ]),
      hint: "Solve like an equation, but flip inequality if dividing by negative.",
      steps: [`${m}x ${op} ${val - b}`, `x ${op} ${(val - b) / m}`],
      formula: "ax + b op c → x op (c-b)/a (flip if / negative)",
    };
  }

  function functionsEval(d) {
    const a = R(1, 5),
      b = R(1, 10);
    const x = R(range(d, 1, 2, 5, 10), range(d, 5, 10, 15, 25));
    const ans = a * x + b;
    return {
      question: `If f(x) = ${a}x + ${b}, find f(${x}).`,
      answer: ans,
      choices: choices(ans, 4, 3),
      hint: "Substitute x in the function.",
      steps: [`f(${x}) = ${a}(${x}) + ${b}`, `= ${a * x} + ${b}`, `= ${ans}`],
      formula: "f(x) = ax + b",
    };
  }

  function domainRange(d) {
    const fns = [
      { f: "f(x) = 1/x", dom: "All reals except 0", rng: "All reals except 0" },
      { f: "f(x) = √x", dom: "x ≥ 0", rng: "y ≥ 0" },
      { f: "f(x) = x²", dom: "All reals", rng: "y ≥ 0" },
      { f: "f(x) = |x|", dom: "All reals", rng: "y ≥ 0" },
      { f: "f(x) = 1/(x-2)", dom: "x ≠ 2", rng: "y ≠ 0" },
      { f: "f(x) = log(x)", dom: "x > 0", rng: "All reals" },
    ];
    const f = pick(fns);
    const ask = pick(["domain", "range"]);
    const ans = ask === "domain" ? f.dom : f.rng;
    return {
      question: `Find the ${ask} of ${f.f}.`,
      answer: ans,
      choices: shuffle([
        ans,
        ...shuffle(
          fns
            .map((x) => (ask === "domain" ? x.dom : x.rng))
            .filter((v) => v !== ans),
        ).slice(0, 3),
      ]),
      hint: "Watch for division by zero, even roots of negatives, and logs of non-positives.",
      steps: [`${f.f}`, `Domain: ${f.dom}`, `Range: ${f.rng}`],
      formula: "Watch: ÷0, √(neg), log(≤0)",
    };
  }

  function polynomials(d) {
    const a = R(1, 5),
      b = R(1, 5),
      c = R(1, 5),
      x = R(1, 5);
    const ans = a * x * x + b * x + c;
    return {
      question: `If P(x) = ${a}x² + ${b}x + ${c}, find P(${x}).`,
      answer: ans,
      choices: choices(ans, 4, 5),
      hint: "Substitute and calculate.",
      steps: [
        `P(${x}) = ${a}(${x})² + ${b}(${x}) + ${c}`,
        `= ${a * x * x} + ${b * x} + ${c}`,
        `= ${ans}`,
      ],
      formula: "Substitute x in polynomial",
    };
  }

  function rationalExpr(d) {
    const a = R(1, 5),
      b = R(1, 5),
      x = R(1, 5);
    const num = a * x,
      den = b * x;
    const ans = num / den;
    return {
      question: `Simplify (${a}x)/(${b}x) for x ≠ 0.`,
      answer: round(a / b, 2),
      choices: choicesF(round(a / b, 2), 4, 1),
      hint: "Cancel common factors.",
      steps: [`${a}x / ${b}x`, `Cancel x`, `= ${a}/${b} = ${round(a / b, 2)}`],
      formula: "Cancel common factors",
    };
  }

  function logarithms(d) {
    const base = R(2, range(d, 5, 8, 10, 12));
    const exp = R(2, range(d, 3, 5, 6, 8));
    const val = Math.pow(base, exp);
    return {
      question: `Evaluate log_${base}(${val}).`,
      answer: exp,
      choices: choices(exp, 4, 1),
      hint: "log_b(b^x) = x",
      steps: [`${base}^? = ${val}`, `= ${exp}`],
      formula: "log_b(bˣ) = x",
    };
  }

  function arithmeticSeq(d) {
    const a1 = R(1, 10),
      dlt = R(2, range(d, 5, 10, 15, 20));
    const n = R(5, range(d, 10, 20, 30, 50));
    const ans = a1 + (n - 1) * dlt;
    return {
      question: `Arithmetic sequence: a₁ = ${a1}, d = ${dlt}. Find the ${n}th term.`,
      answer: ans,
      choices: choices(ans, 4, Math.max(5, Math.floor(ans * 0.1))),
      hint: "a_n = a_1 + (n-1)d",
      steps: [
        `a_${n} = ${a1} + (${n}-1)×${dlt}`,
        `= ${a1} + ${(n - 1) * dlt}`,
        `= ${ans}`,
      ],
      formula: "a_n = a_1 + (n-1)d",
    };
  }

  function geometricSeq(d) {
    const a1 = R(1, 5),
      r = R(2, range(d, 3, 4, 5, 7));
    const n = R(3, range(d, 5, 7, 8, 10));
    const ans = a1 * Math.pow(r, n - 1);
    return {
      question: `Geometric sequence: a₁ = ${a1}, r = ${r}. Find the ${n}th term.`,
      answer: ans,
      choices: choices(ans, 4, Math.max(5, Math.floor(ans * 0.2))),
      hint: "a_n = a_1 × r^(n-1)",
      steps: [
        `a_${n} = ${a1} × ${r}^(${n}-1)`,
        `= ${a1} × ${Math.pow(r, n - 1)}`,
        `= ${ans}`,
      ],
      formula: "a_n = a_1 × r^(n-1)",
    };
  }

  function binomial(d) {
    const n = R(3, 6),
      k = R(1, n - 1);
    const ans = binomCoeff(n, k);
    return {
      question: `Find C(${n}, ${k}) — the binomial coefficient.`,
      answer: ans,
      choices: choices(ans, 4, Math.max(3, Math.floor(ans * 0.2))),
      hint: "C(n,k) = n! / (k! × (n-k)!)",
      steps: [
        `C(${n}, ${k}) = ${n}! / (${k}! × ${n - k}!)`,
        `= ${factorial(n)} / (${factorial(k)} × ${factorial(n - k)})`,
        `= ${ans}`,
      ],
      formula: "C(n,k) = n! / (k!(n-k)!)",
    };
  }
  function factorial(n) {
    let r = 1;
    for (let i = 2; i <= n; i++) r *= i;
    return r;
  }
  function binomCoeff(n, k) {
    return factorial(n) / (factorial(k) * factorial(n - k));
  }

  function trigBasic(d) {
    const angles = [
      { deg: 0, sin: 0, cos: 1, tan: 0 },
      { deg: 30, sin: 0.5, cos: 0.866, tan: 0.577 },
      { deg: 45, sin: 0.707, cos: 0.707, tan: 1 },
      { deg: 60, sin: 0.866, cos: 0.5, tan: 1.732 },
      { deg: 90, sin: 1, cos: 0, tan: "undefined" },
    ];
    const a = pick(angles);
    const fn = pick(["sin", "cos", "tan"]);
    const val = a[fn];
    const ans = typeof val === "number" ? round(val, 3) : val;
    return {
      question: `Find ${fn}(${a.deg}°).`,
      answer: ans,
      choices:
        typeof val === "number"
          ? choicesF(ans, 4, 0.2)
          : ["undefined", "0", "1", "0.5"],
      hint: "Memorize the standard angles (0°, 30°, 45°, 60°, 90°).",
      steps: [`${fn}(${a.deg}°) = ${ans}`],
      formula: "SOH-CAH-TOA for right triangles",
    };
  }

  function trigIdentities(d) {
    const ids = [
      { q: "sin²θ + cos²θ = ?", a: "1" },
      { q: "1 + tan²θ = ?", a: "sec²θ" },
      { q: "1 + cot²θ = ?", a: "csc²θ" },
      { q: "sin(2θ) = ?", a: "2 sinθ cosθ" },
      { q: "cos(2θ) = ?", a: "cos²θ - sin²θ" },
      { q: "tan(θ) = ?", a: "sinθ/cosθ" },
      { q: "sec(θ) = ?", a: "1/cosθ" },
    ];
    const x = pick(ids);
    return {
      question: x.q,
      answer: x.a,
      choices: shuffle(
        [x.a, "2", "sinθ", "cosθ", "tanθ"]
          .filter((v) => v !== x.a)
          .slice(0, 3)
          .concat([x.a]),
      ),
      hint: "Memorize the fundamental trig identities.",
      steps: [`Identity: ${x.q} ${x.a}`],
      formula: "sin²+cos²=1, 1+tan²=sec², 1+cot²=csc²",
    };
  }

  function trigEq(d) {
    const angles = [0, 30, 90, 150, 180];
    const a = pick(angles);
    return {
      question: `Solve: sin(θ) = ${round(Math.sin((a * Math.PI) / 180), 3)} for 0° ≤ θ ≤ 180°.`,
      answer: `${a}°`,
      choices: shuffle([`${a}°`, `${a + 30}°`, `${180 - a}°`, `${a + 90}°`]),
      hint: "Use inverse sin.",
      steps: [
        `sin(θ) = ${round(Math.sin((a * Math.PI) / 180), 3)}`,
        `θ = ${a}° or ${180 - a}°`,
      ],
      formula: "sin(θ) = v → θ = arcsin(v)",
    };
  }

  function circles(d) {
    const r = R(2, range(d, 5, 10, 15, 25));
    const ask = pick(["circumference", "area"]);
    const ans =
      ask === "circumference" ? round(2 * 3.14 * r, 2) : round(3.14 * r * r, 2);
    return {
      question: `Circle radius ${r}cm. Find ${ask}.`,
      answer: ans,
      choices: choicesF(ans, 4, 2),
      hint: ask === "circumference" ? "C = 2πr" : "A = πr²",
      steps: [
        ask === "circumference" ? `2 × 3.14 × ${r}` : `3.14 × ${r}²`,
        `= ${ans}`,
      ],
      formula: ask === "circumference" ? "C = 2πr" : "A = πr²",
    };
  }

  function triangles(d) {
    const types = [
      { name: "equilateral", desc: "3 equal sides" },
      { name: "isosceles", desc: "2 equal sides" },
      { name: "scalene", desc: "no equal sides" },
      { name: "right", desc: "one 90° angle" },
      { name: "acute", desc: "all angles < 90°" },
      { name: "obtuse", desc: "one angle > 90°" },
    ];
    const t = pick(types);
    return {
      question: `A triangle with ${t.desc} is called __?`,
      answer: t.name,
      choices: shuffle([
        t.name,
        ...shuffle(
          types.filter((x) => x.name !== t.name).map((x) => x.name),
        ).slice(0, 3),
      ]),
      hint: "Classify by sides or angles.",
      steps: [`${t.desc} → ${t.name}`],
      formula:
        "By sides: equilateral/isosceles/scalene; by angles: right/acute/obtuse",
    };
  }

  function vectors2d(d) {
    const ax = R(1, 10),
      ay = R(1, 10),
      bx = R(1, 10),
      by = R(1, 10);
    const cx = ax + bx,
      cy = ay + by;
    const mag = round(Math.sqrt(cx * cx + cy * cy), 2);
    return {
      question: `Vector A = (${ax}, ${ay}), B = (${bx}, ${by}). Find |A + B|.`,
      answer: mag,
      choices: choicesF(mag, 4, 2),
      hint: "Add components, then find magnitude.",
      steps: [
        `A + B = (${ax}+${bx}, ${ay}+${by}) = (${cx}, ${cy})`,
        `|A+B| = √(${cx}² + ${cy}²)`,
        `= √(${cx * cx} + ${cy * cy})`,
        `= ${mag}`,
      ],
      formula: "|v| = √(x² + y²)",
    };
  }

  function matrices(d) {
    const a = R(1, 10),
      b = R(1, 10),
      c = R(1, 10),
      e = R(1, 10);
    const det = a * e - b * c;
    return {
      question: `Find the determinant of [[${a}, ${b}], [${c}, ${e}]].`,
      answer: det,
      choices: choices(det, 4, Math.max(3, Math.abs(det) * 0.3)),
      hint: "det = ad - bc",
      steps: [
        `det = (${a})(${e}) - (${b})(${c})`,
        `= ${a * e} - ${b * c}`,
        `= ${det}`,
      ],
      formula: "det([[a,b],[c,d]]) = ad - bc",
    };
  }

  function complex(d) {
    const a = R(1, 10),
      b = R(1, 10);
    const c = R(1, 10),
      e = R(1, 10);
    return {
      question: `Add: (${a} + ${b}i) + (${c} + ${e}i)`,
      answer: `${a + c} + ${b + e}i`,
      choices: shuffle([
        `${a + c} + ${b + e}i`,
        `${a + c} + ${b - e}i`,
        `${a - c} + ${b + e}i`,
        `${a * c} + ${b * e}i`,
      ]),
      hint: "Add real parts, add imaginary parts.",
      steps: [
        `Real: ${a} + ${c} = ${a + c}`,
        `Imaginary: ${b}i + ${e}i = ${b + e}i`,
        `Sum: ${a + c} + ${b + e}i`,
      ],
      formula: "(a+bi) + (c+di) = (a+c) + (b+d)i",
    };
  }

  function conics(d) {
    const conics = [
      { eq: "x² + y² = r²", name: "circle" },
      { eq: "x²/a² + y²/b² = 1", name: "ellipse" },
      { eq: "x²/a² - y²/b² = 1", name: "hyperbola" },
      { eq: "y² = 4ax", name: "parabola" },
    ];
    const c = pick(conics);
    return {
      question: `What conic section is: ${c.eq}?`,
      answer: c.name,
      choices: shuffle([
        c.name,
        ...shuffle(
          conics.filter((x) => x.name !== c.name).map((x) => x.name),
        ).slice(0, 3),
      ]),
      hint: "Look at signs and degrees.",
      steps: [c.eq, `→ ${c.name}`],
      formula:
        "Circle (+=), Ellipse (+/+), Hyperbola (-), Parabola (one var squared)",
    };
  }

  function limits(d) {
    const fns = [
      {
        q: "lim(x→2) (x² - 4)/(x - 2)",
        a: 4,
        steps: ["Factor: (x-2)(x+2)/(x-2)", "Cancel: x+2", "At x=2: 4"],
      },
      { q: "lim(x→0) sin(x)/x", a: 1, steps: ["Standard limit", "= 1"] },
      {
        q: "lim(x→3) (x² - 9)/(x - 3)",
        a: 6,
        steps: ["Factor: (x-3)(x+3)/(x-3)", "Cancel: x+3", "At x=3: 6"],
      },
      { q: "lim(x→∞) 1/x", a: 0, steps: ["1/∞ → 0"] },
      {
        q: "lim(x→0) (1 - cos x)/x²",
        a: 0.5,
        steps: ["L'Hôpital twice", "= 1/2"],
      },
    ];
    const f = pick(fns);
    return {
      question: f.q,
      answer: f.a,
      choices:
        typeof f.a === "number"
          ? Number.isInteger(f.a)
            ? choices(f.a, 4, 1)
            : choicesF(f.a, 4, 0.3)
          : [f.a, "∞", "-∞", "DNE"],
      hint: "Try direct substitution first, then factoring.",
      steps: f.steps,
      formula: "lim(x→a) f(x) = L",
    };
  }

  function derivatives(d) {
    const fns = [
      { f: "x³", d: "3x²" },
      { f: "x⁵", d: "5x⁴" },
      { f: "sin(x)", d: "cos(x)" },
      { f: "cos(x)", d: "-sin(x)" },
      { f: "eˣ", d: "eˣ" },
      { f: "ln(x)", d: "1/x" },
      { f: "x⁻²", d: "-2x⁻³" },
      { f: "5x²", d: "10x" },
    ];
    const f = pick(fns);
    return {
      question: `Find d/dx of ${f.f}.`,
      answer: f.d,
      choices: shuffle([
        f.d,
        ...shuffle(fns.filter((x) => x.d !== f.d).map((x) => x.d)).slice(0, 3),
      ]),
      hint: "Power rule: d/dx(xⁿ) = n·xⁿ⁻¹",
      steps: [`f(x) = ${f.f}`, `f'(x) = ${f.d}`],
      formula: "d/dx(xⁿ) = n·xⁿ⁻¹",
    };
  }

  function integrals(d) {
    const fns = [
      { f: "x²", F: "x³/3 + C" },
      { f: "x³", F: "x⁴/4 + C" },
      { f: "2x", F: "x² + C" },
      { f: "1/x", F: "ln|x| + C" },
      { f: "eˣ", F: "eˣ + C" },
      { f: "cos(x)", F: "sin(x) + C" },
      { f: "sin(x)", F: "-cos(x) + C" },
    ];
    const f = pick(fns);
    return {
      question: `Find ∫ ${f.f} dx.`,
      answer: f.F,
      choices: shuffle([
        f.F,
        ...shuffle(fns.filter((x) => x.F !== f.F).map((x) => x.F)).slice(0, 3),
      ]),
      hint: "Reverse the derivative. Add +C.",
      steps: [`∫ ${f.f} dx`, `= ${f.F}`],
      formula: "∫ xⁿ dx = xⁿ⁺¹/(n+1) + C",
    };
  }

  function stddev(d) {
    const arr = [4, 8, 6, 5, 7];
    const mean = 6;
    const variance = arr.reduce((s, x) => s + (x - mean) ** 2, 0) / arr.length;
    const sd = round(Math.sqrt(variance), 3);
    return {
      question: `Find the standard deviation of: ${arr.join(", ")} (mean = ${mean}).`,
      answer: sd,
      choices: choicesF(sd, 4, 0.5),
      hint: "σ = √(Σ(x - μ)² / n)",
      steps: [
        `Mean μ = ${mean}`,
        `Variance σ² = ${Math.pow(5 - 6, 2) + Math.pow(8 - 6, 2) + Math.pow(6 - 6, 2) + Math.pow(5 - 6, 2) + Math.pow(7 - 6, 2)}/${arr.length} = ${variance}`,
        `σ = √${variance} = ${sd}`,
      ],
      formula: "σ = √(Σ(x-μ)²/n)",
    };
  }

  function permsCombs(d) {
    const n = R(4, range(d, 5, 8, 10, 12));
    const r = R(2, n - 1);
    const isPerm = Math.random() < 0.5;
    const ans = isPerm ? factorial(n) / factorial(n - r) : binomCoeff(n, r);
    return {
      question: `Find ${isPerm ? `P(${n}, ${r})` : `C(${n}, ${r})`}.`,
      answer: ans,
      choices: choices(ans, 4, Math.max(5, Math.floor(ans * 0.1))),
      hint: isPerm ? "P(n,r) = n!/(n-r)!" : "C(n,r) = n!/(r!(n-r)!)",
      steps: isPerm
        ? [
            `${n}!/(${n}-${r})!`,
            `= ${factorial(n)}/${factorial(n - r)}`,
            `= ${ans}`,
          ]
        : [
            `${n}!/(${r}! × ${n - r}!)`,
            `= ${factorial(n)}/(${factorial(r)} × ${factorial(n - r)})`,
            `= ${ans}`,
          ],
      formula: isPerm ? "P(n,r) = n!/(n-r)!" : "C(n,r) = n!/(r!(n-r)!)",
    };
  }

  function setTheory(d) {
    const a = R(2, 10),
      b = R(2, 10),
      inter = R(1, Math.min(a, b) - 1);
    const union = a + b - inter;
    return {
      question: `If n(A) = ${a}, n(B) = ${b}, n(A∩B) = ${inter}, find n(A∪B).`,
      answer: union,
      choices: choices(union, 4, 2),
      hint: "n(A∪B) = n(A) + n(B) - n(A∩B)",
      steps: [`n(A∪B) = ${a} + ${b} - ${inter}`, `= ${union}`],
      formula: "n(A∪B) = n(A) + n(B) - n(A∩B)",
    };
  }

  function numberTheory(d) {
    const types = [
      { q: "Is 17 prime?", a: "Yes" },
      { q: "What is the smallest prime?", a: 2 },
      { q: "How many primes are below 10?", a: 4 },
      { q: "Is 1 a prime number?", a: "No" },
      { q: "What is GCD(12, 18)?", a: 6 },
      { q: "What is LCM(4, 6)?", a: 12 },
    ];
    const t = pick(types);
    return {
      question: t.q,
      answer: t.a,
      choices:
        typeof t.a === "number"
          ? choices(t.a, 4, 2)
          : [t.a, t.a === "Yes" ? "No" : "Yes"],
      hint: "Prime numbers have only 1 and themselves as factors.",
      steps: [t.q, `Answer: ${t.a}`],
      formula: "Prime: divisors are 1 and itself",
    };
  }

  function compoundInterest(d) {
    const P = R(1000, 10000) * (d === "easy" ? 1 : 5);
    const r = R(5, 15) / 100;
    const n = 1; // annually
    const t = R(2, 5);
    const A = round(P * Math.pow(1 + r / n, n * t), 2);
    return {
      question: `Find the amount: P = ₹${P}, r = ${r * 100}%, compounded annually for ${t} years.`,
      answer: A,
      choices: choicesF(A, 4, A * 0.1),
      hint: "A = P(1 + r/n)^(nt)",
      steps: [
        `A = ${P}(1 + ${r})^${t}`,
        `= ${P} × ${Math.pow(1 + r, t).toFixed(3)}`,
        `= ${A}`,
      ],
      formula: "A = P(1 + r/n)^(nt)",
    };
  }

  // ============================================================
  // GENERATORS (College)
  // ============================================================
  function derivativesAdv(d) {
    const fns = [
      { f: "x²·sin(x)", d: "2x sin(x) + x² cos(x)", rule: "Product rule" },
      { f: "sin(x)/x", d: "(x cos(x) - sin(x))/x²", rule: "Quotient rule" },
      { f: "sin(x²)", d: "2x cos(x²)", rule: "Chain rule" },
      { f: "e^(3x)", d: "3e^(3x)", rule: "Chain rule" },
      { f: "ln(x²)", d: "2/x", rule: "Chain rule" },
      { f: "tan(x)", d: "sec²(x)", rule: "Identity" },
    ];
    const f = pick(fns);
    return {
      question: `Find d/dx [${f.f}]. (${f.rule})`,
      answer: f.d,
      choices: shuffle([
        f.d,
        ...shuffle(fns.filter((x) => x.d !== f.d).map((x) => x.d)).slice(0, 3),
      ]),
      hint: `Use the ${f.rule}.`,
      steps: [`${f.rule} for ${f.f}`, `= ${f.d}`],
      formula: f.rule,
    };
  }

  function integralsAdv(d) {
    const fns = [
      { f: "x·eˣ", F: "eˣ(x-1) + C", rule: "By parts" },
      { f: "x·cos(x)", F: "x sin(x) + cos(x) + C", rule: "By parts" },
      { f: "1/(1+x²)", F: "arctan(x) + C", rule: "Standard" },
      { f: "1/√(1-x²)", F: "arcsin(x) + C", rule: "Standard" },
      { f: "x/(x²+1)", F: "½ln(x²+1) + C", rule: "Substitution" },
    ];
    const f = pick(fns);
    return {
      question: `Evaluate ∫ ${f.f} dx. (${f.rule})`,
      answer: f.F,
      choices: shuffle([
        f.F,
        ...shuffle(fns.filter((x) => x.F !== f.F).map((x) => x.F)).slice(0, 3),
      ]),
      hint: f.rule,
      steps: [`${f.rule}`, `∫ ${f.f} dx = ${f.F}`],
      formula: f.rule,
    };
  }

  function seriesConvergence(d) {
    const series = [
      { q: "Σ (1/n!) from n=0 to ∞", a: "Converges (to e)" },
      { q: "Σ (1/n) from n=1 to ∞", a: "Diverges (harmonic)" },
      { q: "Σ (1/n²) from n=1 to ∞", a: "Converges (to π²/6)" },
      { q: "Σ rⁿ for |r|<1", a: "Converges" },
      { q: "Σ rⁿ for |r|≥1", a: "Diverges" },
    ];
    const s = pick(series);
    return {
      question: `Does the series ${s.q} converge or diverge?`,
      answer: s.a,
      choices: shuffle(
        [s.a, "Converges", "Diverges", "Inconclusive"]
          .filter((v, i, arr) => arr.indexOf(v) === i)
          .slice(0, 4),
      ),
      hint: "Use ratio test, comparison test, or known results.",
      steps: [s.q, s.a],
      formula: "Geometric: |r|<1 converges; harmonic diverges",
    };
  }

  function differentialEq(d) {
    const eqs = [
      { q: "dy/dx = 0", a: "y = C" },
      { q: "dy/dx = k", a: "y = kx + C" },
      { q: "dy/dx = ky", a: "y = C·e^(kx)" },
      { q: "d²y/dx² = 0", a: "y = Ax + B" },
      { q: "d²y/dx² + y = 0", a: "y = A·cos(x) + B·sin(x)" },
    ];
    const e = pick(eqs);
    return {
      question: `Solve the differential equation: ${e.q}`,
      answer: e.a,
      choices: shuffle([
        e.a,
        ...shuffle(eqs.filter((x) => x.a !== e.a).map((x) => x.a)).slice(0, 3),
      ]),
      hint: "Integrate both sides.",
      steps: [e.q, "Integrate", e.a],
      formula: "Integrate to find general solution",
    };
  }

  function partialDeriv(d) {
    const fns = [
      { f: "f(x,y) = x²y", dx: "2xy", dy: "x²" },
      { f: "f(x,y) = x³ + y³", dx: "3x²", dy: "3y²" },
      { f: "f(x,y) = xy", dx: "y", dy: "x" },
      { f: "f(x,y) = sin(xy)", dx: "y cos(xy)", dy: "x cos(xy)" },
    ];
    const f = pick(fns);
    const wrt = pick(["x", "y"]);
    const ans = wrt === "x" ? f.dx : f.dy;
    return {
      question: `Find ∂f/∂${wrt} for ${f.f}.`,
      answer: ans,
      choices: shuffle([
        ans,
        ...shuffle(
          fns.flatMap((x) => [x.dx, x.dy]).filter((v) => v !== ans),
        ).slice(0, 3),
      ]),
      hint: `Treat ${wrt === "x" ? "y" : "x"} as a constant.`,
      steps: [f.f, `∂/∂${wrt}: treat other variable as constant`, ans],
      formula: "Partial derivative: hold other variables constant",
    };
  }

  function multivariable(d) {
    const fns = [
      { q: "Find gradient of f(x,y) = x² + y²", a: "∇f = (2x, 2y)" },
      { q: "Find gradient of f(x,y) = xy", a: "∇f = (y, x)" },
      { q: "Find gradient of f(x,y,z) = x + y + z", a: "∇f = (1, 1, 1)" },
    ];
    const f = pick(fns);
    return {
      question: f.q,
      answer: f.a,
      choices: shuffle(
        [f.a, "(x, y)", "(1, 1)", "(0, 0)"]
          .filter((v, i, arr) => arr.indexOf(v) === i)
          .slice(0, 4),
      ),
      hint: "Gradient = vector of partial derivatives.",
      steps: [f.q, f.a],
      formula: "∇f = (∂f/∂x, ∂f/∂y, ...)",
    };
  }

  function linearAlgebra(d) {
    const qs = [
      { q: "A matrix with m rows and n columns has dimension?", a: "m × n" },
      {
        q: "A square matrix has how many equal values?",
        a: "Same rows and columns",
      },
      {
        q: "Identity matrix has 1s on ___ and 0s elsewhere.",
        a: "Main diagonal",
      },
      { q: "Matrix A is invertible iff det(A) ≠ ?", a: "0" },
    ];
    const q = pick(qs);
    return {
      question: q.q,
      answer: q.a,
      choices: shuffle(
        [q.a, "0", "1", "Infinity"]
          .filter((v) => v !== q.a)
          .slice(0, 3)
          .concat([q.a]),
      ),
      hint: "Linear algebra fundamentals.",
      steps: [q.q, q.a],
      formula: "Matrix dimensions: rows × columns",
    };
  }

  function eigenvalues(d) {
    return {
      question: "For matrix [[2, 0], [0, 3]], what are the eigenvalues?",
      answer: "2 and 3",
      choices: shuffle(["2 and 3", "1 and 6", "5 and 0", "6 and -1"]),
      hint: "For diagonal matrices, eigenvalues are the diagonal entries.",
      steps: ["Diagonal matrix", "Eigenvalues = diagonal entries", "= 2 and 3"],
      formula: "det(A - λI) = 0",
    };
  }

  function matrixOps(d) {
    const a = R(1, 9),
      b = R(1, 9),
      c = R(1, 9),
      e = R(1, 9);
    return {
      question: `Add: [[${a},${b}],[${c},${e}]] + [[1,1],[1,1]]`,
      answer: `[[${a + 1},${b + 1}],[${c + 1},${e + 1}]]`,
      choices: shuffle([
        `[[${a + 1},${b + 1}],[${c + 1},${e + 1}]]`,
        `[[${a - 1},${b - 1}],[${c - 1},${e - 1}]]`,
        `[[${a + 1},${b + 1}],[${c},${e}]]`,
        `[[${a},${b}],[${c + 1},${e + 1}]]`,
      ]),
      hint: "Add element by element.",
      steps: [
        `[[${a}+1, ${b}+1], [${c}+1, ${e}+1]]`,
        `= [[${a + 1}, ${b + 1}], [${c + 1}, ${e + 1}]]`,
      ],
      formula: "Add corresponding elements",
    };
  }

  function vectorCalc(d) {
    const qs = [
      { q: "∇·F is called the ___ of F.", a: "divergence" },
      { q: "∇×F is called the ___ of F.", a: "curl" },
      { q: "∇f is called the ___ of f.", a: "gradient" },
    ];
    const q = pick(qs);
    return {
      question: q.q,
      answer: q.a,
      choices: shuffle([
        q.a,
        ...["divergence", "curl", "gradient", "Laplacian"]
          .filter((v) => v !== q.a)
          .slice(0, 3),
      ]),
      hint: "Vector calculus operators.",
      steps: [q.q, q.a],
      formula: "∇· = div, ∇× = curl, ∇f = grad",
    };
  }

  function discreteMath(d) {
    const qs = [
      { q: "In a graph with 5 vertices, max edges in simple graph?", a: 10 },
      { q: "Boolean: 1 AND 0 = ?", a: 0 },
      { q: "Boolean: 1 OR 0 = ?", a: 1 },
      { q: "Boolean: NOT 1 = ?", a: 0 },
      { q: "How many bits in a byte?", a: 8 },
      { q: "Binary 1010 = decimal?", a: 10 },
    ];
    const q = pick(qs);
    return {
      question: q.q,
      answer: q.a,
      choices:
        typeof q.a === "number" ? choices(q.a, 4, 2) : [q.a, q.a === 0 ? 1 : 0],
      hint: "Discrete math fundamentals.",
      steps: [q.q, q.a],
      formula: "Discrete math logic & combinatorics",
    };
  }

  function graphTheory(d) {
    const qs = [
      { q: "A tree with n vertices has how many edges?", a: "n-1" },
      { q: "In a complete graph K_n, how many edges?", a: "n(n-1)/2" },
      { q: "Euler's formula: V - E + F = ?", a: 2 },
      {
        q: "A graph where every vertex has even degree has an ___ circuit.",
        a: "Euler",
      },
    ];
    const q = pick(qs);
    return {
      question: q.q,
      answer: q.a,
      choices: shuffle(
        [q.a, "n", "n+1", "2n"]
          .filter((v, i, arr) => arr.indexOf(v) === i)
          .slice(0, 4),
      ),
      hint: "Graph theory basics.",
      steps: [q.q, q.a],
      formula: "Tree: n-1 edges; K_n: n(n-1)/2 edges",
    };
  }

  function booleanAlgebra(d) {
    const qs = [
      { q: "A AND (B OR C) = ?", a: "(A AND B) OR (A AND C)" },
      { q: "NOT (A AND B) = ?", a: "(NOT A) OR (NOT B)" },
      { q: "A OR (NOT A) = ?", a: "1 (TRUE)" },
      { q: "A AND (NOT A) = ?", a: "0 (FALSE)" },
    ];
    const q = pick(qs);
    return {
      question: q.q,
      answer: q.a,
      choices: shuffle([q.a, "A AND B", "A OR B", "NOT A"]),
      hint: "De Morgan's laws and identities.",
      steps: [q.q, q.a],
      formula: "De Morgan: ¬(A∧B) = ¬A ∨ ¬B",
    };
  }

  function probAdv(d) {
    const qs = [
      { q: "P(A∪B) when independent, P(A)=0.3, P(B)=0.4?", a: 0.58 },
      { q: "Expected value of fair die roll?", a: 3.5 },
      { q: "Variance of fair die?", a: 2.917 },
      { q: "P(at least one 6 in 4 rolls?", a: 0.518 },
    ];
    const q = pick(qs);
    return {
      question: q.q,
      answer: q.a,
      choices: choicesF(q.a, 4, q.a * 0.2),
      hint: "Use probability rules: P(A∪B) = P(A) + P(B) - P(A∩B)",
      steps: [q.q, q.a],
      formula: "P(A∪B) = P(A) + P(B) - P(A∩B)",
    };
  }

  function bayes(d) {
    return {
      question:
        "A disease affects 1% of population. Test is 95% accurate. If positive, what's the chance you have it? (Bayesian update)",
      answer: "About 16% (low due to base rate)",
      choices: ["About 16% (low due to base rate)", "95%", "99%", "About 50%"],
      hint: "Bayes: posterior depends on prior and likelihood.",
      steps: [
        "P(D) = 0.01, P(+|D) = 0.95, P(+|¬D) = 0.05",
        "P(D|+) = P(+|D)P(D) / P(+)",
        "P(+) = 0.95·0.01 + 0.05·0.99 = 0.059",
        "P(D|+) = 0.0095/0.059 ≈ 0.16",
      ],
      formula: "P(A|B) = P(B|A)·P(A) / P(B)",
    };
  }

  function hypothesis(d) {
    return {
      question: "If p-value < 0.05, we ___ the null hypothesis.",
      answer: "reject",
      choices: shuffle(["reject", "accept", "fail to reject", "confirm"]),
      hint: "Significance level α = 0.05 standard.",
      steps: ["α = 0.05", "p < α", "Reject H₀"],
      formula: "p < α → reject H₀",
    };
  }

  function regression(d) {
    return {
      question: "In y = mx + b, what is m?",
      answer: "slope",
      choices: shuffle(["slope", "intercept", "correlation", "residual"]),
      hint: "Slope-intercept form.",
      steps: ["y = mx + b", "m = slope, b = y-intercept"],
      formula: "m = (n·Σxy - Σx·Σy) / (n·Σx² - (Σx)²)",
    };
  }

  function fourier(d) {
    return {
      question:
        "Fourier series decomposes a periodic function into ___ and ___.",
      answer: "sines and cosines",
      choices: shuffle([
        "sines and cosines",
        "polynomials",
        "exponentials only",
        "tangents",
      ]),
      hint: "Fourier uses trig functions.",
      steps: ["f(t) = a₀/2 + Σ[aₙcos(nωt) + bₙsin(nωt)]"],
      formula: "f(t) = Σ [aₙcos + bₙsin]",
    };
  }

  function laplace(d) {
    const fns = [
      { f: "1", L: "1/s" },
      { f: "e^(at)", L: "1/(s-a)" },
      { f: "sin(at)", L: "a/(s²+a²)" },
      { f: "cos(at)", L: "s/(s²+a²)" },
      { f: "t", L: "1/s²" },
    ];
    const f = pick(fns);
    return {
      question: `Find L{${f.f}}(s).`,
      answer: f.L,
      choices: shuffle([
        f.L,
        ...shuffle(fns.filter((x) => x.L !== f.L).map((x) => x.L)).slice(0, 3),
      ]),
      hint: "Laplace transform tables.",
      steps: [`L{${f.f}} = ${f.L}`],
      formula: "L{f(t)} = ∫₀^∞ e^(-st) f(t) dt",
    };
  }

  function taylorSeries(d) {
    const fns = [
      { f: "eˣ", t: "Σ xⁿ/n! (about 0)" },
      { f: "sin(x)", t: "Σ (-1)ⁿ x^(2n+1)/(2n+1)! (about 0)" },
      { f: "cos(x)", t: "Σ (-1)ⁿ x^(2n)/(2n)! (about 0)" },
      { f: "1/(1-x)", t: "Σ xⁿ (about 0)" },
    ];
    const f = pick(fns);
    return {
      question: `Taylor series of ${f.f} about 0 (Maclaurin)?`,
      answer: f.t,
      choices: shuffle([
        f.t,
        ...shuffle(fns.filter((x) => x.t !== f.t).map((x) => x.t)).slice(0, 3),
      ]),
      hint: "f(x) = Σ f⁽ⁿ⁾(0) xⁿ/n!",
      steps: [`f(x) = ${f.f}`, `Maclaurin: ${f.t}`],
      formula: "f(x) = Σ f⁽ⁿ⁾(0)·xⁿ/n!",
    };
  }

  function complexAnalysis(d) {
    const qs = [
      { q: "Euler's formula: e^(iθ) = ?", a: "cos θ + i sin θ" },
      { q: "i² = ?", a: -1 },
      { q: "|3 + 4i| = ?", a: 5 },
      { q: "Argument of i?", a: "π/2" },
    ];
    const q = pick(qs);
    return {
      question: q.q,
      answer: q.a,
      choices:
        typeof q.a === "number"
          ? choices(q.a, 4, 2)
          : shuffle([String(q.a), "cos θ - i sin θ", "1", "i²"]),
      hint: "Complex analysis basics.",
      steps: [q.q, q.a],
      formula: "e^(iθ) = cos θ + i sin θ",
    };
  }

  function topology(d) {
    const qs = [
      { q: "A coffee mug is topologically equivalent to a ___.", a: "donut" },
      { q: "How many holes does a sphere have?", a: 0 },
      { q: "How many holes does a torus have?", a: 1 },
      {
        q: "A set is ___ if every sequence has a convergent subsequence.",
        a: "compact",
      },
    ];
    const q = pick(qs);
    return {
      question: q.q,
      answer: q.a,
      choices:
        typeof q.a === "number"
          ? choices(q.a, 4, 1)
          : shuffle([q.a, "sphere", "cube", "plane"]),
      hint: "Topology studies properties preserved under continuous deformation.",
      steps: [q.q, q.a],
      formula: "Homeomorphism preserves topological properties",
    };
  }

  function abstractAlgebra(d) {
    const qs = [
      {
        q: "A group must have which 4 properties?",
        a: "Closure, Associativity, Identity, Inverse",
      },
      {
        q: "A ring has ___ and ___ operations.",
        a: "addition and multiplication",
      },
      {
        q: "A field is a ring where every non-zero element has a ___.",
        a: "multiplicative inverse",
      },
      { q: "Z (integers) form a ___ under addition.", a: "group" },
    ];
    const q = pick(qs);
    return {
      question: q.q,
      answer: q.a,
      choices: shuffle([
        q.a,
        "Identity only",
        "Associativity only",
        "Closure only",
      ]),
      hint: "Abstract algebra: groups, rings, fields.",
      steps: [q.q, q.a],
      formula: "Group: closure, assoc, identity, inverse",
    };
  }

  function numericalMethods(d) {
    const qs = [
      { q: "Newton's method: x_(n+1) = x_n - ?", a: "f(x_n)/f'(x_n)" },
      {
        q: "Trapezoidal rule approximates ___ with trapezoids.",
        a: "integrals",
      },
      {
        q: "Simpson's rule uses ___ degree polynomials.",
        a: "second (quadratic)",
      },
      { q: "Euler's method approximates ___ equations.", a: "differential" },
    ];
    const q = pick(qs);
    return {
      question: q.q,
      answer: q.a,
      choices: shuffle([q.a, "f(x_n)", "f'(x_n)", "f(x_n)·f'(x_n)"]),
      hint: "Numerical methods for approximating solutions.",
      steps: [q.q, q.a],
      formula: "Newton: x_{n+1} = x_n - f(x_n)/f'(x_n)",
    };
  }

  function optimization(d) {
    const qs = [
      { q: "At a local extremum, f'(x) = ?", a: 0 },
      { q: "For max, f''(x) must be ___ 0.", a: "less than" },
      { q: "Lagrange multipliers use λ for ___ constraints.", a: "equality" },
      {
        q: "Convex functions have ___ local minima that are also global.",
        a: "all",
      },
    ];
    const q = pick(qs);
    return {
      question: q.q,
      answer: q.a,
      choices:
        typeof q.a === "number"
          ? choices(q.a, 4, 1)
          : shuffle([q.a, "greater than", "equal to", "not equal to"]),
      hint: "Optimization finds extrema.",
      steps: [q.q, q.a],
      formula: "Extremum: f'=0, check f''",
    };
  }

  // ---------- Public API ----------
  function generate(topicId, difficulty) {
    const topic = TOPICS.find((t) => t.id === topicId);
    if (!topic) {
      // fallback
      return addBasic(difficulty);
    }
    try {
      const problem = topic.gen(difficulty);
      problem.topicId = topicId;
      problem.topicName = topic.name;
      problem.group = topic.group;
      problem.icon = topic.icon;
      problem.difficulty = difficulty;
      return problem;
    } catch (e) {
      console.error("Generator failed for", topicId, e);
      return addBasic(difficulty);
    }
  }

  function getTopics() {
    return TOPICS;
  }
  function getTopicsByGroup(group) {
    return TOPICS.filter((t) => t.group === group);
  }
  function getTopic(id) {
    return TOPICS.find((t) => t.id === id);
  }

  return {
    TOPICS,
    generate,
    getTopics,
    getTopicsByGroup,
    getTopic,
    shuffle,
    choices,
    factorial,
    gcd,
    lcm,
  };
})();
