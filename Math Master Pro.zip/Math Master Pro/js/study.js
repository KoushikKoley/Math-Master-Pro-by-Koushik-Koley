/* ============================================================
   MathMaster Pro - study.js by Koushik Koley
   Study materials, formula references, tutorials,
   concept explanations for each topic — used for
   "study preparation before starting the game"
   ============================================================ */

const Study = (function () {
  "use strict";

  // ============================================================
  // TOPIC STUDY MATERIALS - Each topic has concept, formula,
  // steps, examples, common mistakes, tips
  // ============================================================
  const MATERIALS = {
    counting: {
      concept:
        "Counting is the foundation of mathematics. It is the process of determining how many objects are in a set, one by one. We start from 1 and continue until every object has been counted. The last number we say is the total count. Learning to count accurately is essential before moving on to addition and subtraction. Practice with physical objects like toys, fingers, or drawings helps build this skill.",
      formula: "Total = last number reached when counting objects one by one",
      steps: [
        'Point to the first object and say "1".',
        'Point to the next object and say "2".',
        "Continue until every object has a number.",
        "The last number you said is the total count.",
      ],
      examples: [
        "🍎🍎🍎 → 1, 2, 3 → Total: 3 apples.",
        "5 fingers on one hand → 1,2,3,4,5.",
        "Count the books on a shelf one by one.",
      ],
      mistakes: [
        "Skipping objects when counting fast.",
        "Counting the same object twice.",
        "Forgetting which number comes next.",
      ],
      tips: [
        "Touch each object as you count it.",
        "Move counted objects to a separate pile.",
        "Count out loud to stay focused.",
      ],
      resources: [
        {
          name: "Counting Songs for Kids",
          url: "https://www.youtube.com/results?search_query=counting+songs+for+kids",
        },
        {
          name: "Counting Worksheets",
          url: "https://www.mathworksheets4kids.com/counting.php",
        },
      ],
    },
    add_basic: {
      concept:
        'Addition is the process of combining two or more numbers to find their total. The "+" symbol means "put together." For example, 2 + 3 means we have 2 objects and we get 3 more, ending with 5 objects total. Addition is one of the four basic arithmetic operations and is used everywhere — from counting money to measuring ingredients. The result of addition is called the "sum."',
      formula: "a + b = sum",
      steps: [
        "Identify the two numbers to add.",
        "Start from the first number.",
        "Count up by the second number.",
        "The result is the sum.",
      ],
      examples: [
        "2 + 3 = 5 (start at 2, count up 3: 3, 4, 5).",
        "10 + 5 = 15.",
        "7 + 8 = 15 (memorize this one!).",
      ],
      mistakes: [
        "Forgetting to carry in multi-digit addition.",
        "Miscounting when adding mentally.",
        "Adding wrong columns (e.g., tens with ones).",
      ],
      tips: [
        'Memorize "doubles" (2+2, 3+3, etc.) — they make other additions easier.',
        'Use "make 10" strategy: 8+7 = 8+2+5 = 10+5 = 15.',
        "Practice with flashcards daily.",
      ],
      resources: [
        {
          name: "Addition Strategies",
          url: "https://www.khanacademy.org/math/cc-1st-grade-math",
        },
      ],
    },
    sub_basic: {
      concept:
        'Subtraction is taking away one number from another. The "−" symbol means "take away." If you have 5 apples and eat 2, you have 5 − 2 = 3 apples left. Subtraction is the inverse (opposite) of addition. The result of subtraction is called the "difference." Subtraction is used when we want to know "how many are left" or "how many more do we need."',
      formula: "a − b = difference",
      steps: [
        "Identify the bigger number (minuend).",
        "Identify the smaller number (subtrahend).",
        "Count down from the bigger by the smaller.",
        "The result is the difference.",
      ],
      examples: [
        "5 − 2 = 3 (start at 5, count back 2: 4, 3).",
        "10 − 4 = 6.",
        "20 − 7 = 13.",
      ],
      mistakes: [
        "Subtracting smaller from bigger incorrectly.",
        "Forgetting to borrow in multi-digit subtraction.",
        "Confusing subtraction with addition signs.",
      ],
      tips: [
        'Use "counting up" strategy: 12−9 = how many from 9 to 12? (3).',
        "Check by adding: 5−2=3, so 3+2 should = 5.",
        "Visualize objects disappearing.",
      ],
      resources: [
        {
          name: "Subtraction Practice",
          url: "https://www.khanacademy.org/math/cc-1st-grade-math/cc-1st-add-subtract",
        },
      ],
    },
    mul_tables: {
      concept:
        'Multiplication is repeated addition. 3 × 4 means "3 added 4 times" or "4 added 3 times" — both give 12. The "×" symbol means "groups of." Learning multiplication tables (1 to 12) is essential because they form the foundation for division, fractions, and almost all higher math. Memorizing these tables saves time and reduces errors in calculations.',
      formula: "a × b = a added b times",
      steps: [
        "Recall the multiplication table for the number.",
        "Find the row for the first factor.",
        "Find the column for the second factor.",
        "Read the product at the intersection.",
      ],
      examples: [
        "3 × 4 = 12 (3 groups of 4).",
        "7 × 8 = 56 (trick: 5,6,7,8 → 56 = 7×8).",
        "9 × 6 = 54 (9 times tables: digits sum to 9: 5+4=9).",
      ],
      mistakes: [
        "Confusing multiplication with addition.",
        "Memorizing wrong products (e.g., 6×7=42, not 48).",
        "Not practicing enough to retain.",
      ],
      tips: [
        'Memorize the "9 trick": for 9×n, the answer starts with (n−1) and ends with (9−(n−1)).',
        "Use songs or rhymes to remember tables.",
        "Practice daily for 5 minutes.",
      ],
      resources: [
        {
          name: "Multiplication Tables",
          url: "https://www.mathsisfun.com/tables.html",
        },
      ],
    },
    div_basic: {
      concept:
        'Division is splitting a number into equal groups. 12 ÷ 3 means "how many groups of 3 can we make from 12?" The answer is 4. Division is the inverse of multiplication: if 3 × 4 = 12, then 12 ÷ 3 = 4 and 12 ÷ 4 = 3. The number being divided is the "dividend," the number we divide by is the "divisor," and the result is the "quotient."',
      formula: "a ÷ b = quotient (a = dividend, b = divisor)",
      steps: [
        "Identify the dividend (the total) and divisor (the group size).",
        'Ask: "How many times does the divisor fit into the dividend?"',
        "Check using multiplication: quotient × divisor should equal dividend.",
      ],
      examples: [
        "12 ÷ 3 = 4 (12 ÷ 3 groups = 4 each).",
        "20 ÷ 5 = 4.",
        "100 ÷ 10 = 10.",
      ],
      mistakes: [
        "Swapping dividend and divisor.",
        "Forgetting the relationship to multiplication.",
        "Leaving a remainder when one exists.",
      ],
      tips: [
        "Know your multiplication tables — division is just reverse multiplication.",
        "Use repeated subtraction: 12÷3 = how many times can we subtract 3? (4).",
        'Practice "fact families": 3×4=12, 4×3=12, 12÷3=4, 12÷4=3.',
      ],
      resources: [
        {
          name: "Division Basics",
          url: "https://www.khanacademy.org/math/cc-third-grade-math/cc-third-grade-mult-div",
        },
      ],
    },
    fractions_add: {
      concept:
        "A fraction represents a part of a whole. It has a numerator (top number) showing how many parts we have, and a denominator (bottom number) showing how many equal parts the whole is divided into. To add or subtract fractions with the same denominator, we simply add or subtract the numerators and keep the denominator the same. When denominators differ, we must first find a common denominator.",
      formula: "a/b ± c/b = (a±c)/b  (same denominator)",
      steps: [
        "Ensure denominators are the same.",
        "Add (or subtract) the numerators.",
        "Keep the denominator unchanged.",
        "Simplify the result if possible.",
      ],
      examples: [
        "1/4 + 2/4 = 3/4 (numerators: 1+2=3, denominator stays 4).",
        "5/8 − 2/8 = 3/8.",
        "3/10 + 4/10 = 7/10.",
      ],
      mistakes: [
        "Adding denominators (wrong: 1/4+2/4=3/8).",
        "Not simplifying the result.",
        "Forgetting common denominators when they differ.",
      ],
      tips: [
        "Visualize pizzas or pies to understand fractions.",
        "Always simplify your answer (e.g., 4/8 = 1/2).",
        "For different denominators, find LCM first.",
      ],
      resources: [
        {
          name: "Fraction Operations",
          url: "https://www.khanacademy.org/math/cc-fourth-grade-math/cc-4th-fractions",
        },
      ],
    },
    percentages: {
      concept:
        'A percentage is a number expressed as a fraction of 100. The "%" symbol means "per hundred." So 25% means 25 out of 100, or 25/100, or 0.25. Percentages are used everywhere — discounts, interest rates, test scores, statistics. To find a percentage of a number, convert the percent to a decimal (divide by 100) and multiply.',
      formula: "x% of n = (x/100) × n",
      steps: [
        "Convert the percentage to a decimal by dividing by 100.",
        "Multiply the decimal by the number.",
        "The result is the answer.",
      ],
      examples: [
        "25% of 80 = 0.25 × 80 = 20.",
        "50% of 60 = 30 (50% is just half).",
        "10% of 250 = 25 (move decimal one place left).",
      ],
      mistakes: [
        "Forgetting to divide by 100 before multiplying.",
        "Confusing percentage increase with simple percentage.",
        "Treating percentage points and percent change the same.",
      ],
      tips: [
        "10% of any number = move decimal one place left.",
        "50% = half, 25% = quarter, 75% = three quarters.",
        "For compound percentages, multiply decimals: 20% off then 10% off = 0.8 × 0.9 = 0.72 (28% off total).",
      ],
      resources: [
        {
          name: "Percentages",
          url: "https://www.khanacademy.org/math/cc-sixth-grade-math/cc-6th-ratios-prop-topic",
        },
      ],
    },
    order_of_ops: {
      concept:
        "Order of operations tells us the sequence in which to evaluate a math expression. We use the acronym PEMDAS: Parentheses, Exponents, Multiplication/Division (left to right), Addition/Subtraction (left to right). Without this rule, the same expression could give different answers. For example, 2 + 3 × 4 = 14 (not 20) because we multiply first.",
      formula: "PEMDAS: ( ) → ^ → ×÷ → +−",
      steps: [
        "First evaluate everything inside Parentheses.",
        "Then evaluate Exponents (powers).",
        "Then Multiplication and Division from left to right.",
        "Finally Addition and Subtraction from left to right.",
      ],
      examples: [
        "2 + 3 × 4 = 2 + 12 = 14 (multiply first).",
        "(2+3) × 4 = 5 × 4 = 20 (parentheses first).",
        "10 − 2³ + 4 = 10 − 8 + 4 = 6 (exponent before subtract).",
      ],
      mistakes: [
        "Doing operations left-to-right without considering precedence.",
        "Forgetting that × and ÷ have equal precedence.",
        "Not handling nested parentheses from inside out.",
      ],
      tips: [
        'Remember PEMDAS with "Please Excuse My Dear Aunt Sally."',
        "When × and ÷ are at the same level, go left to right.",
        "Use parentheses to clarify intent in your own work.",
      ],
      resources: [
        {
          name: "Order of Operations",
          url: "https://www.khanacademy.org/math/cc-sixth-grade-math/cc-6th-arithmetic-operations",
        },
      ],
    },
    algebra_linear: {
      concept:
        "A linear equation is an equation of the form ax + b = c, where x is unknown. To solve, we isolate x using inverse operations. The goal is to get x by itself on one side of the equation. We can add, subtract, multiply, or divide both sides by the same number without changing the solution. The solution is the value of x that makes the equation true.",
      formula: "ax + b = c → x = (c − b)/a",
      steps: [
        "Subtract b from both sides: ax = c − b.",
        "Divide both sides by a: x = (c − b)/a.",
        "Verify by substituting x back into the original equation.",
      ],
      examples: [
        "2x + 3 = 11. Subtract 3: 2x = 8. Divide by 2: x = 4.",
        "5x − 7 = 18. Add 7: 5x = 25. Divide by 5: x = 5.",
        "3x + 9 = 0. Subtract 9: 3x = −9. Divide by 3: x = −3.",
      ],
      mistakes: [
        "Forgetting to apply the operation to both sides.",
        "Dividing incorrectly when the coefficient is negative.",
        "Not checking the answer by substitution.",
      ],
      tips: [
        "Always do the same operation to both sides.",
        "Work backwards: undo addition with subtraction, undo multiplication with division.",
        "Check by plugging your answer back in.",
      ],
      resources: [
        {
          name: "Linear Equations",
          url: "https://www.khanacademy.org/math/algebra/x2f8bb11595b61c86:foundation-algebra",
        },
      ],
    },
    pythagoras: {
      concept:
        "The Pythagorean Theorem states that in a right triangle, the square of the hypotenuse (the side opposite the right angle) equals the sum of the squares of the other two sides (legs). This is written as a² + b² = c². It only works for right triangles and is one of the most famous theorems in mathematics, with applications in geometry, physics, and engineering.",
      formula: "a² + b² = c² (c = hypotenuse)",
      steps: [
        "Identify the two legs (a, b) and the hypotenuse (c).",
        "Square both legs: a² and b².",
        "Add them: a² + b².",
        "Take the square root: c = √(a² + b²).",
      ],
      examples: [
        "Legs 3, 4: 9 + 16 = 25, so c = 5 (the classic 3-4-5 triangle).",
        "Legs 5, 12: 25 + 144 = 169, so c = 13.",
        "Legs 8, 15: 64 + 225 = 289, so c = 17.",
      ],
      mistakes: [
        "Applying it to non-right triangles.",
        "Forgetting to take the square root at the end.",
        "Confusing which side is the hypotenuse.",
      ],
      tips: [
        "Memorize Pythagorean triples: 3-4-5, 5-12-13, 8-15-17, 7-24-25.",
        "The hypotenuse is always opposite the right angle.",
        "If c² < a² + b², the triangle is acute; if c² > a² + b², it's obtuse.",
      ],
      resources: [
        {
          name: "Pythagorean Theorem",
          url: "https://www.khanacademy.org/math/cc-eighth-grade-math/cc-8th-geometry",
        },
      ],
    },
    quad_equations: {
      concept:
        "A quadratic equation is a second-degree polynomial equation of the form ax² + bx + c = 0, where a ≠ 0. Quadratic equations can be solved by factoring, completing the square, or using the quadratic formula. The graph of a quadratic is a parabola. Quadratic equations appear in physics (projectile motion), engineering, economics, and many other fields.",
      formula: "x = (−b ± √(b² − 4ac)) / 2a",
      steps: [
        "Identify a, b, c from the equation.",
        "Calculate the discriminant: Δ = b² − 4ac.",
        "If Δ ≥ 0, apply the quadratic formula.",
        "Simplify to find both solutions.",
      ],
      examples: [
        "x² − 5x + 6 = 0: factor as (x−2)(x−3) = 0, so x = 2 or 3.",
        "x² + 6x + 9 = 0: (x+3)² = 0, so x = −3 (repeated).",
        "x² − 7x + 12 = 0: (x−3)(x−4) = 0, so x = 3 or 4.",
      ],
      mistakes: [
        "Forgetting the ± in the formula (gives two roots).",
        "Misidentifying the signs of b and c.",
        "Not checking if the equation can be factored first.",
      ],
      tips: [
        "Try factoring first — it's often faster.",
        "The discriminant tells you: positive = 2 real roots, zero = 1 repeated root, negative = no real roots.",
        "For x² − (sum)x + (product), look for two numbers with that sum and product.",
      ],
      resources: [
        {
          name: "Quadratic Equations",
          url: "https://www.khanacademy.org/math/algebra/x2f8bb11595b61c86:quadratic-equations-functions",
        },
      ],
    },
    trig_basic: {
      concept:
        "Trigonometry studies the relationships between angles and sides of triangles, especially right triangles. The three main functions are sine (sin), cosine (cos), and tangent (tan). In a right triangle: sin = opposite/hypotenuse, cos = adjacent/hypotenuse, tan = opposite/adjacent. The mnemonic SOH-CAH-TOA helps remember these. Trigonometry is essential in physics, engineering, navigation, and astronomy.",
      formula: "sin θ = opp/hyp, cos θ = adj/hyp, tan θ = opp/adj",
      steps: [
        "Identify the angle θ.",
        "Label the sides as opposite, adjacent, or hypotenuse relative to θ.",
        "Choose the correct trig function (SOH-CAH-TOA).",
        "Substitute and solve.",
      ],
      examples: [
        "sin(30°) = 1/2 = 0.5.",
        "cos(60°) = 1/2 = 0.5.",
        "tan(45°) = 1 (legs are equal).",
      ],
      mistakes: [
        "Confusing opposite and adjacent sides.",
        "Using degrees when the calculator is in radian mode (or vice versa).",
        "Forgetting that sin and cos are bounded between −1 and 1.",
      ],
      tips: [
        "Memorize the standard angles: 0°, 30°, 45°, 60°, 90°.",
        "Use SOH-CAH-TOA: Sin=Opp/Hyp, Cos=Adj/Hyp, Tan=Opp/Adj.",
        "Reciprocal functions: csc = 1/sin, sec = 1/cos, cot = 1/tan.",
      ],
      resources: [
        {
          name: "Trigonometry",
          url: "https://www.khanacademy.org/math/geometry/hs-geo-trig",
        },
      ],
    },
    derivatives_basic: {
      concept:
        "A derivative measures how a function changes as its input changes — it is the instantaneous rate of change, or the slope of the tangent line at a point. For f(x) = xⁿ, the derivative is f'(x) = n·xⁿ⁻¹ (the power rule). Derivatives are fundamental in calculus and have applications in physics (velocity, acceleration), economics (marginal cost), biology (population growth rates), and many other fields.",
      formula: "d/dx(xⁿ) = n·xⁿ⁻¹ (Power Rule)",
      steps: [
        "Identify the function f(x).",
        "Apply the appropriate differentiation rule.",
        "Simplify the result.",
        "Don't forget the constant disappears: d/dx(c) = 0.",
      ],
      examples: [
        "f(x) = x³ → f'(x) = 3x².",
        "f(x) = 5x² → f'(x) = 10x.",
        "f(x) = sin(x) → f'(x) = cos(x).",
      ],
      mistakes: [
        "Forgetting to subtract 1 from the exponent.",
        "Not handling the coefficient correctly.",
        "Forgetting chain rule for composite functions.",
      ],
      tips: [
        "Memorize basic derivatives: sin→cos, cos→−sin, eˣ→eˣ, ln(x)→1/x.",
        "For products, use the product rule: (uv)' = u'v + uv'.",
        "For quotients: (u/v)' = (u'v − uv')/v².",
        "For composites, use chain rule: f(g(x))' = f'(g(x))·g'(x).",
      ],
      resources: [
        {
          name: "Derivatives",
          url: "https://www.khanacademy.org/math/calculus-1/cs1-derivatives-definition-and-basic-rules",
        },
      ],
    },
    integrals_basic: {
      concept:
        "Integration is the reverse of differentiation. It finds the area under a curve, the total accumulation of a quantity, or the antiderivative of a function. The symbol ∫ represents integration. For f(x) = xⁿ, the integral is xⁿ⁺¹/(n+1) + C, where C is the constant of integration. Integrals are used to compute areas, volumes, displacement, and many other quantities.",
      formula: "∫ xⁿ dx = xⁿ⁺¹/(n+1) + C (n ≠ −1)",
      steps: [
        "Identify the integrand f(x).",
        "Apply the appropriate integration rule (reverse of differentiation).",
        "Add the constant of integration C.",
        "For definite integrals, evaluate at the bounds.",
      ],
      examples: [
        "∫ x² dx = x³/3 + C.",
        "∫ 2x dx = x² + C.",
        "∫ sin(x) dx = −cos(x) + C.",
        "∫ eˣ dx = eˣ + C.",
      ],
      mistakes: [
        "Forgetting the constant of integration C.",
        "Not adding 1 to the exponent when integrating.",
        "Forgetting to flip the sign (e.g., ∫ sin = −cos, not cos).",
      ],
      tips: [
        "Always add + C for indefinite integrals.",
        "For definite integrals ∫[a,b], evaluate antiderivative at b minus at a.",
        "Use substitution for composite functions.",
        "Use integration by parts for products: ∫u dv = uv − ∫v du.",
      ],
      resources: [
        {
          name: "Integrals",
          url: "https://www.khanacademy.org/math/calculus-1/cs1-integrals",
        },
      ],
    },
    matrices: {
      concept:
        'A matrix is a rectangular array of numbers arranged in rows and columns. A matrix with m rows and n columns is called an "m × n matrix." Matrices are used to solve systems of linear equations, represent transformations in computer graphics, model networks, and analyze data. The determinant of a square matrix is a single number that gives information about the matrix (e.g., whether it\'s invertible).',
      formula: "det([[a,b],[c,d]]) = ad − bc",
      steps: [
        "Identify the matrix structure.",
        "For 2×2 matrices, det = ad − bc.",
        "For larger matrices, use cofactor expansion.",
        "A matrix is invertible iff det ≠ 0.",
      ],
      examples: [
        "det([[3,1],[2,4]]) = 3·4 − 1·2 = 12 − 2 = 10.",
        "Identity matrix has det = 1.",
        "A matrix with a row of zeros has det = 0.",
      ],
      mistakes: [
        "Confusing matrix dimensions (rows × columns, not columns × rows).",
        "Computing det as ad + bc instead of ad − bc.",
        "Forgetting that matrix multiplication is not commutative (AB ≠ BA generally).",
      ],
      tips: [
        "Practice matrix multiplication by hand.",
        "Memorize: 2×2 det = ad − bc.",
        "For 3×3, use cofactor expansion along a row or column.",
        "Inverse of [[a,b],[c,d]] = (1/det)·[[d,−b],[−c,a]].",
      ],
      resources: [
        {
          name: "Matrices",
          url: "https://www.khanacademy.org/math/algebra-home/alg-matrices",
        },
      ],
    },
    logarithms: {
      concept:
        'A logarithm answers the question "to what power must we raise the base to get this number?" log_b(x) = y means b^y = x. For example, log_2(8) = 3 because 2³ = 8. Logarithms are the inverse of exponentials. Common logarithms use base 10 (written log), natural logarithms use base e ≈ 2.718 (written ln). Logarithms are used in chemistry (pH), seismology (Richter scale), sound (decibels), and finance.',
      formula: "log_b(x) = y means b^y = x",
      steps: [
        "Identify the base b and the argument x.",
        'Ask: "b to what power gives x?"',
        "That power is log_b(x).",
        "Use calculator for non-trivial cases.",
      ],
      examples: [
        "log_2(8) = 3 (because 2³ = 8).",
        "log_10(1000) = 3 (because 10³ = 1000).",
        "log_5(25) = 2 (because 5² = 25).",
        "ln(e) = 1 (because e¹ = e).",
      ],
      mistakes: [
        "Confusing log base 10 with natural log (ln).",
        "Forgetting logarithmic properties: log(ab) = log(a) + log(b).",
        "Trying to take log of zero or negative numbers (undefined).",
      ],
      tips: [
        "Memorize: log_b(b) = 1, log_b(1) = 0.",
        "Product rule: log(ab) = log(a) + log(b).",
        "Quotient rule: log(a/b) = log(a) − log(b).",
        "Power rule: log(aⁿ) = n·log(a).",
      ],
      resources: [
        {
          name: "Logarithms",
          url: "https://www.khanacademy.org/math/algebra2/x2ec2f6f830add910:logarithms",
        },
      ],
    },
    complex_numbers: {
      concept:
        'A complex number has the form a + bi, where a and b are real numbers and i is the imaginary unit defined by i² = −1. The "a" part is called the real part, and "b" is the imaginary part. Complex numbers extend the real number system to solve equations like x² + 1 = 0 (which has solutions x = ±i). They are essential in electrical engineering, quantum mechanics, signal processing, and fluid dynamics.',
      formula: "i² = −1; (a + bi) + (c + di) = (a+c) + (b+d)i",
      steps: [
        "Identify real and imaginary parts.",
        "For addition: add real parts, add imaginary parts.",
        "For multiplication: use FOIL and replace i² with −1.",
        "For division: multiply by conjugate.",
      ],
      examples: [
        "(3 + 2i) + (1 + 4i) = 4 + 6i.",
        "(2 + 3i)(1 + i) = 2 + 2i + 3i + 3i² = 2 + 5i − 3 = −1 + 5i.",
        "|3 + 4i| = √(9+16) = 5 (the magnitude).",
      ],
      mistakes: [
        "Forgetting that i² = −1, not 1.",
        "Not separating real and imaginary parts after multiplication.",
        "Confusing the conjugate (a − bi) with the negative.",
      ],
      tips: [
        "Magnitude: |a + bi| = √(a² + b²).",
        "Conjugate of (a + bi) is (a − bi).",
        "Division: multiply numerator and denominator by the conjugate of the denominator.",
        "Euler's formula: e^(iθ) = cos θ + i sin θ.",
      ],
      resources: [
        {
          name: "Complex Numbers",
          url: "https://www.khanacademy.org/math/algebra2/x2ec2f6f830add910:complex-numbers",
        },
      ],
    },
    limits: {
      concept:
        "A limit describes the value a function approaches as the input approaches some value. We write lim(x→a) f(x) = L, meaning f(x) gets arbitrarily close to L as x approaches a. Limits are the foundation of calculus — they define derivatives and integrals. Some limits can be found by direct substitution; others require factoring, rationalizing, or L'Hôpital's rule.",
      formula: "lim(x→a) f(x) = L means f(x) → L as x → a",
      steps: [
        "Try direct substitution first.",
        "If undefined (0/0 or ∞/∞), try factoring.",
        "Or rationalize by multiplying conjugate.",
        "For ∞/∞ forms, use L'Hôpital's rule (differentiate top and bottom).",
      ],
      examples: [
        "lim(x→2) (x²−4)/(x−2) = lim(x→2) (x+2) = 4 (after factoring).",
        "lim(x→0) sin(x)/x = 1 (famous limit).",
        "lim(x→∞) 1/x = 0.",
      ],
      mistakes: [
        "Giving up when direct substitution fails.",
        "Confusing left and right limits.",
        "Misapplying L'Hôpital's rule on non-indeterminate forms.",
      ],
      tips: [
        "Direct substitution: try it first.",
        "Factor and cancel for 0/0 forms.",
        "Use L'Hôpital's rule for 0/0 or ∞/∞.",
        "For limits at infinity, compare leading terms.",
      ],
      resources: [
        {
          name: "Limits",
          url: "https://www.khanacademy.org/math/calculus-1/cs1-limits-continuity",
        },
      ],
    },
  };

  // ============================================================
  // LEARNING PATHS - Sequence of topics for each level group
  // ============================================================
  const LEARNING_PATHS = {
    primary: {
      title: "Primary School Path (Class 1-5)",
      desc: "Foundational arithmetic and number sense.",
      icon: "🧒",
      path: [
        "counting",
        "number_recognition",
        "compare_numbers",
        "before_after",
        "skip_counting",
        "add_basic",
        "add_carry",
        "sub_basic",
        "sub_borrow",
        "mul_tables",
        "mul_basic",
        "div_basic",
        "word_problems_primary",
        "time",
        "money",
        "shapes",
        "patterns",
      ],
    },
    middle: {
      title: "Middle School Path (Class 6-8)",
      desc: "Fractions, decimals, percentages, pre-algebra, geometry.",
      icon: "👦",
      path: [
        "place_value",
        "rounding",
        "factors",
        "multiples",
        "gcd_lcm",
        "primes",
        "fractions_add",
        "fractions_mul",
        "fractions_simplify",
        "decimals_add",
        "decimals_mul",
        "percentages",
        "ratios",
        "integers_add",
        "integers_mul",
        "order_of_ops",
        "exponents",
        "square_roots",
        "algebra_linear",
        "algebra_simplify",
        "geometry_angles",
        "geometry_area",
        "pythagoras",
        "mean_median_mode",
        "probability_basic",
      ],
    },
    high: {
      title: "High School Path (Class 9-12)",
      desc: "Algebra, geometry, trigonometry, calculus, statistics.",
      icon: "🧑",
      path: [
        "quad_equations",
        "factoring",
        "simultaneous_eq",
        "inequalities",
        "functions_eval",
        "polynomials",
        "logarithms",
        "sequences",
        "geometric_seq",
        "binomial",
        "trig_basic",
        "trig_identities",
        "circles",
        "triangles",
        "vectors_2d",
        "matrices_basic",
        "complex_numbers",
        "limits",
        "derivatives_basic",
        "integrals_basic",
        "stats_std",
        "perms_combs",
        "set_theory",
        "compound_interest",
      ],
    },
    college: {
      title: "College Path",
      desc: "Advanced calculus, linear algebra, differential equations, abstract math.",
      icon: "🎓",
      path: [
        "derivatives_adv",
        "integrals_adv",
        "series_convergence",
        "differential_eq",
        "partial_deriv",
        "multivariable",
        "linear_algebra",
        "eigenvalues",
        "matrix_ops",
        "vector_calc",
        "discrete_math",
        "graph_theory",
        "boolean_algebra",
        "probability_adv",
        "bayes",
        "hypothesis",
        "regression",
        "fourier",
        "laplace",
        "taylor_series",
        "complex_analysis",
        "optimization",
      ],
    },
  };

  // ============================================================
  // FORMULA REFERENCE - Quick lookup for major formulas
  // ============================================================
  const FORMULAS = [
    {
      cat: "Arithmetic",
      name: "Addition",
      formula: "a + b = sum",
      topic: "add_basic",
    },
    {
      cat: "Arithmetic",
      name: "Multiplication",
      formula: "a × b = product",
      topic: "mul_basic",
    },
    {
      cat: "Arithmetic",
      name: "Division",
      formula: "a ÷ b = quotient",
      topic: "div_basic",
    },
    {
      cat: "Arithmetic",
      name: "Order of Operations",
      formula: "PEMDAS: () ^ ×÷ +−",
      topic: "order_of_ops",
    },
    {
      cat: "Fractions",
      name: "Addition (same denom)",
      formula: "a/b + c/b = (a+c)/b",
      topic: "fractions_add",
    },
    {
      cat: "Fractions",
      name: "Multiplication",
      formula: "(a/b)(c/d) = ac/bd",
      topic: "fractions_mul",
    },
    {
      cat: "Fractions",
      name: "Simplify",
      formula: "Divide by GCD",
      topic: "fractions_simplify",
    },
    {
      cat: "Percentages",
      name: "Percent of",
      formula: "x% of n = (x/100)·n",
      topic: "percentages",
    },
    {
      cat: "Percentages",
      name: "Percent change",
      formula: "|new−old|/old × 100",
      topic: "percent_change",
    },
    {
      cat: "Geometry",
      name: "Square area",
      formula: "A = s²",
      topic: "geometry_area",
    },
    {
      cat: "Geometry",
      name: "Rectangle area",
      formula: "A = l × w",
      topic: "geometry_area",
    },
    {
      cat: "Geometry",
      name: "Triangle area",
      formula: "A = ½ × b × h",
      topic: "geometry_area",
    },
    {
      cat: "Geometry",
      name: "Circle area",
      formula: "A = π × r²",
      topic: "circles",
    },
    {
      cat: "Geometry",
      name: "Circle circumference",
      formula: "C = 2π × r",
      topic: "circles",
    },
    {
      cat: "Geometry",
      name: "Cube volume",
      formula: "V = s³",
      topic: "geometry_volume",
    },
    {
      cat: "Geometry",
      name: "Cylinder volume",
      formula: "V = π × r² × h",
      topic: "geometry_volume",
    },
    {
      cat: "Geometry",
      name: "Sphere volume",
      formula: "V = (4/3) × π × r³",
      topic: "geometry_volume",
    },
    {
      cat: "Geometry",
      name: "Pythagorean Theorem",
      formula: "a² + b² = c²",
      topic: "pythagoras",
    },
    {
      cat: "Algebra",
      name: "Linear equation",
      formula: "ax + b = c → x = (c−b)/a",
      topic: "algebra_linear",
    },
    {
      cat: "Algebra",
      name: "Quadratic formula",
      formula: "x = (−b ± √(b²−4ac)) / 2a",
      topic: "quad_formula",
    },
    {
      cat: "Algebra",
      name: "Discriminant",
      formula: "Δ = b² − 4ac",
      topic: "quad_formula",
    },
    {
      cat: "Algebra",
      name: "Slope",
      formula: "m = (y₂−y₁) / (x₂−x₁)",
      topic: "functions_eval",
    },
    {
      cat: "Algebra",
      name: "Distance formula",
      formula: "d = √((x₂−x₁)² + (y₂−y₁)²)",
      topic: "pythagoras",
    },
    {
      cat: "Algebra",
      name: "Slope-intercept form",
      formula: "y = mx + b",
      topic: "functions_eval",
    },
    {
      cat: "Trigonometry",
      name: "Sine",
      formula: "sin θ = opp/hyp",
      topic: "trig_basic",
    },
    {
      cat: "Trigonometry",
      name: "Cosine",
      formula: "cos θ = adj/hyp",
      topic: "trig_basic",
    },
    {
      cat: "Trigonometry",
      name: "Tangent",
      formula: "tan θ = opp/adj",
      topic: "trig_basic",
    },
    {
      cat: "Trigonometry",
      name: "Pythagorean identity",
      formula: "sin²θ + cos²θ = 1",
      topic: "trig_identities",
    },
    {
      cat: "Trigonometry",
      name: "Double angle (sin)",
      formula: "sin(2θ) = 2 sin θ cos θ",
      topic: "trig_identities",
    },
    {
      cat: "Statistics",
      name: "Mean",
      formula: "x̄ = Σx / n",
      topic: "mean_median_mode",
    },
    {
      cat: "Statistics",
      name: "Variance",
      formula: "σ² = Σ(x−μ)² / n",
      topic: "stats_std",
    },
    {
      cat: "Statistics",
      name: "Standard deviation",
      formula: "σ = √(Σ(x−μ)²/n)",
      topic: "stats_std",
    },
    {
      cat: "Statistics",
      name: "Combinations",
      formula: "C(n,r) = n! / (r!(n−r)!)",
      topic: "perms_combs",
    },
    {
      cat: "Statistics",
      name: "Permutations",
      formula: "P(n,r) = n! / (n−r)!",
      topic: "perms_combs",
    },
    {
      cat: "Probability",
      name: "Basic",
      formula: "P(E) = favorable / total",
      topic: "probability_basic",
    },
    {
      cat: "Probability",
      name: "Bayes",
      formula: "P(A|B) = P(B|A)·P(A) / P(B)",
      topic: "bayes",
    },
    {
      cat: "Calculus",
      name: "Power rule (derivative)",
      formula: "d/dx(xⁿ) = n·xⁿ⁻¹",
      topic: "derivatives_basic",
    },
    {
      cat: "Calculus",
      name: "Power rule (integral)",
      formula: "∫xⁿ dx = xⁿ⁺¹/(n+1) + C",
      topic: "integrals_basic",
    },
    {
      cat: "Calculus",
      name: "Product rule",
      formula: "(uv)' = u'v + uv'",
      topic: "derivatives_adv",
    },
    {
      cat: "Calculus",
      name: "Quotient rule",
      formula: "(u/v)' = (u'v − uv')/v²",
      topic: "derivatives_adv",
    },
    {
      cat: "Calculus",
      name: "Chain rule",
      formula: "d/dx f(g(x)) = f'(g(x))·g'(x)",
      topic: "derivatives_adv",
    },
    {
      cat: "Calculus",
      name: "Integration by parts",
      formula: "∫u dv = uv − ∫v du",
      topic: "integrals_adv",
    },
    {
      cat: "Calculus",
      name: "Fundamental theorem",
      formula: "∫[a,b] f(x) dx = F(b) − F(a)",
      topic: "integrals_basic",
    },
    {
      cat: "Linear Algebra",
      name: "Matrix determinant (2×2)",
      formula: "det = ad − bc",
      topic: "matrices",
    },
    {
      cat: "Linear Algebra",
      name: "Matrix inverse (2×2)",
      formula: "A⁻¹ = (1/det)·[[d,−b],[−c,a]]",
      topic: "matrices",
    },
    {
      cat: "Linear Algebra",
      name: "Eigenvalues",
      formula: "det(A − λI) = 0",
      topic: "eigenvalues",
    },
    {
      cat: "Number Theory",
      name: "GCD",
      formula: "largest common divisor",
      topic: "gcd_lcm",
    },
    {
      cat: "Number Theory",
      name: "LCM",
      formula: "|a×b| / GCD(a,b)",
      topic: "gcd_lcm",
    },
    {
      cat: "Number Theory",
      name: "Modular arithmetic",
      formula: "a ≡ b (mod n) iff n | (a−b)",
      topic: "number_theory",
    },
    {
      cat: "Sequences",
      name: "Arithmetic nth term",
      formula: "aₙ = a₁ + (n−1)d",
      topic: "sequences",
    },
    {
      cat: "Sequences",
      name: "Arithmetic sum",
      formula: "Sₙ = n/2 × (a₁ + aₙ)",
      topic: "sequences",
    },
    {
      cat: "Sequences",
      name: "Geometric nth term",
      formula: "aₙ = a₁ × r^(n−1)",
      topic: "geometric_seq",
    },
    {
      cat: "Sequences",
      name: "Geometric sum",
      formula: "Sₙ = a₁(1−rⁿ)/(1−r)",
      topic: "geometric_seq",
    },
    {
      cat: "Finance",
      name: "Simple interest",
      formula: "I = P × r × t",
      topic: "compound_interest",
    },
    {
      cat: "Finance",
      name: "Compound interest",
      formula: "A = P(1 + r/n)^(nt)",
      topic: "compound_interest",
    },
    {
      cat: "Finance",
      name: "Continuous compounding",
      formula: "A = P × e^(rt)",
      topic: "compound_interest",
    },
    {
      cat: "Series",
      name: "Taylor series",
      formula: "f(x) = Σ f⁽ⁿ⁾(0)·xⁿ/n!",
      topic: "taylor_series",
    },
    {
      cat: "Series",
      name: "Maclaurin (eˣ)",
      formula: "eˣ = Σ xⁿ/n!",
      topic: "taylor_series",
    },
    {
      cat: "Series",
      name: "Maclaurin (sin x)",
      formula: "sin(x) = Σ (−1)ⁿ x^(2n+1)/(2n+1)!",
      topic: "taylor_series",
    },
    {
      cat: "Complex",
      name: "Euler's formula",
      formula: "e^(iθ) = cos θ + i sin θ",
      topic: "complex_analysis",
    },
    {
      cat: "Complex",
      name: "Magnitude",
      formula: "|a+bi| = √(a² + b²)",
      topic: "complex_numbers",
    },
    {
      cat: "Differential Equations",
      name: "Separable",
      formula: "dy/dx = f(x)g(y) → ∫dy/g(y) = ∫f(x)dx",
      topic: "differential_eq",
    },
    {
      cat: "Differential Equations",
      name: "First-order linear",
      formula: "y' + P(x)y = Q(x)",
      topic: "differential_eq",
    },
    {
      cat: "Vector Calculus",
      name: "Gradient",
      formula: "∇f = (∂f/∂x, ∂f/∂y, ∂f/∂z)",
      topic: "multivariable",
    },
    {
      cat: "Vector Calculus",
      name: "Divergence",
      formula: "∇·F = ∂F₁/∂x + ∂F₂/∂y + ∂F₃/∂z",
      topic: "vector_calc",
    },
    {
      cat: "Vector Calculus",
      name: "Curl",
      formula: "∇×F = determinant form",
      topic: "vector_calc",
    },
    {
      cat: "Transforms",
      name: "Laplace (1)",
      formula: "L{1} = 1/s",
      topic: "laplace",
    },
    {
      cat: "Transforms",
      name: "Laplace (e^(at))",
      formula: "L{e^(at)} = 1/(s−a)",
      topic: "laplace",
    },
    {
      cat: "Transforms",
      name: "Fourier series",
      formula: "f(t) = a₀/2 + Σ[aₙcos(nωt) + bₙsin(nωt)]",
      topic: "fourier",
    },
  ];

  // ============================================================
  // GLOSSARY
  // ============================================================
  const GLOSSARY = [
    {
      term: "Integer",
      def: "A whole number (positive, negative, or zero), no fractions or decimals.",
    },
    {
      term: "Prime number",
      def: "A number greater than 1 with exactly two factors: 1 and itself.",
    },
    {
      term: "Composite number",
      def: "A number greater than 1 with more than two factors.",
    },
    {
      term: "Numerator",
      def: "The top number of a fraction, showing how many parts we have.",
    },
    {
      term: "Denominator",
      def: "The bottom number of a fraction, showing how many equal parts the whole is divided into.",
    },
    {
      term: "Reciprocal",
      def: "1 divided by a number. The reciprocal of x is 1/x.",
    },
    {
      term: "Variable",
      def: "A letter or symbol representing an unknown number, like x or y.",
    },
    {
      term: "Coefficient",
      def: "The number multiplied by a variable, like 5 in 5x.",
    },
    {
      term: "Constant",
      def: "A number that doesn't change, like 7 in the expression x + 7.",
    },
    {
      term: "Expression",
      def: "A combination of numbers, variables, and operations, like 3x + 5.",
    },
    {
      term: "Equation",
      def: "A statement that two expressions are equal, like 2x + 3 = 7.",
    },
    {
      term: "Function",
      def: "A relationship where each input has exactly one output, written f(x).",
    },
    {
      term: "Domain",
      def: "The set of all possible input values of a function.",
    },
    {
      term: "Range",
      def: "The set of all possible output values of a function.",
    },
    {
      term: "Slope",
      def: "The steepness of a line, calculated as rise over run.",
    },
    {
      term: "Hypotenuse",
      def: "The longest side of a right triangle, opposite the right angle.",
    },
    {
      term: "Adjacent",
      def: "The side next to a given angle (not the hypotenuse).",
    },
    { term: "Opposite", def: "The side across from a given angle." },
    {
      term: "Derivative",
      def: "The instantaneous rate of change of a function, or the slope of the tangent line.",
    },
    {
      term: "Integral",
      def: "The accumulation of a quantity, or the area under a curve.",
    },
    {
      term: "Limit",
      def: "The value a function approaches as the input approaches some value.",
    },
    {
      term: "Matrix",
      def: "A rectangular array of numbers arranged in rows and columns.",
    },
    {
      term: "Determinant",
      def: "A single number computed from a square matrix, used in linear algebra.",
    },
    {
      term: "Eigenvalue",
      def: "A scalar λ such that Av = λv for some nonzero vector v.",
    },
    {
      term: "Vector",
      def: "A quantity with both magnitude and direction, often drawn as an arrow.",
    },
    {
      term: "Scalar",
      def: "A quantity with magnitude only (just a number, no direction).",
    },
    {
      term: "Complex number",
      def: "A number of the form a + bi, where i² = −1.",
    },
    { term: "Imaginary unit", def: "The number i, defined by i² = −1." },
    {
      term: "Logarithm",
      def: "The inverse of exponentiation: log_b(x) = y means b^y = x.",
    },
    {
      term: "Asymptote",
      def: "A line that a curve approaches but never touches.",
    },
    {
      term: "Parabola",
      def: "A U-shaped curve, the graph of y = ax² + bx + c.",
    },
    {
      term: "Polynomial",
      def: "A sum of terms with variables raised to whole-number powers.",
    },
    {
      term: "Quadratic",
      def: "A polynomial of degree 2, of the form ax² + bx + c.",
    },
    { term: "Permutation", def: "An ordered arrangement of objects." },
    { term: "Combination", def: "An unordered selection of objects." },
    {
      term: "Probability",
      def: "A measure of how likely an event is, from 0 (impossible) to 1 (certain).",
    },
    {
      term: "Standard deviation",
      def: "A measure of how spread out numbers are from the mean.",
    },
    {
      term: "Correlation",
      def: "A statistical relationship between two variables.",
    },
    {
      term: "Theorem",
      def: "A statement proven true using logical reasoning from axioms.",
    },
    {
      term: "Axiom",
      def: "A statement accepted as true without proof, a starting point.",
    },
    {
      term: "Proof",
      def: "A logical argument that establishes a statement is true.",
    },
    { term: "Set", def: "A collection of distinct objects, called elements." },
    {
      term: "Union",
      def: "The set of all elements in either of two sets, written A ∪ B.",
    },
    {
      term: "Intersection",
      def: "The set of elements common to two sets, written A ∩ B.",
    },
    {
      term: "Subset",
      def: "A set whose elements are all contained in another set.",
    },
    {
      term: "Infinity",
      def: "A concept of endlessness, written ∞. Not a real number.",
    },
  ];

  // ============================================================
  // TIPS AND TRICKS
  // ============================================================
  const TIPS = [
    {
      title: "The 9 Times Table Trick",
      body: "For 9 × n, the answer's digits sum to 9. 9×6=54, 5+4=9. To find 9×n, hold up n fingers, count fingers before (tens) and after (ones).",
    },
    {
      title: "Multiplying by 11",
      body: "For 11 × (two-digit number), just add the digits and put the sum in the middle. 11 × 23 = 2 (2+3) 3 = 253.",
    },
    {
      title: "Squaring numbers ending in 5",
      body: "For n5², take n×(n+1) and append 25. 25²: 2×3=6, so 625. 75²: 7×8=56, so 5625.",
    },
    {
      title: "Divisibility by 3",
      body: "A number is divisible by 3 if the sum of its digits is. 123: 1+2+3=6, divisible by 3, so 123 is.",
    },
    {
      title: "Divisibility by 9",
      body: "A number is divisible by 9 if the sum of its digits is. 81: 8+1=9, so yes.",
    },
    {
      title: "Divisibility by 11",
      body: "Alternating sum of digits: subtract, add, subtract. 121: 1−2+1=0, divisible by 11.",
    },
    {
      title: "Percentage of 100 trick",
      body: "For x% of any number, just multiply. 25% = 1/4, so divide by 4. 50% = 1/2, divide by 2. 10% = divide by 10.",
    },
    {
      title: "Squaring numbers near 100",
      body: "For (100−n)² = 10000 − 200n + n². E.g., 98² = 10000 − 400 + 4 = 9604.",
    },
    {
      title: "Converting fractions to decimals",
      body: "Memorize common ones: 1/4=0.25, 1/3≈0.33, 1/2=0.5, 1/8=0.125, 1/5=0.2.",
    },
    {
      title: "Memorize π",
      body: '3.14159 — "How I wish I could calculate pi" (counts letters: 3 1 4 1 5 9).',
    },
    {
      title: "Memorize e",
      body: 'e ≈ 2.71828 — "It enables natural logs to resonate."',
    },
    {
      title: "Pythagorean triples",
      body: "Memorize: 3-4-5, 5-12-13, 8-15-17, 7-24-25. Multiples work too (6-8-10, etc.).",
    },
    {
      title: "Sum of 1 to n",
      body: "n(n+1)/2. Sum 1 to 100 = 100×101/2 = 5050 (Gauss's trick).",
    },
    {
      title: "FOIL for binomials",
      body: "(a+b)(c+d) = ac + ad + bc + bd. (x+3)(x+4) = x² + 7x + 12.",
    },
    {
      title: "Difference of squares",
      body: "a² − b² = (a+b)(a−b). x² − 9 = (x+3)(x−3). Quick factoring!",
    },
    {
      title: "Memorize trig values",
      body: "For 30°-60°-90°: sides 1, √3, 2. For 45°-45°-90°: sides 1, 1, √2.",
    },
    {
      title: "Calculating tips quickly",
      body: "10% = move decimal left one place. 20% = double that. For 15% = 10% + half of 10%.",
    },
    {
      title: "Estimating square roots",
      body: "√50 is between √49 (7) and √64 (8), closer to 7. Actual: ≈7.07.",
    },
    {
      title: "Multiplying by 5",
      body: "Multiply by 10, then divide by 2. 5 × 36 = 360/2 = 180.",
    },
    {
      title: 'The "make 10" addition trick',
      body: "8 + 7 = 8 + 2 + 5 = 10 + 5 = 15. Round up to 10 first.",
    },
    {
      title: "Reciprocal of a fraction",
      body: "Flip it! 3/4 → 4/3. Used in division: dividing by 2/3 = multiplying by 3/2.",
    },
    {
      title: "Rounding for estimation",
      body: "47 + 28 ≈ 50 + 30 = 80 (actual: 75). Quick check.",
    },
    {
      title: "Area of a triangle from sides",
      body: "Heron's formula: A = √(s(s−a)(s−b)(s−c)) where s = (a+b+c)/2.",
    },
    {
      title: "Natural log approx",
      body: "ln(1+x) ≈ x for small x. ln(1.1) ≈ 0.1 (actual: 0.0953).",
    },
    {
      title: "Binomial coefficients",
      body: "Use Pascal's triangle! Row n gives coefficients of (a+b)ⁿ.",
    },
  ];

  // ============================================================
  // COMMON MISTAKES BY CATEGORY
  // ============================================================
  const COMMON_MISTAKES = [
    {
      cat: "Arithmetic",
      mistake: "Treating 0 as nothing in operations",
      fix: "0 is a number! 5+0=5, 5−0=5, 5×0=0, but 5÷0 is undefined.",
    },
    {
      cat: "Arithmetic",
      mistake: "Adding denominators in fractions",
      fix: "1/4 + 2/4 = 3/4, NOT 3/8. Keep the denominator.",
    },
    {
      cat: "Arithmetic",
      mistake: "Confusing multiplication with addition for negative numbers",
      fix: "−3 × −4 = +12 (negative × negative = positive).",
    },
    {
      cat: "Algebra",
      mistake: "Forgetting to do the same operation to both sides",
      fix: "If you subtract 5 from one side, subtract 5 from the other too.",
    },
    {
      cat: "Algebra",
      mistake: "Dividing by a variable that could be 0",
      fix: "When dividing by x, check if x=0 is a solution separately.",
    },
    {
      cat: "Algebra",
      mistake:
        "Forgetting to flip the inequality sign when dividing by a negative",
      fix: "−2x > 6 becomes x < −3 (inequality flips).",
    },
    {
      cat: "Fractions",
      mistake: "Cross-multiplying for addition",
      fix: "Cross-multiplication is for comparing, not adding. Find common denominator first.",
    },
    {
      cat: "Geometry",
      mistake: "Using Pythagorean theorem on non-right triangles",
      fix: "Pythagoras only works for right triangles. Use Law of Cosines otherwise.",
    },
    {
      cat: "Geometry",
      mistake: "Confusing area and perimeter",
      fix: "Area is in square units (cm²), perimeter is in linear units (cm).",
    },
    {
      cat: "Trigonometry",
      mistake: "Using degrees when calculator is in radians",
      fix: "Check calculator mode! Most problems specify degrees or radians.",
    },
    {
      cat: "Trigonometry",
      mistake: "Forgetting SOH-CAH-TOA",
      fix: "sin=opp/hyp, cos=adj/hyp, tan=opp/adj.",
    },
    {
      cat: "Calculus",
      mistake: "Forgetting the chain rule",
      fix: "d/dx[f(g(x))] = f'(g(x)) · g'(x). Always check for composites!",
    },
    {
      cat: "Calculus",
      mistake: "Forgetting the constant of integration",
      fix: "Always add + C for indefinite integrals.",
    },
    {
      cat: "Calculus",
      mistake: "Misapplying L'Hôpital's rule",
      fix: "Only for 0/0 or ∞/∞ forms. Check first!",
    },
    {
      cat: "Statistics",
      mistake: "Confusing mean, median, and mode",
      fix: "Mean=average, median=middle, mode=most frequent.",
    },
    {
      cat: "Statistics",
      mistake: "Forgetting to square root for standard deviation",
      fix: "Variance is squared, SD is the square root of variance.",
    },
    {
      cat: "Probability",
      mistake: "Adding probabilities of independent events",
      fix: 'For "AND" (independent), multiply. For "OR" (mutually exclusive), add.',
    },
    {
      cat: "General",
      mistake: "Not checking your answer",
      fix: "Substitute back into the original equation to verify.",
    },
    {
      cat: "General",
      mistake: "Rounding too early",
      fix: "Keep full precision until the final answer, then round.",
    },
    {
      cat: "General",
      mistake: "Forgetting units",
      fix: "Always include units in word problems: cm, kg, m/s, etc.",
    },
  ];

  // ============================================================
  // MATH HISTORY (fun facts to inspire)
  // ============================================================
  const HISTORY = [
    {
      era: "~30000 BCE",
      event: "Earliest tally bones (Ishango bone) suggest counting.",
    },
    {
      era: "~2000 BCE",
      event:
        "Babylonians use base-60 number system (why we have 60 seconds in a minute).",
    },
    {
      era: "~1650 BCE",
      event: "Rhind Papyrus: Egyptian math including π ≈ 3.16.",
    },
    {
      era: "~600 BCE",
      event: "Pythagoras and his school study geometry and number theory.",
    },
    {
      era: "~300 BCE",
      event: 'Euclid writes "Elements," the most influential math book ever.',
    },
    { era: "~250 BCE", event: "Archimedes calculates π and studies buoyancy." },
    { era: "~200 CE", event: "Diophantus writes about algebraic equations." },
    {
      era: "~830 CE",
      event: 'Al-Khwarizmi writes on algebra (his name → "algorithm").',
    },
    {
      era: "~1202 CE",
      event: "Fibonacci introduces Hindu-Arabic numerals to Europe.",
    },
    {
      era: "1545",
      event: "Cardano publishes solutions to cubic and quartic equations.",
    },
    { era: "1614", event: "Napier invents logarithms." },
    { era: "1679", event: "Leibniz develops binary number system." },
    {
      era: "1687",
      event: "Newton publishes Principia Mathematica (calculus + physics).",
    },
    { era: "1799", event: "Gauss proves the Fundamental Theorem of Algebra." },
    { era: "1854", event: "Riemann introduces non-Euclidean geometry." },
    {
      era: "1931",
      event: "Gödel's incompleteness theorems shock mathematics.",
    },
    { era: "1976", event: "Four color theorem first proved using a computer." },
    {
      era: "1995",
      event: "Andrew Wiles proves Fermat's Last Theorem after 358 years.",
    },
    { era: "2003", event: "Grigori Perelman proves the Poincaré conjecture." },
  ];

  // ============================================================
  // Public API
  // ============================================================
  function getMaterial(topicId) {
    return MATERIALS[topicId] || generateGenericMaterial(topicId);
  }

  function generateGenericMaterial(topicId) {
    const topic = Problems.getTopic(topicId);
    if (!topic) return null;
    return {
      concept: `This topic covers ${topic.name}. Study the concept thoroughly before attempting practice problems. Understanding the underlying principle is key to mastery.`,
      formula: "See practice problems for the specific formula.",
      steps: [
        "Read the problem carefully.",
        "Identify what is being asked.",
        "Apply the relevant formula or method.",
        "Check your answer.",
      ],
      examples: [
        "Work through example problems step by step.",
        "Try variations to build flexibility.",
      ],
      mistakes: [
        "Rushing through without understanding.",
        "Not checking your work.",
      ],
      tips: [
        "Practice regularly for retention.",
        "Explain the concept to someone else to test understanding.",
      ],
      resources: [
        {
          name: "Search Khan Academy",
          url:
            "https://www.khanacademy.org/search?page_search_query=" +
            encodeURIComponent(topic.name),
        },
      ],
    };
  }

  function getLearningPaths() {
    return LEARNING_PATHS;
  }
  function getLearningPath(group) {
    return LEARNING_PATHS[group];
  }
  function getFormulas(cat) {
    return cat ? FORMULAS.filter((f) => f.cat === cat) : FORMULAS;
  }
  function getFormulaCategories() {
    return [...new Set(FORMULAS.map((f) => f.cat))];
  }
  function getGlossary() {
    return GLOSSARY;
  }
  function getTips() {
    return TIPS;
  }
  function getCommonMistakes() {
    return COMMON_MISTAKES;
  }
  function getHistory() {
    return HISTORY;
  }

  return {
    MATERIALS,
    LEARNING_PATHS,
    FORMULAS,
    GLOSSARY,
    TIPS,
    COMMON_MISTAKES,
    HISTORY,
    getMaterial,
    getLearningPaths,
    getLearningPath,
    getFormulas,
    getFormulaCategories,
    getGlossary,
    getTips,
    getCommonMistakes,
    getHistory,
  };
})();
