/* ============================================================
   MathMaster Pro - data.js by Koushik Koley
   State management, localStorage persistence, achievements,
   level system, and feature catalog (200+ features)
   ============================================================ */

const MMP = (function () {
  "use strict";

  // ---------- Storage Keys ----------
  const KEYS = {
    PROFILE: "mmp_profile",
    STATS: "mmp_stats",
    SETTINGS: "mmp_settings",
    HISTORY: "mmp_history",
    ACHIEVEMENTS: "mmp_achievements",
    FLASHCARDS: "mmp_flashcards",
    BOOKMARKS: "mmp_bookmarks",
    STUDY_PROGRESS: "mmp_study_progress",
    TOPIC_PROGRESS: "mmp_topic_progress",
    CUSTOM_SETS: "mmp_custom_sets",
    NOTEPAD: "mmp_notepad",
  };

  // ---------- Default Settings ----------
  const DEFAULT_SETTINGS = {
    theme: "light", // light | dark
    color: "indigo", // indigo | emerald | rose | blue | purple | teal | orange
    fontSize: "medium", // small | medium | large
    contrast: "normal", // normal | high
    sound: true,
    music: false,
    animations: true,
    haptics: true,
    autoNext: true,
    showHints: true,
    showTimer: true,
    showSteps: true,
    inputMode: "auto", // auto | keyboard | numpad | voice
    questionFormat: "mcq", // mcq | input | truefalse | matching
    language: "en",
    numberFormat: "western",
    keyboardShortcuts: true,
    autoSave: true,
    adaptive: true,
    passScore: 70,
  };

  // ---------- Default Profile ----------
  const DEFAULT_PROFILE = {
    name: "Learner",
    avatar: "🦊",
    title: "Beginner",
    level: 1,
    xp: 0,
    streak: 0,
    lastActive: null,
    createdAt: Date.now(),
    dailyGoal: 20,
    todayCount: 0,
    todayDate: "",
  };

  // ---------- Default Stats ----------
  const DEFAULT_STATS = {
    totalAttempted: 0,
    totalCorrect: 0,
    totalXp: 0,
    bestStreak: 0,
    totalTimeSpent: 0, // seconds
    topicsAttempted: {},
    topicsCorrect: {},
    difficultyStats: {
      easy: { a: 0, c: 0 },
      medium: { a: 0, c: 0 },
      hard: { a: 0, c: 0 },
      expert: { a: 0, c: 0 },
    },
    byDay: {}, // { 'YYYY-MM-DD': { a, c, xp } }
    byMode: {
      practice: { a: 0, c: 0 },
      quiz: { a: 0, c: 0 },
      flashcard: 0,
      game: { a: 0, c: 0 },
    },
    fastestSolve: Infinity,
    slowestSolve: 0,
    sessionCount: 0,
    worksheetGenerated: 0,
    customSetsCreated: 0,
  };

  // ---------- State ----------
  let profile = load(KEYS.PROFILE, DEFAULT_PROFILE);
  let stats = load(KEYS.STATS, DEFAULT_STATS);
  let settings = load(KEYS.SETTINGS, DEFAULT_SETTINGS);
  let history = load(KEYS.HISTORY, []);
  let achievements = load(KEYS.ACHIEVEMENTS, []);
  let flashcards = load(KEYS.FLASHCARDS, []);
  let bookmarks = load(KEYS.BOOKMARKS, []);
  let studyProgress = load(KEYS.STUDY_PROGRESS, {});
  let topicProgress = load(KEYS.TOPIC_PROGRESS, {});
  let customSets = load(KEYS.CUSTOM_SETS, []);
  let notepad = load(KEYS.NOTEPAD, "");

  // ---------- Storage Helpers ----------
  function load(key, def) {
    try {
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : structuredClone(def);
    } catch (e) {
      console.warn("Load failed for", key, e);
      return structuredClone(def);
    }
  }
  function save(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.warn("Save failed for", key, e);
      return false;
    }
  }

  // ---------- Persistence API ----------
  const persist = {
    profile: () => save(KEYS.PROFILE, profile),
    stats: () => save(KEYS.STATS, stats),
    settings: () => save(KEYS.SETTINGS, settings),
    history: () => save(KEYS.HISTORY, history.slice(-500)), // keep last 500
    achievements: () => save(KEYS.ACHIEVEMENTS, achievements),
    flashcards: () => save(KEYS.FLASHCARDS, flashcards),
    bookmarks: () => save(KEYS.BOOKMARKS, bookmarks),
    studyProgress: () => save(KEYS.STUDY_PROGRESS, studyProgress),
    topicProgress: () => save(KEYS.TOPIC_PROGRESS, topicProgress),
    customSets: () => save(KEYS.CUSTOM_SETS, customSets),
    notepad: () => save(KEYS.NOTEPAD, notepad),
    all: () => {
      persist.profile();
      persist.stats();
      persist.settings();
      persist.history();
      persist.achievements();
      persist.flashcards();
      persist.bookmarks();
      persist.studyProgress();
      persist.topicProgress();
      persist.customSets();
      persist.notepad();
    },
  };

  // ---------- XP / Level System ----------
  // Levels scale: level n requires n*100 XP cumulative threshold
  function xpForLevel(lvl) {
    return Math.floor(50 * lvl * (lvl + 1) * (1 + lvl * 0.1));
  }
  function levelFromXP(xp) {
    let lvl = 1;
    while (xp >= xpForLevel(lvl)) lvl++;
    return lvl;
  }
  function levelProgress() {
    const cur = xpForLevel(profile.level - 1);
    const next = xpForLevel(profile.level);
    const inLevel = profile.xp - cur;
    const need = next - cur;
    return { inLevel, need, pct: Math.min(100, (inLevel / need) * 100) };
  }
  const TITLES = [
    { min: 1, title: "Beginner" },
    { min: 3, title: "Learner" },
    { min: 5, title: "Practitioner" },
    { min: 8, title: "Solver" },
    { min: 12, title: "Strategist" },
    { min: 16, title: "Expert" },
    { min: 22, title: "Master" },
    { min: 30, title: "Grandmaster" },
    { min: 40, title: "Mathematician" },
    { min: 55, title: "Scholar" },
    { min: 75, title: "Genius" },
    { min: 100, title: "Legend" },
  ];
  function titleForLevel(lvl) {
    let t = TITLES[0].title;
    for (const T of TITLES) if (lvl >= T.min) t = T.title;
    return t;
  }

  function addXP(amount) {
    profile.xp += amount;
    stats.totalXp += amount;
    const newLevel = levelFromXP(profile.xp);
    if (newLevel > profile.level) {
      profile.level = newLevel;
      profile.title = titleForLevel(newLevel);
      return { leveledUp: true, newLevel };
    }
    profile.title = titleForLevel(newLevel);
    return { leveledUp: false };
  }

  // ---------- Streak Management ----------
  function todayStr() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }
  function updateStreak() {
    const today = todayStr();
    if (profile.todayDate !== today) {
      // Check if yesterday
      const y = new Date();
      y.setDate(y.getDate() - 1);
      const yStr = `${y.getFullYear()}-${String(y.getMonth() + 1).padStart(2, "0")}-${String(y.getDate()).padStart(2, "0")}`;
      if (profile.lastActive === yStr) {
        profile.streak += 1;
      } else if (profile.lastActive !== today) {
        profile.streak = 1;
      }
      profile.todayDate = today;
      profile.todayCount = 0;
    }
    profile.lastActive = today;
    if (profile.streak > stats.bestStreak) stats.bestStreak = profile.streak;
  }

  function recordDaily() {
    const t = todayStr();
    if (!stats.byDay[t]) stats.byDay[t] = { a: 0, c: 0, xp: 0, time: 0 };
    return stats.byDay[t];
  }

  // ---------- Answer Recording ----------
  function recordAnswer({
    topic,
    difficulty,
    correct,
    timeSpent,
    mode = "practice",
  }) {
    stats.totalAttempted += 1;
    if (correct) stats.totalCorrect += 1;
    if (timeSpent) {
      if (timeSpent < stats.fastestSolve) stats.fastestSolve = timeSpent;
      if (timeSpent > stats.slowestSolve) stats.slowestSolve = timeSpent;
      stats.totalTimeSpent += timeSpent;
    }

    // Topic stats
    if (!stats.topicsAttempted[topic]) stats.topicsAttempted[topic] = 0;
    if (!stats.topicsCorrect[topic]) stats.topicsCorrect[topic] = 0;
    stats.topicsAttempted[topic] += 1;
    if (correct) stats.topicsCorrect[topic] += 1;

    // Topic progress (unlimited levels per topic)
    if (!topicProgress[topic])
      topicProgress[topic] = { level: 1, solved: 0, mastered: false };
    topicProgress[topic].solved += 1;
    const needed = topicProgress[topic].level * 5;
    if (topicProgress[topic].solved >= needed && correct) {
      topicProgress[topic].level += 1;
      topicProgress[topic].solved = 0;
    }

    // Difficulty stats
    if (stats.difficultyStats[difficulty]) {
      stats.difficultyStats[difficulty].a += 1;
      if (correct) stats.difficultyStats[difficulty].c += 1;
    }

    // Mode stats
    if (stats.byMode[mode]) {
      if (mode === "flashcard") stats.byMode[mode] += 1;
      else {
        stats.byMode[mode].a += 1;
        if (correct) stats.byMode[mode].c += 1;
      }
    }

    // Daily
    const d = recordDaily();
    d.a += 1;
    if (correct) d.c += 1;
    if (timeSpent) d.time = (d.time || 0) + timeSpent;

    // XP
    const baseXP =
      { easy: 5, medium: 10, hard: 18, expert: 30 }[difficulty] || 5;
    const gain = correct
      ? baseXP + Math.floor((timeSpent ? Math.max(0, 30 - timeSpent) : 0) / 2)
      : 1;
    const result = addXP(gain);
    d.xp += gain;

    // Streak
    updateStreak();
    profile.todayCount += 1;

    // History
    history.push({
      t: Date.now(),
      topic,
      difficulty,
      correct,
      timeSpent,
      mode,
      xp: gain,
    });

    // Check achievements
    checkAchievements();

    persist.all();
    return { xp: gain, ...result };
  }

  // ---------- Achievements Catalog ----------
  const ACHIEVEMENTS_CATALOG = [
    {
      id: "first_correct",
      name: "First Steps",
      desc: "Answer your first question correctly",
      icon: "🌱",
      check: () => stats.totalCorrect >= 1,
    },
    {
      id: "ten_correct",
      name: "Getting Warmer",
      desc: "Answer 10 questions correctly",
      icon: "🔥",
      check: () => stats.totalCorrect >= 10,
    },
    {
      id: "fifty_correct",
      name: "Half Century",
      desc: "Answer 50 questions correctly",
      icon: "⭐",
      check: () => stats.totalCorrect >= 50,
    },
    {
      id: "hundred_correct",
      name: "Centurion",
      desc: "Answer 100 questions correctly",
      icon: "💯",
      check: () => stats.totalCorrect >= 100,
    },
    {
      id: "five_hundred",
      name: "Marathoner",
      desc: "Answer 500 questions correctly",
      icon: "🏃",
      check: () => stats.totalCorrect >= 500,
    },
    {
      id: "thousand_correct",
      name: "Math Machine",
      desc: "Answer 1000 questions correctly",
      icon: "🤖",
      check: () => stats.totalCorrect >= 1000,
    },
    {
      id: "streak_3",
      name: "On Fire",
      desc: "Get a 3-question streak",
      icon: "🔥",
      check: () => stats.bestStreak >= 3,
    },
    {
      id: "streak_5",
      name: "Hot Streak",
      desc: "Get a 5-question streak",
      icon: "⚡",
      check: () => stats.bestStreak >= 5,
    },
    {
      id: "streak_10",
      name: "Unstoppable",
      desc: "Get a 10-question streak",
      icon: "🌟",
      check: () => stats.bestStreak >= 10,
    },
    {
      id: "streak_20",
      name: "Lightning",
      desc: "Get a 20-question streak",
      icon: "⚡",
      check: () => stats.bestStreak >= 20,
    },
    {
      id: "level_5",
      name: "Rising Star",
      desc: "Reach level 5",
      icon: "⭐",
      check: () => profile.level >= 5,
    },
    {
      id: "level_10",
      name: "Dedicated",
      desc: "Reach level 10",
      icon: "🎯",
      check: () => profile.level >= 10,
    },
    {
      id: "level_25",
      name: "Veteran",
      desc: "Reach level 25",
      icon: "🏆",
      check: () => profile.level >= 25,
    },
    {
      id: "level_50",
      name: "Elite",
      desc: "Reach level 50",
      icon: "👑",
      check: () => profile.level >= 50,
    },
    {
      id: "level_100",
      name: "Mythic",
      desc: "Reach level 100",
      icon: "🌌",
      check: () => profile.level >= 100,
    },
    {
      id: "speed_demon",
      name: "Speed Demon",
      desc: "Solve a problem in under 3 seconds",
      icon: "💨",
      check: () => stats.fastestSolve <= 3,
    },
    {
      id: "perfectionist",
      name: "Perfectionist",
      desc: "Get 10 correct in a row at hard difficulty",
      icon: "💎",
      check: () => false,
    }, // tracked live
    {
      id: "topic_master",
      name: "Topic Master",
      desc: "Master any topic (reach level 5 in it)",
      icon: "🎓",
      check: () => Object.values(topicProgress).some((t) => t.level >= 5),
    },
    {
      id: "topic_grandmaster",
      name: "Topic Grandmaster",
      desc: "Reach level 10 in any topic",
      icon: "🎖️",
      check: () => Object.values(topicProgress).some((t) => t.level >= 10),
    },
    {
      id: "daily_goal",
      name: "Daily Goal",
      desc: "Complete your daily goal",
      icon: "📅",
      check: () => profile.todayCount >= profile.dailyGoal,
    },
    {
      id: "week_streak",
      name: "Weekly Warrior",
      desc: "Maintain a 7-day streak",
      icon: "📆",
      check: () => profile.streak >= 7,
    },
    {
      id: "month_streak",
      name: "Monthly Master",
      desc: "Maintain a 30-day streak",
      icon: "🗓️",
      check: () => profile.streak >= 30,
    },
    {
      id: "explorer",
      name: "Explorer",
      desc: "Try 5 different topics",
      icon: "🧭",
      check: () => Object.keys(stats.topicsAttempted).length >= 5,
    },
    {
      id: "polymath",
      name: "Polymath",
      desc: "Try 15 different topics",
      icon: "🧠",
      check: () => Object.keys(stats.topicsAttempted).length >= 15,
    },
    {
      id: "all_rounder",
      name: "All-Rounder",
      desc: "Try 30 different topics",
      icon: "🌐",
      check: () => Object.keys(stats.topicsAttempted).length >= 30,
    },
    {
      id: "worksheet_maker",
      name: "Worksheet Maker",
      desc: "Generate your first worksheet",
      icon: "🖨️",
      check: () => stats.worksheetGenerated >= 1,
    },
    {
      id: "card_creator",
      name: "Card Creator",
      desc: "Create a custom flashcard",
      icon: "🗂️",
      check: () => flashcards.length >= 1,
    },
    {
      id: "night_owl",
      name: "Night Owl",
      desc: "Practice after 10 PM",
      icon: "🦉",
      check: () => new Date().getHours() >= 22,
    },
    {
      id: "early_bird",
      name: "Early Bird",
      desc: "Practice before 7 AM",
      icon: "🐦",
      check: () => new Date().getHours() < 7,
    },
    {
      id: "no_hints",
      name: "No Help Needed",
      desc: "Answer 10 questions without hints",
      icon: "🚫",
      check: () => false,
    }, // tracked live
    {
      id: "hard_hitter",
      name: "Hard Hitter",
      desc: "Answer 25 hard questions correctly",
      icon: "🔨",
      check: () => stats.difficultyStats.hard.c >= 25,
    },
    {
      id: "expert_solver",
      name: "Expert Solver",
      desc: "Answer 25 expert questions correctly",
      icon: "🧙",
      check: () => stats.difficultyStats.expert.c >= 25,
    },
    {
      id: "time_master",
      name: "Time Master",
      desc: "Practice for 60 minutes total",
      icon: "⏰",
      check: () => stats.totalTimeSpent >= 3600,
    },
    {
      id: "xp_1k",
      name: "XP Hunter",
      desc: "Earn 1,000 total XP",
      icon: "💎",
      check: () => stats.totalXp >= 1000,
    },
    {
      id: "xp_10k",
      name: "XP Mogul",
      desc: "Earn 10,000 total XP",
      icon: "💰",
      check: () => stats.totalXp >= 10000,
    },
    {
      id: "comeback",
      name: "Comeback Kid",
      desc: "Practice 7 days after your first session",
      icon: "🔄",
      check: () => Date.now() - profile.createdAt >= 7 * 86400000,
    },
  ];

  function checkAchievements() {
    const newlyUnlocked = [];
    for (const a of ACHIEVEMENTS_CATALOG) {
      if (!achievements.includes(a.id) && a.check()) {
        achievements.push(a.id);
        newlyUnlocked.push(a);
      }
    }
    return newlyUnlocked;
  }

  // ---------- Topic Progress ----------
  function getTopicLevel(topicId) {
    return topicProgress[topicId] ? topicProgress[topicId].level : 1;
  }
  function getTopicProgress(topicId) {
    if (!topicProgress[topicId])
      return { level: 1, solved: 0, needed: 5, mastered: false };
    const tp = topicProgress[topicId];
    return {
      level: tp.level,
      solved: tp.solved,
      needed: tp.level * 5,
      mastered: tp.level >= 10,
    };
  }

  // ---------- Custom Flashcards ----------
  function addFlashcard(card) {
    flashcards.push({
      ...card,
      id: Date.now() + Math.random(),
      created: Date.now(),
    });
    persist.flashcards();
  }
  function removeFlashcard(id) {
    flashcards = flashcards.filter((c) => c.id !== id);
    persist.flashcards();
  }

  // ---------- Bookmarks ----------
  function toggleBookmark(item) {
    const idx = bookmarks.findIndex((b) => b.id === item.id);
    if (idx >= 0) bookmarks.splice(idx, 1);
    else bookmarks.push({ ...item, savedAt: Date.now() });
    persist.bookmarks();
    return idx < 0;
  }
  function isBookmarked(id) {
    return bookmarks.some((b) => b.id === id);
  }

  // ---------- Custom Sets ----------
  function addCustomSet(set) {
    customSets.push({ ...set, id: Date.now(), created: Date.now() });
    stats.customSetsCreated += 1;
    persist.customSets();
    persist.stats();
  }
  function removeCustomSet(id) {
    customSets = customSets.filter((s) => s.id !== id);
    persist.customSets();
  }

  // ---------- Reset ----------
  function resetProgress() {
    profile = structuredClone(DEFAULT_PROFILE);
    stats = structuredClone(DEFAULT_STATS);
    history = [];
    achievements = [];
    flashcards = [];
    bookmarks = [];
    studyProgress = {};
    topicProgress = {};
    customSets = [];
    notepad = "";
    persist.all();
  }
  function resetSettings() {
    settings = structuredClone(DEFAULT_SETTINGS);
    persist.settings();
  }

  // ---------- Export / Import ----------
  function exportData() {
    return {
      version: "1.0",
      exportedAt: new Date().toISOString(),
      profile,
      stats,
      settings,
      history,
      achievements,
      flashcards,
      bookmarks,
      studyProgress,
      topicProgress,
      customSets,
      notepad,
    };
  }
  function importData(data) {
    if (!data || typeof data !== "object") return false;
    try {
      if (data.profile) profile = data.profile;
      if (data.stats) stats = data.stats;
      if (data.settings) settings = { ...DEFAULT_SETTINGS, ...data.settings };
      if (data.history) history = data.history;
      if (data.achievements) achievements = data.achievements;
      if (data.flashcards) flashcards = data.flashcards;
      if (data.bookmarks) bookmarks = data.bookmarks;
      if (data.studyProgress) studyProgress = data.studyProgress;
      if (data.topicProgress) topicProgress = data.topicProgress;
      if (data.customSets) customSets = data.customSets;
      if (data.notepad) notepad = data.notepad;
      persist.all();
      return true;
    } catch (e) {
      console.error("Import failed", e);
      return false;
    }
  }

  // ---------- Public API ----------
  return {
    // state accessors
    get profile() {
      return profile;
    },
    get stats() {
      return stats;
    },
    get settings() {
      return settings;
    },
    get history() {
      return history;
    },
    get achievements() {
      return achievements;
    },
    get flashcards() {
      return flashcards;
    },
    get bookmarks() {
      return bookmarks;
    },
    get studyProgress() {
      return studyProgress;
    },
    get topicProgress() {
      return topicProgress;
    },
    get customSets() {
      return customSets;
    },
    get notepad() {
      return notepad;
    },
    set notepad(v) {
      notepad = v;
      persist.notepad();
    },
    set settings(v) {
      settings = v;
      persist.settings();
    },
    set profile(v) {
      profile = v;
      persist.profile();
    },
    ACHIEVEMENTS: ACHIEVEMENTS_CATALOG,
    TITLES,
    // methods
    persist,
    recordAnswer,
    addXP,
    levelProgress,
    levelFromXP,
    titleForLevel,
    checkAchievements,
    getTopicLevel,
    getTopicProgress,
    addFlashcard,
    removeFlashcard,
    toggleBookmark,
    isBookmarked,
    addCustomSet,
    removeCustomSet,
    resetProgress,
    resetSettings,
    exportData,
    importData,
    todayStr,
    updateStreak,
    DEFAULT_SETTINGS,
  };
})();
